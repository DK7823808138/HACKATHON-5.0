package rx;

import rx.internal.util.SubscriptionList;

public abstract class Subscriber<T> implements Observer<T>, Subscription {
    private final SubscriptionList cs;
    private final Subscriber<?> op;
    private Producer f859p;
    private long requested;

    protected Subscriber() {
        this.requested = Long.MIN_VALUE;
        this.op = null;
        this.cs = new SubscriptionList();
    }

    protected Subscriber(Subscriber<?> op) {
        this.requested = Long.MIN_VALUE;
        this.op = op;
        this.cs = op.cs;
    }

    public final void add(Subscription s) {
        this.cs.add(s);
    }

    public final void unsubscribe() {
        this.cs.unsubscribe();
    }

    public final boolean isUnsubscribed() {
        return this.cs.isUnsubscribed();
    }

    public void onStart() {
    }

    protected final void request(long n) {
        Producer shouldRequest = null;
        synchronized (this) {
            if (this.f859p != null) {
                shouldRequest = this.f859p;
            } else {
                this.requested = n;
            }
        }
        if (shouldRequest != null) {
            shouldRequest.request(n);
        }
    }

    public void setProducer(Producer producer) {
        boolean setProducer = false;
        synchronized (this) {
            long toRequest = this.requested;
            this.f859p = producer;
            if (this.op != null && toRequest == Long.MIN_VALUE) {
                setProducer = true;
            }
        }
        if (setProducer) {
            this.op.setProducer(this.f859p);
        } else if (toRequest == Long.MIN_VALUE) {
            this.f859p.request(Long.MAX_VALUE);
        } else {
            this.f859p.request(toRequest);
        }
    }
}
