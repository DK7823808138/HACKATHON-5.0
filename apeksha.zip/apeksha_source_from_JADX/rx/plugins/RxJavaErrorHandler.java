package rx.plugins;

public abstract class RxJavaErrorHandler {
    public void handleError(Throwable e) {
    }
}
