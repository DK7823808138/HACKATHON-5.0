package rx.observers;

import rx.Observer;
import rx.Subscriber;

public class SerializedSubscriber<T> extends Subscriber<T> {
    private final Observer<T> f873s;

    public SerializedSubscriber(Subscriber<? super T> s) {
        super(s);
        this.f873s = new SerializedObserver(s);
    }

    public void onCompleted() {
        this.f873s.onCompleted();
    }

    public void onError(Throwable e) {
        this.f873s.onError(e);
    }

    public void onNext(T t) {
        this.f873s.onNext(t);
    }
}
