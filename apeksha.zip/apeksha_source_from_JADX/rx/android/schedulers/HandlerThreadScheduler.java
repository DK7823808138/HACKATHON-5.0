package rx.android.schedulers;

import android.os.Handler;
import rx.Scheduler;
import rx.Scheduler.Worker;

@Deprecated
public class HandlerThreadScheduler extends Scheduler {
    private final Handler handler;

    @Deprecated
    public HandlerThreadScheduler(Handler handler) {
        this.handler = handler;
    }

    public Worker createWorker() {
        return new InnerHandlerThreadScheduler(this.handler);
    }
}
