package rx.android;

import android.os.Looper;
import rx.Scheduler.Worker;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action0;
import rx.subscriptions.Subscriptions;

public final class AndroidSubscriptions {
    private AndroidSubscriptions() {
        throw new AssertionError("No instances");
    }

    public static Subscription unsubscribeInUiThread(final Action0 unsubscribe) {
        return Subscriptions.create(new Action0() {
            public void call() {
                if (Looper.getMainLooper() == Looper.myLooper()) {
                    unsubscribe.call();
                    return;
                }
                final Worker inner = AndroidSchedulers.mainThread().createWorker();
                inner.schedule(new Action0() {
                    public void call() {
                        unsubscribe.call();
                        inner.unsubscribe();
                    }
                });
            }
        });
    }
}
