package rx.android.content;

import android.database.Cursor;
import rx.Observable.OnSubscribe;
import rx.Subscriber;

final class OnSubscribeCursor implements OnSubscribe<Cursor> {
    private final Cursor cursor;

    OnSubscribeCursor(Cursor cursor) {
        this.cursor = cursor;
    }

    public void call(Subscriber<? super Cursor> subscriber) {
        while (!subscriber.isUnsubscribed() && this.cursor.moveToNext()) {
            try {
                subscriber.onNext(this.cursor);
            } catch (Throwable th) {
                if (!this.cursor.isClosed()) {
                    this.cursor.close();
                }
            }
        }
        if (!this.cursor.isClosed()) {
            this.cursor.close();
        }
        subscriber.onCompleted();
    }
}
