package rx.android.content;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.functions.Action0;
import rx.subscriptions.Subscriptions;

class OnSubscribeLocalBroadcastRegister implements OnSubscribe<Intent> {
    private final Context context;
    private final IntentFilter intentFilter;

    public OnSubscribeLocalBroadcastRegister(Context context, IntentFilter intentFilter) {
        this.context = context;
        this.intentFilter = intentFilter;
    }

    public void call(final Subscriber<? super Intent> subscriber) {
        final LocalBroadcastManager localBroadcastManager = LocalBroadcastManager.getInstance(this.context);
        final BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                subscriber.onNext(intent);
            }
        };
        subscriber.add(Subscriptions.create(new Action0() {
            public void call() {
                localBroadcastManager.unregisterReceiver(broadcastReceiver);
            }
        }));
        localBroadcastManager.registerReceiver(broadcastReceiver, this.intentFilter);
    }
}
