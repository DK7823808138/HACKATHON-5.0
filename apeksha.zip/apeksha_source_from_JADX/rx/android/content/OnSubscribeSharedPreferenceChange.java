package rx.android.content;

import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.functions.Action0;
import rx.subscriptions.Subscriptions;

class OnSubscribeSharedPreferenceChange implements OnSubscribe<String> {
    private final SharedPreferences sharedPreferences;

    public OnSubscribeSharedPreferenceChange(SharedPreferences sharedPreferences) {
        this.sharedPreferences = sharedPreferences;
    }

    public void call(final Subscriber<? super String> subscriber) {
        final OnSharedPreferenceChangeListener listener = new OnSharedPreferenceChangeListener() {
            public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
                subscriber.onNext(key);
            }
        };
        subscriber.add(Subscriptions.create(new Action0() {
            public void call() {
                OnSubscribeSharedPreferenceChange.this.sharedPreferences.unregisterOnSharedPreferenceChangeListener(listener);
            }
        }));
        this.sharedPreferences.registerOnSharedPreferenceChangeListener(listener);
    }
}
