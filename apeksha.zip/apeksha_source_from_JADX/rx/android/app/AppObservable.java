package rx.android.app;

import android.app.Activity;
import android.os.Build.VERSION;
import android.support.v4.app.Fragment;
import rx.Observable;
import rx.android.internal.Assertions;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;

public final class AppObservable {
    private static final Func1<Activity, Boolean> ACTIVITY_VALIDATOR = new C27531();
    private static final Func1<Fragment, Boolean> FRAGMENTV4_VALIDATOR = new C27553();
    private static final Func1<android.app.Fragment, Boolean> FRAGMENT_VALIDATOR = new C27542();
    public static final boolean USES_SUPPORT_FRAGMENTS;

    static class C27531 implements Func1<Activity, Boolean> {
        C27531() {
        }

        public Boolean call(Activity activity) {
            return Boolean.valueOf(!activity.isFinishing());
        }
    }

    static class C27542 implements Func1<android.app.Fragment, Boolean> {
        C27542() {
        }

        public Boolean call(android.app.Fragment fragment) {
            boolean z = fragment.isAdded() && !fragment.getActivity().isFinishing();
            return Boolean.valueOf(z);
        }
    }

    static class C27553 implements Func1<Fragment, Boolean> {
        C27553() {
        }

        public Boolean call(Fragment fragment) {
            boolean z = fragment.isAdded() && !fragment.getActivity().isFinishing();
            return Boolean.valueOf(z);
        }
    }

    private AppObservable() {
        throw new AssertionError("No instances");
    }

    static {
        boolean supportFragmentsAvailable = false;
        try {
            Class.forName("android.support.v4.app.Fragment");
            supportFragmentsAvailable = true;
        } catch (ClassNotFoundException e) {
        }
        USES_SUPPORT_FRAGMENTS = supportFragmentsAvailable;
    }

    public static <T> Observable<T> bindActivity(Activity activity, Observable<T> source) {
        Assertions.assertUiThread();
        return source.observeOn(AndroidSchedulers.mainThread()).lift(new OperatorConditionalBinding(activity, ACTIVITY_VALIDATOR));
    }

    public static <T> Observable<T> bindFragment(Object fragment, Observable<T> source) {
        Assertions.assertUiThread();
        Observable<T> o = source.observeOn(AndroidSchedulers.mainThread());
        if (USES_SUPPORT_FRAGMENTS && (fragment instanceof Fragment)) {
            return o.lift(new OperatorConditionalBinding((Fragment) fragment, FRAGMENTV4_VALIDATOR));
        }
        if (VERSION.SDK_INT >= 11 && (fragment instanceof android.app.Fragment)) {
            return o.lift(new OperatorConditionalBinding((android.app.Fragment) fragment, FRAGMENT_VALIDATOR));
        }
        throw new IllegalArgumentException("Target fragment is neither a native nor support library Fragment");
    }
}
