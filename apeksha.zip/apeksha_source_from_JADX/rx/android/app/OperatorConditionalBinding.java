package rx.android.app;

import android.util.Log;
import rx.Observable.Operator;
import rx.Subscriber;
import rx.android.internal.Assertions;
import rx.functions.Func1;
import rx.internal.util.UtilityFunctions;

final class OperatorConditionalBinding<T, R> implements Operator<T, T> {
    private static final String LOG_TAG = "ConditionalBinding";
    private R boundRef;
    private final Func1<? super R, Boolean> predicate;

    public OperatorConditionalBinding(R bound, Func1<? super R, Boolean> predicate) {
        this.boundRef = bound;
        this.predicate = predicate;
    }

    public OperatorConditionalBinding(R bound) {
        this.boundRef = bound;
        this.predicate = UtilityFunctions.alwaysTrue();
    }

    public Subscriber<? super T> call(final Subscriber<? super T> child) {
        return new Subscriber<T>(child) {
            public void onCompleted() {
                Assertions.assertUiThread();
                if (shouldForwardNotification()) {
                    child.onCompleted();
                } else {
                    handleLostBinding("onCompleted");
                }
            }

            public void onError(Throwable e) {
                Assertions.assertUiThread();
                if (shouldForwardNotification()) {
                    child.onError(e);
                } else {
                    handleLostBinding("onError");
                }
            }

            public void onNext(T t) {
                Assertions.assertUiThread();
                if (shouldForwardNotification()) {
                    child.onNext(t);
                } else {
                    handleLostBinding("onNext");
                }
            }

            private boolean shouldForwardNotification() {
                return OperatorConditionalBinding.this.boundRef != null && ((Boolean) OperatorConditionalBinding.this.predicate.call(OperatorConditionalBinding.this.boundRef)).booleanValue();
            }

            private void handleLostBinding(String context) {
                log("bound object has become invalid; skipping " + context);
                log("unsubscribing...");
                OperatorConditionalBinding.this.boundRef = null;
                unsubscribe();
            }

            private void log(String message) {
                if (Log.isLoggable(OperatorConditionalBinding.LOG_TAG, 3)) {
                    Log.d(OperatorConditionalBinding.LOG_TAG, message);
                }
            }
        };
    }

    R getBoundRef() {
        return this.boundRef;
    }
}
