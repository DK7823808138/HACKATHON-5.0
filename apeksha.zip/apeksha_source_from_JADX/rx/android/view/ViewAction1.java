package rx.android.view;

import android.view.View;
import java.lang.ref.WeakReference;
import rx.functions.Action1;

public abstract class ViewAction1<V extends View, T> implements Action1<T> {
    private final WeakReference<V> viewReference;

    public abstract void call(V v, T t);

    public ViewAction1(V view) {
        this.viewReference = new WeakReference(view);
    }

    public final void call(T t) {
        View view = (View) this.viewReference.get();
        if (view != null) {
            call(view, t);
        }
    }
}
