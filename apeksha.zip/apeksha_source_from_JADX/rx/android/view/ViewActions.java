package rx.android.view;

import android.view.View;
import android.widget.TextView;
import com.google.android.gms.analytics.ecommerce.Promotion;
import rx.android.internal.Preconditions;
import rx.functions.Action1;

public final class ViewActions {
    private ViewActions() {
        throw new IllegalStateException("No instances!");
    }

    public static Action1<? super Boolean> setEnabled(View view) {
        Preconditions.checkNotNull(view, Promotion.ACTION_VIEW);
        return new ViewAction1<View, Boolean>(view) {
            public void call(View view, Boolean enabled) {
                view.setEnabled(enabled.booleanValue());
            }
        };
    }

    public static Action1<? super Boolean> setActivated(View view) {
        Preconditions.checkNotNull(view, Promotion.ACTION_VIEW);
        return new ViewAction1<View, Boolean>(view) {
            public void call(View view, Boolean activated) {
                view.setActivated(activated.booleanValue());
            }
        };
    }

    public static Action1<? super Boolean> setClickable(View view) {
        Preconditions.checkNotNull(view, Promotion.ACTION_VIEW);
        return new ViewAction1<View, Boolean>(view) {
            public void call(View view, Boolean clickable) {
                view.setClickable(clickable.booleanValue());
            }
        };
    }

    public static Action1<? super Boolean> setFocusable(View view) {
        Preconditions.checkNotNull(view, Promotion.ACTION_VIEW);
        return new ViewAction1<View, Boolean>(view) {
            public void call(View view, Boolean focusable) {
                view.setFocusable(focusable.booleanValue());
            }
        };
    }

    public static Action1<? super Boolean> setSelected(View view) {
        Preconditions.checkNotNull(view, Promotion.ACTION_VIEW);
        return new ViewAction1<View, Boolean>(view) {
            public void call(View view, Boolean selected) {
                view.setSelected(selected.booleanValue());
            }
        };
    }

    public static Action1<? super Boolean> setVisibility(View view) {
        return setVisibility(view, 8);
    }

    public static Action1<? super Boolean> setVisibility(View view, final int visibilityOnFalse) {
        Preconditions.checkNotNull(view, Promotion.ACTION_VIEW);
        Preconditions.checkArgument(visibilityOnFalse != 0, "Binding false to VISIBLE has no effect and is thus disallowed.");
        if (visibilityOnFalse == 4 || visibilityOnFalse == 8) {
            return new ViewAction1<View, Boolean>(view) {
                public void call(View view, Boolean value) {
                    view.setVisibility(value.booleanValue() ? 0 : visibilityOnFalse);
                }
            };
        }
        throw new IllegalArgumentException(visibilityOnFalse + " is not a valid visibility value.");
    }

    public static Action1<? super CharSequence> setText(TextView textView) {
        Preconditions.checkNotNull(textView, "textView");
        return new ViewAction1<TextView, CharSequence>(textView) {
            public void call(TextView view, CharSequence text) {
                view.setText(text);
            }
        };
    }

    public static Action1<? super Integer> setTextResource(TextView textView) {
        Preconditions.checkNotNull(textView, "textView");
        return new ViewAction1<TextView, Integer>(textView) {
            public void call(TextView view, Integer resId) {
                view.setText(resId.intValue());
            }
        };
    }
}
