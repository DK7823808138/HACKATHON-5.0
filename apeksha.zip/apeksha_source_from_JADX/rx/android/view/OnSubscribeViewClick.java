package rx.android.view;

import android.view.View;
import android.view.View.OnClickListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.Subscription;
import rx.android.AndroidSubscriptions;
import rx.android.internal.Assertions;
import rx.functions.Action0;

final class OnSubscribeViewClick implements OnSubscribe<OnClickEvent> {
    private final boolean emitInitialValue;
    private final View view;

    private static class CachedListeners {
        private static final Map<View, CompositeOnClickListener> sCachedListeners = new WeakHashMap();

        private CachedListeners() {
        }

        public static CompositeOnClickListener getFromViewOrCreate(View view) {
            CompositeOnClickListener cached = (CompositeOnClickListener) sCachedListeners.get(view);
            if (cached != null) {
                return cached;
            }
            CompositeOnClickListener listener = new CompositeOnClickListener();
            sCachedListeners.put(view, listener);
            view.setOnClickListener(listener);
            return listener;
        }
    }

    private static class CompositeOnClickListener implements OnClickListener {
        private final List<OnClickListener> listeners;

        private CompositeOnClickListener() {
            this.listeners = new ArrayList();
        }

        public boolean addOnClickListener(OnClickListener listener) {
            return this.listeners.add(listener);
        }

        public boolean removeOnClickListener(OnClickListener listener) {
            return this.listeners.remove(listener);
        }

        public void onClick(View view) {
            for (OnClickListener listener : this.listeners) {
                listener.onClick(view);
            }
        }
    }

    public OnSubscribeViewClick(View view, boolean emitInitialValue) {
        this.emitInitialValue = emitInitialValue;
        this.view = view;
    }

    public void call(final Subscriber<? super OnClickEvent> observer) {
        Assertions.assertUiThread();
        final CompositeOnClickListener composite = CachedListeners.getFromViewOrCreate(this.view);
        final OnClickListener listener = new OnClickListener() {
            public void onClick(View clicked) {
                observer.onNext(OnClickEvent.create(OnSubscribeViewClick.this.view));
            }
        };
        Subscription subscription = AndroidSubscriptions.unsubscribeInUiThread(new Action0() {
            public void call() {
                composite.removeOnClickListener(listener);
            }
        });
        if (this.emitInitialValue) {
            observer.onNext(OnClickEvent.create(this.view));
        }
        composite.addOnClickListener(listener);
        observer.add(subscription);
    }
}
