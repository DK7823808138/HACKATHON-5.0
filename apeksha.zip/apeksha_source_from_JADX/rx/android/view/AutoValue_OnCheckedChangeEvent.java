package rx.android.view;

import android.widget.CompoundButton;

final class AutoValue_OnCheckedChangeEvent extends OnCheckedChangeEvent {
    private final boolean value;
    private final CompoundButton view;

    AutoValue_OnCheckedChangeEvent(CompoundButton view, boolean value) {
        if (view == null) {
            throw new NullPointerException("Null view");
        }
        this.view = view;
        this.value = value;
    }

    public CompoundButton view() {
        return this.view;
    }

    public boolean value() {
        return this.value;
    }

    public String toString() {
        return "OnCheckedChangeEvent{view=" + this.view + ", value=" + this.value + "}";
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof OnCheckedChangeEvent)) {
            return false;
        }
        OnCheckedChangeEvent that = (OnCheckedChangeEvent) o;
        if (this.view.equals(that.view()) && this.value == that.value()) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return (((1 * 1000003) ^ this.view.hashCode()) * 1000003) ^ (this.value ? 1231 : 1237);
    }
}
