package rx.android.view;

import android.view.View;

final class AutoValue_OnClickEvent extends OnClickEvent {
    private final View view;

    AutoValue_OnClickEvent(View view) {
        if (view == null) {
            throw new NullPointerException("Null view");
        }
        this.view = view;
    }

    public View view() {
        return this.view;
    }

    public String toString() {
        return "OnClickEvent{view=" + this.view + "}";
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof OnClickEvent)) {
            return false;
        }
        return this.view.equals(((OnClickEvent) o).view());
    }

    public int hashCode() {
        return (1 * 1000003) ^ this.view.hashCode();
    }
}
