package rx.android.view;

import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.Subscription;

final class OnSubscribeViewDetachedFromWindowFirst implements OnSubscribe<View> {
    private final View view;

    private static class SubscriptionAdapter implements OnAttachStateChangeListener, Subscription {
        private Subscriber<? super View> subscriber;
        private View view;

        public SubscriptionAdapter(Subscriber<? super View> subscriber, View view) {
            this.subscriber = subscriber;
            this.view = view;
        }

        public void onViewAttachedToWindow(View v) {
        }

        public void onViewDetachedFromWindow(View v) {
            if (!isUnsubscribed()) {
                Subscriber<? super View> originalSubscriber = this.subscriber;
                unsubscribe();
                originalSubscriber.onNext(v);
                originalSubscriber.onCompleted();
            }
        }

        public void unsubscribe() {
            if (!isUnsubscribed()) {
                this.view.removeOnAttachStateChangeListener(this);
                this.view = null;
                this.subscriber = null;
            }
        }

        public boolean isUnsubscribed() {
            return this.view == null;
        }
    }

    public OnSubscribeViewDetachedFromWindowFirst(View view) {
        this.view = view;
    }

    public void call(Subscriber<? super View> subscriber) {
        SubscriptionAdapter adapter = new SubscriptionAdapter(subscriber, this.view);
        subscriber.add(adapter);
        this.view.addOnAttachStateChangeListener(adapter);
    }
}
