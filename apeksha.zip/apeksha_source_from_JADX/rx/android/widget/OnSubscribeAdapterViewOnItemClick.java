package rx.android.widget;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.Subscription;
import rx.android.AndroidSubscriptions;
import rx.android.internal.Assertions;
import rx.functions.Action0;

class OnSubscribeAdapterViewOnItemClick implements OnSubscribe<OnItemClickEvent> {
    private final AdapterView<?> adapterView;

    private static class CachedListeners {
        private static final Map<AdapterView<?>, CompositeOnClickListener> sCachedListeners = new WeakHashMap();

        private CachedListeners() {
        }

        public static CompositeOnClickListener getFromViewOrCreate(AdapterView<?> view) {
            CompositeOnClickListener cached = (CompositeOnClickListener) sCachedListeners.get(view);
            if (cached != null) {
                return cached;
            }
            CompositeOnClickListener listener = new CompositeOnClickListener();
            sCachedListeners.put(view, listener);
            view.setOnItemClickListener(listener);
            return listener;
        }
    }

    private static class CompositeOnClickListener implements OnItemClickListener {
        private final List<OnItemClickListener> listeners;

        private CompositeOnClickListener() {
            this.listeners = new ArrayList();
        }

        public boolean addOnClickListener(OnItemClickListener listener) {
            return this.listeners.add(listener);
        }

        public boolean removeOnClickListener(OnItemClickListener listener) {
            return this.listeners.remove(listener);
        }

        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            for (OnItemClickListener listener : this.listeners) {
                listener.onItemClick(parent, view, position, id);
            }
        }
    }

    public OnSubscribeAdapterViewOnItemClick(AdapterView<?> adapterView) {
        this.adapterView = adapterView;
    }

    public void call(final Subscriber<? super OnItemClickEvent> observer) {
        Assertions.assertUiThread();
        final CompositeOnClickListener composite = CachedListeners.getFromViewOrCreate(this.adapterView);
        final OnItemClickListener listener = new OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                observer.onNext(OnItemClickEvent.create(parent, view, position, id));
            }
        };
        Subscription subscription = AndroidSubscriptions.unsubscribeInUiThread(new Action0() {
            public void call() {
                composite.removeOnClickListener(listener);
            }
        });
        composite.addOnClickListener(listener);
        observer.add(subscription);
    }
}
