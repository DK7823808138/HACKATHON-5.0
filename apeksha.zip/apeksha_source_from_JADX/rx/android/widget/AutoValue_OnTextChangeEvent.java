package rx.android.widget;

import android.widget.TextView;

final class AutoValue_OnTextChangeEvent extends OnTextChangeEvent {
    private final CharSequence text;
    private final TextView view;

    AutoValue_OnTextChangeEvent(TextView view, CharSequence text) {
        if (view == null) {
            throw new NullPointerException("Null view");
        }
        this.view = view;
        if (text == null) {
            throw new NullPointerException("Null text");
        }
        this.text = text;
    }

    public TextView view() {
        return this.view;
    }

    public CharSequence text() {
        return this.text;
    }

    public String toString() {
        return "OnTextChangeEvent{view=" + this.view + ", text=" + this.text + "}";
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof OnTextChangeEvent)) {
            return false;
        }
        OnTextChangeEvent that = (OnTextChangeEvent) o;
        if (this.view.equals(that.view()) && this.text.equals(that.text())) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return (((1 * 1000003) ^ this.view.hashCode()) * 1000003) ^ this.text.hashCode();
    }
}
