package rx.android.widget;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.TextView;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.Subscription;
import rx.android.AndroidSubscriptions;
import rx.android.internal.Assertions;
import rx.functions.Action0;

class OnSubscribeTextViewInput implements OnSubscribe<OnTextChangeEvent> {
    private final boolean emitInitialValue;
    private final TextView input;

    private static class SimpleTextWatcher implements TextWatcher {
        private SimpleTextWatcher() {
        }

        public void beforeTextChanged(CharSequence sequence, int start, int count, int after) {
        }

        public void onTextChanged(CharSequence sequence, int start, int before, int count) {
        }

        public void afterTextChanged(Editable editable) {
        }
    }

    public OnSubscribeTextViewInput(TextView input, boolean emitInitialValue) {
        this.input = input;
        this.emitInitialValue = emitInitialValue;
    }

    public void call(final Subscriber<? super OnTextChangeEvent> observer) {
        Assertions.assertUiThread();
        final TextWatcher watcher = new SimpleTextWatcher() {
            public void afterTextChanged(Editable editable) {
                observer.onNext(OnTextChangeEvent.create(OnSubscribeTextViewInput.this.input));
            }
        };
        Subscription subscription = AndroidSubscriptions.unsubscribeInUiThread(new Action0() {
            public void call() {
                OnSubscribeTextViewInput.this.input.removeTextChangedListener(watcher);
            }
        });
        if (this.emitInitialValue) {
            observer.onNext(OnTextChangeEvent.create(this.input));
        }
        this.input.addTextChangedListener(watcher);
        observer.add(subscription);
    }
}
