package rx.android.widget;

import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.android.AndroidSubscriptions;
import rx.android.internal.Assertions;
import rx.functions.Action0;

class OnSubscribeListViewScroll implements OnSubscribe<OnListViewScrollEvent> {
    private final AbsListView listView;

    private static class CachedListeners {
        private static final Map<AdapterView<?>, CompositeOnScrollListener> sCachedListeners = new WeakHashMap();

        private CachedListeners() {
        }

        public static CompositeOnScrollListener getFromViewOrCreate(AbsListView view) {
            CompositeOnScrollListener cached = (CompositeOnScrollListener) sCachedListeners.get(view);
            if (cached != null) {
                return cached;
            }
            CompositeOnScrollListener listener = new CompositeOnScrollListener();
            sCachedListeners.put(view, listener);
            view.setOnScrollListener(listener);
            return listener;
        }
    }

    private static class CompositeOnScrollListener implements OnScrollListener {
        private final List<OnScrollListener> listeners;

        private CompositeOnScrollListener() {
            this.listeners = new ArrayList();
        }

        public boolean addOnScrollListener(OnScrollListener listener) {
            return this.listeners.add(listener);
        }

        public boolean removeOnScrollListener(OnScrollListener listener) {
            return this.listeners.remove(listener);
        }

        public void onScrollStateChanged(AbsListView view, int scrollState) {
            for (OnScrollListener listener : this.listeners) {
                listener.onScrollStateChanged(view, scrollState);
            }
        }

        public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
            for (OnScrollListener listener : this.listeners) {
                listener.onScroll(view, firstVisibleItem, visibleItemCount, totalItemCount);
            }
        }
    }

    public OnSubscribeListViewScroll(AbsListView listView) {
        this.listView = listView;
    }

    public void call(final Subscriber<? super OnListViewScrollEvent> observer) {
        Assertions.assertUiThread();
        final CompositeOnScrollListener composite = CachedListeners.getFromViewOrCreate(this.listView);
        final OnScrollListener listener = new OnScrollListener() {
            int currentScrollState = 0;

            public void onScrollStateChanged(AbsListView view, int scrollState) {
                this.currentScrollState = scrollState;
            }

            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                observer.onNext(OnListViewScrollEvent.create(view, this.currentScrollState, firstVisibleItem, visibleItemCount, totalItemCount));
            }
        };
        composite.addOnScrollListener(listener);
        observer.add(AndroidSubscriptions.unsubscribeInUiThread(new Action0() {
            public void call() {
                composite.removeOnScrollListener(listener);
            }
        }));
    }
}
