package rx.android.widget;

import android.view.View;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.Subscription;
import rx.android.AndroidSubscriptions;
import rx.android.internal.Assertions;
import rx.android.view.OnCheckedChangeEvent;
import rx.functions.Action0;

class OnSubscribeCompoundButtonInput implements OnSubscribe<OnCheckedChangeEvent> {
    private final CompoundButton button;
    private final boolean emitInitialValue;

    private static class CachedListeners {
        private static final Map<View, CompositeOnCheckedChangeListener> sCachedListeners = new WeakHashMap();

        private CachedListeners() {
        }

        public static CompositeOnCheckedChangeListener getFromViewOrCreate(CompoundButton button) {
            CompositeOnCheckedChangeListener cached = (CompositeOnCheckedChangeListener) sCachedListeners.get(button);
            if (cached != null) {
                return cached;
            }
            CompositeOnCheckedChangeListener listener = new CompositeOnCheckedChangeListener();
            sCachedListeners.put(button, listener);
            button.setOnCheckedChangeListener(listener);
            return listener;
        }
    }

    private static class CompositeOnCheckedChangeListener implements OnCheckedChangeListener {
        private final List<OnCheckedChangeListener> listeners;

        private CompositeOnCheckedChangeListener() {
            this.listeners = new ArrayList();
        }

        public boolean addOnCheckedChangeListener(OnCheckedChangeListener listener) {
            return this.listeners.add(listener);
        }

        public boolean removeOnCheckedChangeListener(OnCheckedChangeListener listener) {
            return this.listeners.remove(listener);
        }

        public void onCheckedChanged(CompoundButton button, boolean checked) {
            for (OnCheckedChangeListener listener : this.listeners) {
                listener.onCheckedChanged(button, checked);
            }
        }
    }

    public OnSubscribeCompoundButtonInput(CompoundButton button, boolean emitInitialValue) {
        this.emitInitialValue = emitInitialValue;
        this.button = button;
    }

    public void call(final Subscriber<? super OnCheckedChangeEvent> observer) {
        Assertions.assertUiThread();
        final CompositeOnCheckedChangeListener composite = CachedListeners.getFromViewOrCreate(this.button);
        final OnCheckedChangeListener listener = new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton view, boolean checked) {
                observer.onNext(OnCheckedChangeEvent.create(OnSubscribeCompoundButtonInput.this.button, checked));
            }
        };
        Subscription subscription = AndroidSubscriptions.unsubscribeInUiThread(new Action0() {
            public void call() {
                composite.removeOnCheckedChangeListener(listener);
            }
        });
        if (this.emitInitialValue) {
            observer.onNext(OnCheckedChangeEvent.create(this.button));
        }
        composite.addOnCheckedChangeListener(listener);
        observer.add(subscription);
    }
}
