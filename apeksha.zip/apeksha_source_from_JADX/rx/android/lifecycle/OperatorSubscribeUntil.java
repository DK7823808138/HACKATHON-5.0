package rx.android.lifecycle;

import rx.Observable;
import rx.Observable.Operator;
import rx.Subscriber;
import rx.observers.SerializedSubscriber;

final class OperatorSubscribeUntil<T, R> implements Operator<T, T> {
    private final Observable<? extends R> other;

    public OperatorSubscribeUntil(Observable<? extends R> other) {
        this.other = other;
    }

    public Subscriber<? super T> call(Subscriber<? super T> child) {
        final Subscriber<T> parent = new SerializedSubscriber(child);
        this.other.unsafeSubscribe(new Subscriber<R>(child) {
            public void onCompleted() {
                parent.unsubscribe();
            }

            public void onError(Throwable e) {
                parent.onError(e);
            }

            public void onNext(R r) {
                parent.unsubscribe();
            }
        });
        return parent;
    }
}
