package rx.android.lifecycle;

import rx.Observable;
import rx.functions.Func1;
import rx.functions.Func2;

public class LifecycleObservable {
    private static final Func1<LifecycleEvent, LifecycleEvent> ACTIVITY_LIFECYCLE = new C27664();
    private static final Func1<LifecycleEvent, LifecycleEvent> FRAGMENT_LIFECYCLE = new C27675();

    static class C27642 implements Func1<Boolean, Boolean> {
        C27642() {
        }

        public Boolean call(Boolean shouldComplete) {
            return shouldComplete;
        }
    }

    static class C27653 implements Func2<LifecycleEvent, LifecycleEvent, Boolean> {
        C27653() {
        }

        public Boolean call(LifecycleEvent bindUntilEvent, LifecycleEvent lifecycleEvent) {
            return Boolean.valueOf(lifecycleEvent == bindUntilEvent);
        }
    }

    static class C27664 implements Func1<LifecycleEvent, LifecycleEvent> {
        C27664() {
        }

        public LifecycleEvent call(LifecycleEvent lastEvent) {
            if (lastEvent == null) {
                throw new NullPointerException("Cannot bind to null LifecycleEvent.");
            }
            switch (lastEvent) {
                case CREATE:
                    return LifecycleEvent.DESTROY;
                case START:
                    return LifecycleEvent.STOP;
                case RESUME:
                    return LifecycleEvent.PAUSE;
                case PAUSE:
                    return LifecycleEvent.STOP;
                case STOP:
                    return LifecycleEvent.DESTROY;
                case DESTROY:
                    throw new IllegalStateException("Cannot bind to Activity lifecycle when outside of it.");
                case ATTACH:
                case CREATE_VIEW:
                case DESTROY_VIEW:
                case DETACH:
                    throw new IllegalStateException("Cannot bind to " + lastEvent + " for an Activity.");
                default:
                    throw new UnsupportedOperationException("Binding to LifecycleEvent " + lastEvent + " not yet implemented");
            }
        }
    }

    static class C27675 implements Func1<LifecycleEvent, LifecycleEvent> {
        C27675() {
        }

        public LifecycleEvent call(LifecycleEvent lastEvent) {
            if (lastEvent == null) {
                throw new NullPointerException("Cannot bind to null LifecycleEvent.");
            }
            switch (lastEvent) {
                case CREATE:
                    return LifecycleEvent.DESTROY;
                case START:
                    return LifecycleEvent.STOP;
                case RESUME:
                    return LifecycleEvent.PAUSE;
                case PAUSE:
                    return LifecycleEvent.STOP;
                case STOP:
                    return LifecycleEvent.DESTROY_VIEW;
                case DESTROY:
                    return LifecycleEvent.DETACH;
                case ATTACH:
                    return LifecycleEvent.DETACH;
                case CREATE_VIEW:
                    return LifecycleEvent.DESTROY_VIEW;
                case DESTROY_VIEW:
                    return LifecycleEvent.DESTROY;
                case DETACH:
                    throw new IllegalStateException("Cannot bind to Fragment lifecycle when outside of it.");
                default:
                    throw new UnsupportedOperationException("Binding to LifecycleEvent " + lastEvent + " not yet implemented");
            }
        }
    }

    private LifecycleObservable() {
        throw new AssertionError("No instances");
    }

    public static <T> Observable<T> bindUntilLifecycleEvent(Observable<LifecycleEvent> lifecycle, Observable<T> source, final LifecycleEvent event) {
        if (lifecycle != null && source != null) {
            return source.lift(new OperatorSubscribeUntil(lifecycle.takeFirst(new Func1<LifecycleEvent, Boolean>() {
                public Boolean call(LifecycleEvent lifecycleEvent) {
                    return Boolean.valueOf(lifecycleEvent == event);
                }
            })));
        }
        throw new IllegalArgumentException("Lifecycle and Observable must be given");
    }

    public static <T> Observable<T> bindActivityLifecycle(Observable<LifecycleEvent> lifecycle, Observable<T> source) {
        return bindLifecycle(lifecycle, source, ACTIVITY_LIFECYCLE);
    }

    public static <T> Observable<T> bindFragmentLifecycle(Observable<LifecycleEvent> lifecycle, Observable<T> source) {
        return bindLifecycle(lifecycle, source, FRAGMENT_LIFECYCLE);
    }

    private static <T> Observable<T> bindLifecycle(Observable<LifecycleEvent> lifecycle, Observable<T> source, Func1<LifecycleEvent, LifecycleEvent> correspondingEvents) {
        if (lifecycle == null || source == null) {
            throw new IllegalArgumentException("Lifecycle and Observable must be given");
        }
        Observable<LifecycleEvent> sharedLifecycle = lifecycle.share();
        return source.lift(new OperatorSubscribeUntil(Observable.combineLatest(sharedLifecycle.take(1).map(correspondingEvents), sharedLifecycle.skip(1), new C27653()).takeFirst(new C27642())));
    }
}
