package rx.functions;

public interface Function {
}
