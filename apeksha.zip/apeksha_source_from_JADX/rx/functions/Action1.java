package rx.functions;

public interface Action1<T1> extends Action {
    void call(T1 t1);
}
