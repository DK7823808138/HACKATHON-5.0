package rx.observables;

import java.util.Iterator;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicReference;
import rx.Observable;
import rx.Subscriber;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.internal.operators.BlockingOperatorLatest;
import rx.internal.operators.BlockingOperatorMostRecent;
import rx.internal.operators.BlockingOperatorNext;
import rx.internal.operators.BlockingOperatorToFuture;
import rx.internal.operators.BlockingOperatorToIterator;
import rx.internal.util.UtilityFunctions;

public final class BlockingObservable<T> {
    private final Observable<? extends T> f871o;

    class C29962 implements Iterable<T> {
        C29962() {
        }

        public Iterator<T> iterator() {
            return BlockingObservable.this.getIterator();
        }
    }

    private BlockingObservable(Observable<? extends T> o) {
        this.f871o = o;
    }

    public static <T> BlockingObservable<T> from(Observable<? extends T> o) {
        return new BlockingObservable(o);
    }

    public void forEach(final Action1<? super T> onNext) {
        final CountDownLatch latch = new CountDownLatch(1);
        final AtomicReference<Throwable> exceptionFromOnError = new AtomicReference();
        this.f871o.subscribe(new Subscriber<T>() {
            public void onCompleted() {
                latch.countDown();
            }

            public void onError(Throwable e) {
                exceptionFromOnError.set(e);
                latch.countDown();
            }

            public void onNext(T args) {
                onNext.call(args);
            }
        });
        try {
            latch.await();
            if (exceptionFromOnError.get() == null) {
                return;
            }
            if (exceptionFromOnError.get() instanceof RuntimeException) {
                throw ((RuntimeException) exceptionFromOnError.get());
            }
            throw new RuntimeException((Throwable) exceptionFromOnError.get());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Interrupted while waiting for subscription to complete.", e);
        }
    }

    public Iterator<T> getIterator() {
        return BlockingOperatorToIterator.toIterator(this.f871o);
    }

    public T first() {
        return blockForSingle(this.f871o.first());
    }

    public T first(Func1<? super T, Boolean> predicate) {
        return blockForSingle(this.f871o.first(predicate));
    }

    public T firstOrDefault(T defaultValue) {
        return blockForSingle(this.f871o.map(UtilityFunctions.identity()).firstOrDefault(defaultValue));
    }

    public T firstOrDefault(T defaultValue, Func1<? super T, Boolean> predicate) {
        return blockForSingle(this.f871o.filter(predicate).map(UtilityFunctions.identity()).firstOrDefault(defaultValue));
    }

    public T last() {
        return blockForSingle(this.f871o.last());
    }

    public T last(Func1<? super T, Boolean> predicate) {
        return blockForSingle(this.f871o.last(predicate));
    }

    public T lastOrDefault(T defaultValue) {
        return blockForSingle(this.f871o.map(UtilityFunctions.identity()).lastOrDefault(defaultValue));
    }

    public T lastOrDefault(T defaultValue, Func1<? super T, Boolean> predicate) {
        return blockForSingle(this.f871o.filter(predicate).map(UtilityFunctions.identity()).lastOrDefault(defaultValue));
    }

    public Iterable<T> mostRecent(T initialValue) {
        return BlockingOperatorMostRecent.mostRecent(this.f871o, initialValue);
    }

    public Iterable<T> next() {
        return BlockingOperatorNext.next(this.f871o);
    }

    public Iterable<T> latest() {
        return BlockingOperatorLatest.latest(this.f871o);
    }

    public T single() {
        return blockForSingle(this.f871o.single());
    }

    public T single(Func1<? super T, Boolean> predicate) {
        return blockForSingle(this.f871o.single(predicate));
    }

    public T singleOrDefault(T defaultValue) {
        return blockForSingle(this.f871o.map(UtilityFunctions.identity()).singleOrDefault(defaultValue));
    }

    public T singleOrDefault(T defaultValue, Func1<? super T, Boolean> predicate) {
        return blockForSingle(this.f871o.filter(predicate).map(UtilityFunctions.identity()).singleOrDefault(defaultValue));
    }

    public Future<T> toFuture() {
        return BlockingOperatorToFuture.toFuture(this.f871o);
    }

    public Iterable<T> toIterable() {
        return new C29962();
    }

    private T blockForSingle(Observable<? extends T> observable) {
        final AtomicReference<T> returnItem = new AtomicReference();
        final AtomicReference<Throwable> returnException = new AtomicReference();
        final CountDownLatch latch = new CountDownLatch(1);
        observable.subscribe(new Subscriber<T>() {
            public void onCompleted() {
                latch.countDown();
            }

            public void onError(Throwable e) {
                returnException.set(e);
                latch.countDown();
            }

            public void onNext(T item) {
                returnItem.set(item);
            }
        });
        try {
            latch.await();
            if (returnException.get() == null) {
                return returnItem.get();
            }
            if (returnException.get() instanceof RuntimeException) {
                throw ((RuntimeException) returnException.get());
            }
            throw new RuntimeException((Throwable) returnException.get());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Interrupted while waiting for subscription to complete.", e);
        }
    }
}
