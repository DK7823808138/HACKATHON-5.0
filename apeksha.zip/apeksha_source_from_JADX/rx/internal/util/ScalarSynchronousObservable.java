package rx.internal.util;

import rx.Observable;
import rx.Observable.OnSubscribe;
import rx.Subscriber;

public final class ScalarSynchronousObservable<T> extends Observable<T> {
    private final T f869t;

    class C29911 implements OnSubscribe<T> {
        final /* synthetic */ Object val$t;

        C29911(Object obj) {
            this.val$t = obj;
        }

        public void call(Subscriber<? super T> s) {
            s.onNext(this.val$t);
            s.onCompleted();
        }
    }

    public static final <T> ScalarSynchronousObservable<T> create(T t) {
        return new ScalarSynchronousObservable(t);
    }

    protected ScalarSynchronousObservable(T t) {
        super(new C29911(t));
        this.f869t = t;
    }

    public T get() {
        return this.f869t;
    }
}
