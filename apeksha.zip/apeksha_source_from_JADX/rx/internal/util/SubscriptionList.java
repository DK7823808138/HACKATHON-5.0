package rx.internal.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import rx.Subscription;
import rx.exceptions.CompositeException;

public final class SubscriptionList implements Subscription {
    private List<Subscription> subscriptions;
    private boolean unsubscribed = false;

    public SubscriptionList(Subscription... subscriptions) {
        this.subscriptions = new LinkedList(Arrays.asList(subscriptions));
    }

    public synchronized boolean isUnsubscribed() {
        return this.unsubscribed;
    }

    public void add(Subscription s) {
        Subscription unsubscribe = null;
        synchronized (this) {
            if (this.unsubscribed) {
                unsubscribe = s;
            } else {
                if (this.subscriptions == null) {
                    this.subscriptions = new LinkedList();
                }
                this.subscriptions.add(s);
            }
        }
        if (unsubscribe != null) {
            unsubscribe.unsubscribe();
        }
    }

    public void unsubscribe() {
        synchronized (this) {
            if (this.unsubscribed) {
                return;
            }
            this.unsubscribed = true;
            unsubscribeFromAll(this.subscriptions);
            this.subscriptions = null;
        }
    }

    private static void unsubscribeFromAll(Collection<Subscription> subscriptions) {
        if (subscriptions != null) {
            List<Throwable> es = null;
            for (Subscription s : subscriptions) {
                try {
                    s.unsubscribe();
                } catch (Throwable e) {
                    if (es == null) {
                        es = new ArrayList();
                    }
                    es.add(e);
                }
            }
            if (es == null) {
                return;
            }
            if (es.size() == 1) {
                Throwable t = (Throwable) es.get(0);
                if (t instanceof RuntimeException) {
                    throw ((RuntimeException) t);
                }
                throw new CompositeException("Failed to unsubscribe to 1 or more subscriptions.", es);
            }
            throw new CompositeException("Failed to unsubscribe to 2 or more subscriptions.", es);
        }
    }
}
