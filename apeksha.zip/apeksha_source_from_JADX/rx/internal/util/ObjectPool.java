package rx.internal.util;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;
import rx.Scheduler.Worker;
import rx.functions.Action0;
import rx.internal.util.unsafe.MpmcArrayQueue;
import rx.internal.util.unsafe.UnsafeAccess;
import rx.schedulers.Schedulers;

public abstract class ObjectPool<T> {
    private final int maxSize;
    private Queue<T> pool;
    private Worker schedulerWorker;

    protected abstract T createObject();

    public ObjectPool() {
        this(0, 0, 67);
    }

    private ObjectPool(final int min, final int max, long validationInterval) {
        this.maxSize = max;
        initialize(min);
        this.schedulerWorker = Schedulers.computation().createWorker();
        this.schedulerWorker.schedulePeriodically(new Action0() {
            public void call() {
                int size = ObjectPool.this.pool.size();
                int i;
                if (size < min) {
                    int sizeToBeAdded = max - size;
                    for (i = 0; i < sizeToBeAdded; i++) {
                        ObjectPool.this.pool.add(ObjectPool.this.createObject());
                    }
                } else if (size > max) {
                    int sizeToBeRemoved = size - max;
                    for (i = 0; i < sizeToBeRemoved; i++) {
                        ObjectPool.this.pool.poll();
                    }
                }
            }
        }, validationInterval, validationInterval, TimeUnit.SECONDS);
    }

    public T borrowObject() {
        T object = this.pool.poll();
        if (object == null) {
            return createObject();
        }
        return object;
    }

    public void returnObject(T object) {
        if (object != null) {
            this.pool.offer(object);
        }
    }

    public void shutdown() {
        this.schedulerWorker.unsubscribe();
    }

    private void initialize(int min) {
        if (UnsafeAccess.isUnsafeAvailable()) {
            this.pool = new MpmcArrayQueue(Math.max(this.maxSize, 1024));
        } else {
            this.pool = new ConcurrentLinkedQueue();
        }
        for (int i = 0; i < min; i++) {
            this.pool.add(createObject());
        }
    }
}
