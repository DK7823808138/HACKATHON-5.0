package rx.internal.util.unsafe;

public final class SpscArrayQueue<E> extends SpscArrayQueueL3Pad<E> {
    public SpscArrayQueue(int capacity) {
        super(capacity);
    }

    public boolean offer(E e) {
        if (e == null) {
            throw new NullPointerException("Null is not a valid element");
        }
        E[] lElementBuffer = this.buffer;
        if (this.producerIndex >= this.producerLookAhead) {
            if (lvElement(lElementBuffer, calcElementOffset(this.producerIndex + ((long) this.lookAheadStep))) != null) {
                return false;
            }
            this.producerLookAhead = this.producerIndex + ((long) this.lookAheadStep);
        }
        long offset = calcElementOffset(this.producerIndex);
        this.producerIndex++;
        soElement(lElementBuffer, offset, e);
        return true;
    }

    public E poll() {
        long offset = calcElementOffset(this.consumerIndex);
        E[] lElementBuffer = this.buffer;
        E e = lvElement(lElementBuffer, offset);
        if (e == null) {
            return null;
        }
        this.consumerIndex++;
        soElement(lElementBuffer, offset, null);
        return e;
    }

    public E peek() {
        return lvElement(calcElementOffset(this.consumerIndex));
    }

    public int size() {
        long currentProducerIndex;
        long after = lvConsumerIndex();
        long before;
        do {
            before = after;
            currentProducerIndex = lvProducerIndex();
            after = lvConsumerIndex();
        } while (before != after);
        return (int) (currentProducerIndex - after);
    }
}
