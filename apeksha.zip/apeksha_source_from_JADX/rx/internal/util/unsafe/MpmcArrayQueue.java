package rx.internal.util.unsafe;

public class MpmcArrayQueue<E> extends MpmcArrayQueueConsumerField<E> {
    long p30;
    long p31;
    long p32;
    long p33;
    long p34;
    long p35;
    long p36;
    long p37;
    long p40;
    long p41;
    long p42;
    long p43;
    long p44;
    long p45;
    long p46;

    public MpmcArrayQueue(int capacity) {
        super(Math.max(2, capacity));
    }

    public boolean offer(E e) {
        if (e == null) {
            throw new NullPointerException("Null is not a valid element");
        }
        long[] lSequenceBuffer = this.sequenceBuffer;
        while (true) {
            long currentProducerIndex = lvProducerIndex();
            long seqOffset = calcSequenceOffset(currentProducerIndex);
            long delta = lvSequence(lSequenceBuffer, seqOffset) - currentProducerIndex;
            if (delta == 0) {
                if (casProducerIndex(currentProducerIndex, 1 + currentProducerIndex)) {
                    spElement(calcElementOffset(currentProducerIndex), e);
                    soSequence(lSequenceBuffer, seqOffset, 1 + currentProducerIndex);
                    return true;
                }
            } else if (delta < 0) {
                return false;
            }
        }
    }

    public E poll() {
        long[] lSequenceBuffer = this.sequenceBuffer;
        while (true) {
            long currentConsumerIndex = lvConsumerIndex();
            long seqOffset = calcSequenceOffset(currentConsumerIndex);
            long delta = lvSequence(lSequenceBuffer, seqOffset) - (1 + currentConsumerIndex);
            if (delta == 0) {
                if (casConsumerIndex(currentConsumerIndex, 1 + currentConsumerIndex)) {
                    long offset = calcElementOffset(currentConsumerIndex);
                    E e = lpElement(offset);
                    spElement(offset, null);
                    soSequence(lSequenceBuffer, seqOffset, ((long) this.capacity) + currentConsumerIndex);
                    return e;
                }
            } else if (delta < 0) {
                return null;
            }
        }
    }

    public E peek() {
        return lpElement(calcElementOffset(lvConsumerIndex()));
    }

    public int size() {
        long currentProducerIndex;
        long after = lvConsumerIndex();
        long before;
        do {
            before = after;
            currentProducerIndex = lvProducerIndex();
            after = lvConsumerIndex();
        } while (before != after);
        return (int) (currentProducerIndex - after);
    }

    public boolean isEmpty() {
        return lvConsumerIndex() == lvProducerIndex();
    }
}
