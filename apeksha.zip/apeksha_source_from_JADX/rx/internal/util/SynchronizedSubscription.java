package rx.internal.util;

import rx.Subscription;

public class SynchronizedSubscription implements Subscription {
    private final Subscription f870s;

    public SynchronizedSubscription(Subscription s) {
        this.f870s = s;
    }

    public synchronized void unsubscribe() {
        this.f870s.unsubscribe();
    }

    public synchronized boolean isUnsubscribed() {
        return this.f870s.isUnsubscribed();
    }
}
