package rx.internal.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import rx.Subscription;
import rx.exceptions.CompositeException;

public final class SubscriptionRandomList<T extends Subscription> implements Subscription {
    private Set<T> subscriptions;
    private boolean unsubscribed = false;

    public SubscriptionRandomList(T... subscriptions) {
        this.subscriptions = new HashSet(Arrays.asList(subscriptions));
    }

    public synchronized boolean isUnsubscribed() {
        return this.unsubscribed;
    }

    public void add(T s) {
        Subscription unsubscribe = null;
        synchronized (this) {
            if (this.unsubscribed) {
                unsubscribe = s;
            } else {
                if (this.subscriptions == null) {
                    this.subscriptions = new HashSet(4);
                }
                this.subscriptions.add(s);
            }
        }
        if (unsubscribe != null) {
            unsubscribe.unsubscribe();
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void remove(rx.Subscription r3) {
        /*
        r2 = this;
        r0 = 0;
        monitor-enter(r2);
        r1 = r2.unsubscribed;	 Catch:{ all -> 0x0019 }
        if (r1 != 0) goto L_0x000a;
    L_0x0006:
        r1 = r2.subscriptions;	 Catch:{ all -> 0x0019 }
        if (r1 != 0) goto L_0x000c;
    L_0x000a:
        monitor-exit(r2);	 Catch:{ all -> 0x0019 }
    L_0x000b:
        return;
    L_0x000c:
        r1 = r2.subscriptions;	 Catch:{ all -> 0x0019 }
        r0 = r1.remove(r3);	 Catch:{ all -> 0x0019 }
        monitor-exit(r2);	 Catch:{ all -> 0x0019 }
        if (r0 == 0) goto L_0x000b;
    L_0x0015:
        r3.unsubscribe();
        goto L_0x000b;
    L_0x0019:
        r1 = move-exception;
        monitor-exit(r2);	 Catch:{ all -> 0x0019 }
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: rx.internal.util.SubscriptionRandomList.remove(rx.Subscription):void");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void clear() {
        /*
        r2 = this;
        r0 = 0;
        monitor-enter(r2);
        r1 = r2.unsubscribed;	 Catch:{ all -> 0x0016 }
        if (r1 != 0) goto L_0x000a;
    L_0x0006:
        r1 = r2.subscriptions;	 Catch:{ all -> 0x0016 }
        if (r1 != 0) goto L_0x000c;
    L_0x000a:
        monitor-exit(r2);	 Catch:{ all -> 0x0016 }
    L_0x000b:
        return;
    L_0x000c:
        r0 = r2.subscriptions;	 Catch:{ all -> 0x0016 }
        r1 = 0;
        r2.subscriptions = r1;	 Catch:{ all -> 0x0016 }
        monitor-exit(r2);	 Catch:{ all -> 0x0016 }
        unsubscribeFromAll(r0);
        goto L_0x000b;
    L_0x0016:
        r1 = move-exception;
        monitor-exit(r2);	 Catch:{ all -> 0x0016 }
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: rx.internal.util.SubscriptionRandomList.clear():void");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void forEach(rx.functions.Action1<T> r6) {
        /*
        r5 = this;
        r1 = 0;
        monitor-enter(r5);
        r3 = r5.unsubscribed;	 Catch:{ all -> 0x0023 }
        if (r3 != 0) goto L_0x000a;
    L_0x0006:
        r3 = r5.subscriptions;	 Catch:{ all -> 0x0023 }
        if (r3 != 0) goto L_0x000c;
    L_0x000a:
        monitor-exit(r5);	 Catch:{ all -> 0x0023 }
    L_0x000b:
        return;
    L_0x000c:
        r3 = r5.subscriptions;	 Catch:{ all -> 0x0023 }
        r3 = r3.toArray(r1);	 Catch:{ all -> 0x0023 }
        r0 = r3;
        r0 = (rx.Subscription[]) r0;	 Catch:{ all -> 0x0023 }
        r1 = r0;
        monitor-exit(r5);	 Catch:{ all -> 0x0023 }
        r4 = r1.length;
        r3 = 0;
    L_0x0019:
        if (r3 >= r4) goto L_0x000b;
    L_0x001b:
        r2 = r1[r3];
        r6.call(r2);
        r3 = r3 + 1;
        goto L_0x0019;
    L_0x0023:
        r3 = move-exception;
        monitor-exit(r5);	 Catch:{ all -> 0x0023 }
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: rx.internal.util.SubscriptionRandomList.forEach(rx.functions.Action1):void");
    }

    public void unsubscribe() {
        synchronized (this) {
            if (this.unsubscribed) {
                return;
            }
            this.unsubscribed = true;
            Collection<T> unsubscribe = this.subscriptions;
            this.subscriptions = null;
            unsubscribeFromAll(unsubscribe);
        }
    }

    private static <T extends Subscription> void unsubscribeFromAll(Collection<T> subscriptions) {
        if (subscriptions != null) {
            List<Throwable> es = null;
            for (T s : subscriptions) {
                try {
                    s.unsubscribe();
                } catch (Throwable e) {
                    if (es == null) {
                        es = new ArrayList();
                    }
                    es.add(e);
                }
            }
            if (es == null) {
                return;
            }
            if (es.size() == 1) {
                Throwable t = (Throwable) es.get(0);
                if (t instanceof RuntimeException) {
                    throw ((RuntimeException) t);
                }
                throw new CompositeException("Failed to unsubscribe to 1 or more subscriptions.", es);
            }
            throw new CompositeException("Failed to unsubscribe to 2 or more subscriptions.", es);
        }
    }
}
