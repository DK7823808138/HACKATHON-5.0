package rx.internal.operators;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import rx.Observable;
import rx.Observable.Operator;
import rx.Producer;
import rx.Subscriber;
import rx.exceptions.CompositeException;
import rx.exceptions.MissingBackpressureException;
import rx.exceptions.OnErrorThrowable;
import rx.functions.Func1;
import rx.internal.util.RxRingBuffer;
import rx.internal.util.ScalarSynchronousObservable;
import rx.internal.util.SubscriptionIndexedRingBuffer;

public class OperatorMerge<T> implements Operator<T, Observable<? extends T>> {
    private final boolean delayErrors;

    private static final class InnerSubscriber<T> extends Subscriber<T> {
        static final AtomicIntegerFieldUpdater<InnerSubscriber> ONCE_TERMINATED = AtomicIntegerFieldUpdater.newUpdater(InnerSubscriber.class, "terminated");
        final MergeSubscriber<T> parentSubscriber;
        final MergeProducer<T> producer;
        private final RxRingBuffer f864q = RxRingBuffer.getSpmcInstance();
        public int sindex;
        volatile int terminated;

        public InnerSubscriber(MergeSubscriber<T> parent, MergeProducer<T> producer) {
            this.parentSubscriber = parent;
            this.producer = producer;
            add(this.f864q);
            request((long) this.f864q.capacity());
        }

        public void onNext(T t) {
            emit(t, false);
        }

        public void onError(Throwable e) {
            if (ONCE_TERMINATED.compareAndSet(this, 0, 1)) {
                this.parentSubscriber.innerError(e, false);
            }
        }

        public void onCompleted() {
            if (ONCE_TERMINATED.compareAndSet(this, 0, 1)) {
                emit(null, true);
            }
        }

        public void requestMore(long n) {
            request(n);
        }

        private void emit(T t, boolean complete) {
            boolean drain = false;
            boolean enqueue = true;
            if (this.parentSubscriber.getEmitLock()) {
                long emitted;
                enqueue = false;
                try {
                    emitted = 0 + ((long) drainQueue());
                    if (this.producer == null) {
                        if (complete) {
                            this.parentSubscriber.completeInner(this);
                        } else {
                            this.parentSubscriber.actual.onNext(t);
                            emitted++;
                        }
                    } else if (this.producer.requested <= 0 || this.f864q.count() != 0) {
                        enqueue = true;
                    } else if (complete) {
                        this.parentSubscriber.completeInner(this);
                    } else {
                        try {
                            this.parentSubscriber.actual.onNext(t);
                        } catch (Throwable e) {
                            onError(OnErrorThrowable.addValueAsLastCause(e, t));
                        }
                        emitted++;
                        MergeProducer.REQUESTED.decrementAndGet(this.producer);
                    }
                } catch (Throwable th) {
                    drain = this.parentSubscriber.releaseEmitLock();
                }
                drain = this.parentSubscriber.releaseEmitLock();
                if (emitted > 0) {
                    request(emitted);
                }
            }
            if (enqueue) {
                enqueue(t, complete);
                drain = true;
            }
            if (drain) {
                this.parentSubscriber.drainQueuesIfNeeded();
            }
        }

        private void enqueue(T t, boolean complete) {
            if (complete) {
                try {
                    this.f864q.onCompleted();
                    return;
                } catch (MissingBackpressureException e) {
                    onError(e);
                    return;
                }
            }
            this.f864q.onNext(t);
        }

        private int drainRequested() {
            int emitted = 0;
            long toEmit = this.producer.requested;
            for (int i = 0; ((long) i) < toEmit; i++) {
                Object o = this.f864q.poll();
                if (o == null) {
                    break;
                }
                if (this.f864q.isCompleted(o)) {
                    this.parentSubscriber.completeInner(this);
                } else {
                    try {
                        if (!this.f864q.accept(o, this.parentSubscriber.actual)) {
                            emitted++;
                        }
                    } catch (Throwable e) {
                        onError(OnErrorThrowable.addValueAsLastCause(e, o));
                    }
                }
            }
            MergeProducer.REQUESTED.getAndAdd(this.producer, (long) (-emitted));
            return emitted;
        }

        private int drainAll() {
            int emitted = 0;
            while (true) {
                Object o = this.f864q.poll();
                if (o == null) {
                    return emitted;
                }
                if (this.f864q.isCompleted(o)) {
                    this.parentSubscriber.completeInner(this);
                } else {
                    try {
                        if (!this.f864q.accept(o, this.parentSubscriber.actual)) {
                            emitted++;
                        }
                    } catch (Throwable e) {
                        onError(OnErrorThrowable.addValueAsLastCause(e, o));
                    }
                }
            }
        }

        private int drainQueue() {
            if (this.producer != null) {
                return drainRequested();
            }
            return drainAll();
        }
    }

    private static final class MergeProducer<T> implements Producer {
        static final AtomicLongFieldUpdater<MergeProducer> REQUESTED = AtomicLongFieldUpdater.newUpdater(MergeProducer.class, "requested");
        private final MergeSubscriber<T> ms;
        private volatile long requested = 0;

        public MergeProducer(MergeSubscriber<T> ms) {
            this.ms = ms;
        }

        public void request(long n) {
            if (this.requested != Long.MAX_VALUE) {
                if (n == Long.MAX_VALUE) {
                    this.requested = Long.MAX_VALUE;
                    return;
                }
                REQUESTED.getAndAdd(this, n);
                if (this.ms.drainQueuesIfNeeded()) {
                    boolean sendComplete = false;
                    synchronized (this.ms) {
                        if (this.ms.wip == 0 && this.ms.scalarValueQueue != null && this.ms.scalarValueQueue.isEmpty()) {
                            sendComplete = true;
                        }
                    }
                    if (sendComplete) {
                        this.ms.drainAndComplete();
                    }
                }
            }
        }
    }

    private static final class MergeSubscriber<T> extends Subscriber<Observable<? extends T>> {
        final Func1<InnerSubscriber<T>, Boolean> DRAIN_ACTION = new C28911();
        final Subscriber<? super T> actual;
        private volatile SubscriptionIndexedRingBuffer<InnerSubscriber<T>> childrenSubscribers;
        private boolean completed;
        private final boolean delayErrors;
        private boolean emitLock = false;
        private ConcurrentLinkedQueue<Throwable> exceptions;
        int lastDrainedIndex = 0;
        private final MergeProducer<T> mergeProducer;
        private int missedEmitting = 0;
        final NotificationLite<T> on = NotificationLite.instance();
        private RxRingBuffer scalarValueQueue = null;
        private int wip;

        class C28911 implements Func1<InnerSubscriber<T>, Boolean> {
            C28911() {
            }

            public Boolean call(InnerSubscriber<T> s) {
                if (s.f864q != null) {
                    long r = MergeSubscriber.this.mergeProducer.requested;
                    int emitted = s.drainQueue();
                    if (emitted > 0) {
                        s.requestMore((long) emitted);
                    }
                    if (((long) emitted) == r) {
                        return Boolean.FALSE;
                    }
                }
                return Boolean.TRUE;
            }
        }

        public MergeSubscriber(Subscriber<? super T> actual, boolean delayErrors) {
            super(actual);
            this.actual = actual;
            this.mergeProducer = new MergeProducer(this);
            this.delayErrors = delayErrors;
            actual.add(this);
            actual.setProducer(this.mergeProducer);
        }

        public void onStart() {
            request((long) RxRingBuffer.SIZE);
        }

        public void onNext(Observable<? extends T> t) {
            if (t instanceof ScalarSynchronousObservable) {
                handleScalarSynchronousObservable((ScalarSynchronousObservable) t);
            } else if (t != null && !isUnsubscribed()) {
                synchronized (this) {
                    this.wip++;
                }
                handleNewSource(t);
            }
        }

        private void handleNewSource(Observable<? extends T> t) {
            if (this.childrenSubscribers == null) {
                this.childrenSubscribers = new SubscriptionIndexedRingBuffer();
                add(this.childrenSubscribers);
            }
            MergeProducer<T> producerIfNeeded = null;
            if (this.mergeProducer.requested != Long.MAX_VALUE) {
                producerIfNeeded = this.mergeProducer;
            }
            InnerSubscriber<T> i = new InnerSubscriber(this, producerIfNeeded);
            i.sindex = this.childrenSubscribers.add(i);
            t.unsafeSubscribe(i);
            if (!isUnsubscribed()) {
                request(1);
            }
        }

        private void handleScalarSynchronousObservable(ScalarSynchronousObservable<? extends T> t) {
            if (this.mergeProducer.requested == Long.MAX_VALUE) {
                handleScalarSynchronousObservableWithoutRequestLimits(t);
            } else {
                handleScalarSynchronousObservableWithRequestLimits(t);
            }
        }

        private void handleScalarSynchronousObservableWithoutRequestLimits(ScalarSynchronousObservable<? extends T> t) {
            T value = t.get();
            if (getEmitLock()) {
                Object releaseEmitLock;
                try {
                    this.actual.onNext(value);
                    if (releaseEmitLock != null) {
                        drainQueuesIfNeeded();
                    }
                    request(1);
                } finally {
                    releaseEmitLock = releaseEmitLock();
                }
            } else {
                initScalarValueQueueIfNeeded();
                try {
                    this.scalarValueQueue.onNext(value);
                } catch (MissingBackpressureException e) {
                    onError(e);
                }
            }
        }

        private void handleScalarSynchronousObservableWithRequestLimits(ScalarSynchronousObservable<? extends T> t) {
            if (getEmitLock()) {
                boolean emitted = false;
                boolean isReturn = false;
                try {
                    if (this.mergeProducer.requested > 0) {
                        emitted = true;
                        this.actual.onNext(t.get());
                        MergeProducer.REQUESTED.decrementAndGet(this.mergeProducer);
                        isReturn = true;
                    }
                    if (releaseEmitLock()) {
                        drainQueuesIfNeeded();
                    }
                    if (emitted) {
                        request(1);
                    }
                    if (isReturn) {
                        return;
                    }
                } catch (Throwable th) {
                    boolean releaseEmitLock = releaseEmitLock();
                }
            }
            initScalarValueQueueIfNeeded();
            try {
                this.scalarValueQueue.onNext(t.get());
            } catch (MissingBackpressureException e) {
                onError(e);
            }
        }

        private void initScalarValueQueueIfNeeded() {
            if (this.scalarValueQueue == null) {
                this.scalarValueQueue = RxRingBuffer.getSpmcInstance();
                add(this.scalarValueQueue);
            }
        }

        private synchronized boolean releaseEmitLock() {
            boolean z = false;
            synchronized (this) {
                this.emitLock = false;
                if (this.missedEmitting != 0) {
                    z = true;
                }
            }
            return z;
        }

        private synchronized boolean getEmitLock() {
            boolean z = false;
            synchronized (this) {
                if (this.emitLock) {
                    this.missedEmitting++;
                } else {
                    this.emitLock = true;
                    this.missedEmitting = 0;
                    z = true;
                }
            }
            return z;
        }

        private boolean drainQueuesIfNeeded() {
            while (getEmitLock()) {
                int i = 0;
                boolean moreToDrain;
                try {
                    i = drainScalarValueQueue();
                    drainChildrenQueues();
                    if (i > 0) {
                        request((long) i);
                        continue;
                    }
                    if (!moreToDrain) {
                        return true;
                    }
                } finally {
                    moreToDrain = releaseEmitLock();
                }
            }
            return false;
        }

        private void drainChildrenQueues() {
            if (this.childrenSubscribers != null) {
                this.lastDrainedIndex = this.childrenSubscribers.forEach(this.DRAIN_ACTION, this.lastDrainedIndex);
            }
        }

        private int drainScalarValueQueue() {
            if (this.scalarValueQueue == null) {
                return 0;
            }
            long r = this.mergeProducer.requested;
            int emittedWhileDraining = 0;
            Object o;
            if (r < 0) {
                while (true) {
                    o = this.scalarValueQueue.poll();
                    if (o == null) {
                        return emittedWhileDraining;
                    }
                    this.on.accept(this.actual, o);
                    emittedWhileDraining++;
                }
            } else if (r <= 0) {
                return 0;
            } else {
                long toEmit = r;
                for (int i = 0; ((long) i) < toEmit; i++) {
                    o = this.scalarValueQueue.poll();
                    if (o == null) {
                        break;
                    }
                    this.on.accept(this.actual, o);
                    emittedWhileDraining++;
                }
                MergeProducer.REQUESTED.getAndAdd(this.mergeProducer, (long) (-emittedWhileDraining));
                return emittedWhileDraining;
            }
        }

        public void onError(Throwable e) {
            if (!this.completed) {
                this.completed = true;
                innerError(e, true);
            }
        }

        private void innerError(Throwable e, boolean parent) {
            if (this.delayErrors) {
                synchronized (this) {
                    if (this.exceptions == null) {
                        this.exceptions = new ConcurrentLinkedQueue();
                    }
                }
                this.exceptions.add(e);
                boolean sendOnComplete = false;
                synchronized (this) {
                    if (!parent) {
                        this.wip--;
                    }
                    if ((this.wip == 0 && this.completed) || this.wip < 0) {
                        sendOnComplete = true;
                    }
                }
                if (sendOnComplete) {
                    drainAndComplete();
                    return;
                }
                return;
            }
            this.actual.onError(e);
        }

        public void onCompleted() {
            boolean c = false;
            synchronized (this) {
                this.completed = true;
                if (this.wip == 0 && (this.scalarValueQueue == null || this.scalarValueQueue.isEmpty())) {
                    c = true;
                }
            }
            if (c) {
                drainAndComplete();
            }
        }

        void completeInner(InnerSubscriber<T> s) {
            boolean sendOnComplete = false;
            synchronized (this) {
                this.wip--;
                if (this.wip == 0 && this.completed) {
                    sendOnComplete = true;
                }
            }
            this.childrenSubscribers.remove(s.sindex);
            if (sendOnComplete) {
                drainAndComplete();
            }
        }

        private void drainAndComplete() {
            drainQueuesIfNeeded();
            if (this.delayErrors) {
                Queue<Throwable> es;
                synchronized (this) {
                    es = this.exceptions;
                }
                if (es == null) {
                    this.actual.onCompleted();
                    return;
                } else if (es.isEmpty()) {
                    this.actual.onCompleted();
                    return;
                } else if (es.size() == 1) {
                    this.actual.onError((Throwable) es.poll());
                    return;
                } else {
                    this.actual.onError(new CompositeException(es));
                    return;
                }
            }
            this.actual.onCompleted();
        }
    }

    public OperatorMerge() {
        this.delayErrors = false;
    }

    public OperatorMerge(boolean delayErrors) {
        this.delayErrors = delayErrors;
    }

    public Subscriber<Observable<? extends T>> call(Subscriber<? super T> child) {
        return new MergeSubscriber(child, this.delayErrors);
    }
}
