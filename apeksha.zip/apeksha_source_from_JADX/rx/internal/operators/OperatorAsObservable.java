package rx.internal.operators;

import rx.Observable.Operator;
import rx.Subscriber;

public final class OperatorAsObservable<T> implements Operator<T, T> {
    public Subscriber<? super T> call(Subscriber<? super T> s) {
        return s;
    }
}
