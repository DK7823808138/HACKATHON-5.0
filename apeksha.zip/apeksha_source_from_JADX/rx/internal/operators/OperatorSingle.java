package rx.internal.operators;

import java.util.NoSuchElementException;
import rx.Observable.Operator;
import rx.Subscriber;

public final class OperatorSingle<T> implements Operator<T, T> {
    private final T defaultValue;
    private final boolean hasDefaultValue;

    public OperatorSingle() {
        this(false, null);
    }

    public OperatorSingle(T defaultValue) {
        this(true, defaultValue);
    }

    private OperatorSingle(boolean hasDefaultValue, T defaultValue) {
        this.hasDefaultValue = hasDefaultValue;
        this.defaultValue = defaultValue;
    }

    public Subscriber<? super T> call(final Subscriber<? super T> subscriber) {
        return new Subscriber<T>(subscriber) {
            private boolean hasTooManyElements = false;
            private boolean isNonEmpty = false;
            private T value;

            public void onNext(T value) {
                if (this.isNonEmpty) {
                    this.hasTooManyElements = true;
                    subscriber.onError(new IllegalArgumentException("Sequence contains too many elements"));
                    unsubscribe();
                    return;
                }
                this.value = value;
                this.isNonEmpty = true;
                request(1);
            }

            public void onCompleted() {
                if (!this.hasTooManyElements) {
                    if (this.isNonEmpty) {
                        subscriber.onNext(this.value);
                        subscriber.onCompleted();
                    } else if (OperatorSingle.this.hasDefaultValue) {
                        subscriber.onNext(OperatorSingle.this.defaultValue);
                        subscriber.onCompleted();
                    } else {
                        subscriber.onError(new NoSuchElementException("Sequence contains no elements"));
                    }
                }
            }

            public void onError(Throwable e) {
                subscriber.onError(e);
            }
        };
    }
}
