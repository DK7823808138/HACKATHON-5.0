package rx.internal.operators;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import rx.Observable.Operator;
import rx.Subscriber;

public final class OperatorToObservableList<T> implements Operator<List<T>, T> {
    public Subscriber<? super T> call(final Subscriber<? super List<T>> o) {
        return new Subscriber<T>(o) {
            private boolean completed = false;
            final List<T> list = new LinkedList();

            public void onStart() {
                request(Long.MAX_VALUE);
            }

            public void onCompleted() {
                try {
                    this.completed = true;
                    o.onNext(new ArrayList(this.list));
                    o.onCompleted();
                } catch (Throwable e) {
                    onError(e);
                }
            }

            public void onError(Throwable e) {
                o.onError(e);
            }

            public void onNext(T value) {
                if (!this.completed) {
                    this.list.add(value);
                }
            }
        };
    }
}
