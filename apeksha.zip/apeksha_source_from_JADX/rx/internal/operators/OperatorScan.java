package rx.internal.operators;

import java.util.concurrent.atomic.AtomicBoolean;
import rx.Observable.Operator;
import rx.Producer;
import rx.Subscriber;
import rx.exceptions.OnErrorThrowable;
import rx.functions.Func0;
import rx.functions.Func2;

public final class OperatorScan<R, T> implements Operator<R, T> {
    private static final Object NO_INITIAL_VALUE = new Object();
    private final Func2<R, ? super T, R> accumulator;
    private final Func0<R> initialValueFactory;

    class C29261 implements Func0<R> {
        final /* synthetic */ Object val$initialValue;

        C29261(Object obj) {
            this.val$initialValue = obj;
        }

        public R call() {
            return this.val$initialValue;
        }
    }

    public OperatorScan(R initialValue, Func2<R, ? super T, R> accumulator) {
        this(new C29261(initialValue), (Func2) accumulator);
    }

    public OperatorScan(Func0<R> initialValueFactory, Func2<R, ? super T, R> accumulator) {
        this.initialValueFactory = initialValueFactory;
        this.accumulator = accumulator;
    }

    public OperatorScan(Func2<R, ? super T, R> accumulator) {
        this(NO_INITIAL_VALUE, (Func2) accumulator);
    }

    public Subscriber<? super T> call(final Subscriber<? super R> child) {
        return new Subscriber<T>(child) {
            private final R initialValue = OperatorScan.this.initialValueFactory.call();
            boolean initialized = false;
            private R value = this.initialValue;

            public void onNext(T currentValue) {
                emitInitialValueIfNeeded(child);
                if (this.value == OperatorScan.NO_INITIAL_VALUE) {
                    this.value = currentValue;
                } else {
                    try {
                        this.value = OperatorScan.this.accumulator.call(this.value, currentValue);
                    } catch (Throwable e) {
                        child.onError(OnErrorThrowable.addValueAsLastCause(e, currentValue));
                    }
                }
                child.onNext(this.value);
            }

            public void onError(Throwable e) {
                child.onError(e);
            }

            public void onCompleted() {
                emitInitialValueIfNeeded(child);
                child.onCompleted();
            }

            private void emitInitialValueIfNeeded(Subscriber<? super R> child) {
                if (!this.initialized) {
                    this.initialized = true;
                    if (this.initialValue != OperatorScan.NO_INITIAL_VALUE) {
                        child.onNext(this.initialValue);
                    }
                }
            }

            public void setProducer(final Producer producer) {
                child.setProducer(new Producer() {
                    final AtomicBoolean excessive = new AtomicBoolean();
                    final AtomicBoolean once = new AtomicBoolean();

                    public void request(long n) {
                        if (this.once.compareAndSet(false, true)) {
                            if (C29282.this.initialValue == OperatorScan.NO_INITIAL_VALUE || n == Long.MAX_VALUE) {
                                producer.request(n);
                            } else if (n == 1) {
                                this.excessive.set(true);
                                producer.request(1);
                            } else {
                                producer.request(n - 1);
                            }
                        } else if (n <= 1 || !this.excessive.compareAndSet(true, false) || n == Long.MAX_VALUE) {
                            producer.request(n);
                        } else {
                            producer.request(n - 1);
                        }
                    }
                });
            }
        };
    }
}
