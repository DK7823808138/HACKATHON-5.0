package rx.internal.operators;

import rx.Observable;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.functions.Action0;
import rx.functions.Action1;
import rx.functions.Func0;
import rx.functions.Func1;
import rx.subscriptions.Subscriptions;

public final class OnSubscribeUsing<T, Resource> implements OnSubscribe<T> {
    private final Action1<? super Resource> dispose;
    private final Func1<? super Resource, ? extends Observable<? extends T>> observableFactory;
    private final Func0<Resource> resourceFactory;

    public OnSubscribeUsing(Func0<Resource> resourceFactory, Func1<? super Resource, ? extends Observable<? extends T>> observableFactory, Action1<? super Resource> dispose) {
        this.resourceFactory = resourceFactory;
        this.observableFactory = observableFactory;
        this.dispose = dispose;
    }

    public void call(Subscriber<? super T> subscriber) {
        try {
            final Resource resource = this.resourceFactory.call();
            subscriber.add(Subscriptions.create(new Action0() {
                public void call() {
                    OnSubscribeUsing.this.dispose.call(resource);
                }
            }));
            ((Observable) this.observableFactory.call(resource)).subscribe((Subscriber) subscriber);
        } catch (Throwable e) {
            subscriber.unsubscribe();
            subscriber.onError(e);
        }
    }
}
