package rx.internal.operators;

import rx.Observable.Operator;
import rx.Subscriber;
import rx.functions.Func1;

public final class OperatorAny<T> implements Operator<Boolean, T> {
    private final Func1<? super T, Boolean> predicate;
    private final boolean returnOnEmpty;

    public OperatorAny(Func1<? super T, Boolean> predicate, boolean returnOnEmpty) {
        this.predicate = predicate;
        this.returnOnEmpty = returnOnEmpty;
    }

    public Subscriber<? super T> call(final Subscriber<? super Boolean> child) {
        Subscriber<T> s = new Subscriber<T>() {
            boolean done;
            boolean hasElements;

            public void onNext(T t) {
                this.hasElements = true;
                if (!((Boolean) OperatorAny.this.predicate.call(t)).booleanValue() || this.done) {
                    request(1);
                    return;
                }
                this.done = true;
                child.onNext(Boolean.valueOf(!OperatorAny.this.returnOnEmpty));
                child.onCompleted();
                unsubscribe();
            }

            public void onError(Throwable e) {
                child.onError(e);
            }

            public void onCompleted() {
                if (!this.done) {
                    this.done = true;
                    if (this.hasElements) {
                        child.onNext(Boolean.valueOf(false));
                    } else {
                        child.onNext(Boolean.valueOf(OperatorAny.this.returnOnEmpty));
                    }
                    child.onCompleted();
                }
            }
        };
        child.add(s);
        return s;
    }
}
