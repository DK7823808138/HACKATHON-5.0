package rx.internal.operators;

import java.util.Iterator;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import rx.Observable.OnSubscribe;
import rx.Producer;
import rx.Subscriber;

public final class OnSubscribeFromIterable<T> implements OnSubscribe<T> {
    final Iterable<? extends T> is;

    private static final class IterableProducer<T> implements Producer {
        private static final AtomicLongFieldUpdater<IterableProducer> REQUESTED_UPDATER = AtomicLongFieldUpdater.newUpdater(IterableProducer.class, "requested");
        private final Iterator<? extends T> it;
        private final Subscriber<? super T> f861o;
        private volatile long requested;

        private IterableProducer(Subscriber<? super T> o, Iterator<? extends T> it) {
            this.requested = 0;
            this.f861o = o;
            this.it = it;
        }

        public void request(long n) {
            if (REQUESTED_UPDATER.get(this) != Long.MAX_VALUE) {
                if (n == Long.MAX_VALUE) {
                    REQUESTED_UPDATER.set(this, n);
                    while (this.it.hasNext()) {
                        if (!this.f861o.isUnsubscribed()) {
                            this.f861o.onNext(this.it.next());
                        } else {
                            return;
                        }
                    }
                    if (!this.f861o.isUnsubscribed()) {
                        this.f861o.onCompleted();
                    }
                } else if (n > 0 && REQUESTED_UPDATER.getAndAdd(this, n) == 0) {
                    long r;
                    do {
                        r = this.requested;
                        long numToEmit = r;
                        while (this.it.hasNext()) {
                            numToEmit--;
                            if (numToEmit < 0) {
                                break;
                            } else if (!this.f861o.isUnsubscribed()) {
                                this.f861o.onNext(this.it.next());
                            } else {
                                return;
                            }
                        }
                        if (!this.it.hasNext()) {
                            if (!this.f861o.isUnsubscribed()) {
                                this.f861o.onCompleted();
                                return;
                            }
                            return;
                        }
                    } while (REQUESTED_UPDATER.addAndGet(this, -r) != 0);
                }
            }
        }
    }

    public OnSubscribeFromIterable(Iterable<? extends T> iterable) {
        if (iterable == null) {
            throw new NullPointerException("iterable must not be null");
        }
        this.is = iterable;
    }

    public void call(Subscriber<? super T> o) {
        o.setProducer(new IterableProducer(o, this.is.iterator()));
    }
}
