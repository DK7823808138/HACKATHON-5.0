package rx.internal.operators;

import rx.Observable.Operator;
import rx.Subscriber;
import rx.functions.Func1;

public final class OperatorDistinctUntilChanged<T, U> implements Operator<T, T> {
    final Func1<? super T, ? extends U> keySelector;

    public OperatorDistinctUntilChanged(Func1<? super T, ? extends U> keySelector) {
        this.keySelector = keySelector;
    }

    public Subscriber<? super T> call(final Subscriber<? super T> child) {
        return new Subscriber<T>(child) {
            boolean hasPrevious;
            U previousKey;

            public void onNext(T t) {
                U currentKey = this.previousKey;
                U key = OperatorDistinctUntilChanged.this.keySelector.call(t);
                this.previousKey = key;
                if (!this.hasPrevious) {
                    this.hasPrevious = true;
                    child.onNext(t);
                } else if (currentKey == key || (key != null && key.equals(currentKey))) {
                    request(1);
                } else {
                    child.onNext(t);
                }
            }

            public void onError(Throwable e) {
                child.onError(e);
            }

            public void onCompleted() {
                child.onCompleted();
            }
        };
    }
}
