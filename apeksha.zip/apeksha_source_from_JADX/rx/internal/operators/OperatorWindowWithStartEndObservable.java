package rx.internal.operators;

import java.util.LinkedList;
import java.util.List;
import rx.Observable;
import rx.Observable.Operator;
import rx.Observer;
import rx.Subscriber;
import rx.functions.Func1;
import rx.observers.SerializedObserver;
import rx.observers.SerializedSubscriber;
import rx.subscriptions.CompositeSubscription;

public final class OperatorWindowWithStartEndObservable<T, U, V> implements Operator<Observable<T>, T> {
    final Func1<? super U, ? extends Observable<? extends V>> windowClosingSelector;
    final Observable<? extends U> windowOpenings;

    static final class SerializedSubject<T> {
        final Observer<T> consumer;
        final Observable<T> producer;

        public SerializedSubject(Observer<T> consumer, Observable<T> producer) {
            this.consumer = new SerializedObserver(consumer);
            this.producer = producer;
        }
    }

    final class SourceSubscriber extends Subscriber<T> {
        final Subscriber<? super Observable<T>> child;
        final List<SerializedSubject<T>> chunks = new LinkedList();
        final CompositeSubscription csub = new CompositeSubscription();
        boolean done;
        final Object guard = new Object();

        public SourceSubscriber(Subscriber<? super Observable<T>> child) {
            super(child);
            this.child = new SerializedSubscriber(child);
            child.add(this.csub);
        }

        public void onStart() {
            request(Long.MAX_VALUE);
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onNext(T r5) {
            /*
            r4 = this;
            r3 = r4.guard;
            monitor-enter(r3);
            r2 = r4.done;	 Catch:{ all -> 0x0027 }
            if (r2 == 0) goto L_0x0009;
        L_0x0007:
            monitor-exit(r3);	 Catch:{ all -> 0x0027 }
        L_0x0008:
            return;
        L_0x0009:
            r1 = new java.util.ArrayList;	 Catch:{ all -> 0x0027 }
            r2 = r4.chunks;	 Catch:{ all -> 0x0027 }
            r1.<init>(r2);	 Catch:{ all -> 0x0027 }
            monitor-exit(r3);	 Catch:{ all -> 0x0027 }
            r2 = r1.iterator();
        L_0x0015:
            r3 = r2.hasNext();
            if (r3 == 0) goto L_0x0008;
        L_0x001b:
            r0 = r2.next();
            r0 = (rx.internal.operators.OperatorWindowWithStartEndObservable.SerializedSubject) r0;
            r3 = r0.consumer;
            r3.onNext(r5);
            goto L_0x0015;
        L_0x0027:
            r2 = move-exception;
            monitor-exit(r3);	 Catch:{ all -> 0x0027 }
            throw r2;
            */
            throw new UnsupportedOperationException("Method not decompiled: rx.internal.operators.OperatorWindowWithStartEndObservable.SourceSubscriber.onNext(java.lang.Object):void");
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onError(java.lang.Throwable r5) {
            /*
            r4 = this;
            r3 = r4.guard;
            monitor-enter(r3);
            r2 = r4.done;	 Catch:{ all -> 0x002f }
            if (r2 == 0) goto L_0x0009;
        L_0x0007:
            monitor-exit(r3);	 Catch:{ all -> 0x002f }
        L_0x0008:
            return;
        L_0x0009:
            r2 = 1;
            r4.done = r2;	 Catch:{ all -> 0x002f }
            r1 = new java.util.ArrayList;	 Catch:{ all -> 0x002f }
            r2 = r4.chunks;	 Catch:{ all -> 0x002f }
            r1.<init>(r2);	 Catch:{ all -> 0x002f }
            r2 = r4.chunks;	 Catch:{ all -> 0x002f }
            r2.clear();	 Catch:{ all -> 0x002f }
            monitor-exit(r3);	 Catch:{ all -> 0x002f }
            r2 = r1.iterator();
        L_0x001d:
            r3 = r2.hasNext();
            if (r3 == 0) goto L_0x0032;
        L_0x0023:
            r0 = r2.next();
            r0 = (rx.internal.operators.OperatorWindowWithStartEndObservable.SerializedSubject) r0;
            r3 = r0.consumer;
            r3.onError(r5);
            goto L_0x001d;
        L_0x002f:
            r2 = move-exception;
            monitor-exit(r3);	 Catch:{ all -> 0x002f }
            throw r2;
        L_0x0032:
            r2 = r4.child;
            r2.onError(r5);
            goto L_0x0008;
            */
            throw new UnsupportedOperationException("Method not decompiled: rx.internal.operators.OperatorWindowWithStartEndObservable.SourceSubscriber.onError(java.lang.Throwable):void");
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onCompleted() {
            /*
            r4 = this;
            r3 = r4.guard;
            monitor-enter(r3);
            r2 = r4.done;	 Catch:{ all -> 0x002f }
            if (r2 == 0) goto L_0x0009;
        L_0x0007:
            monitor-exit(r3);	 Catch:{ all -> 0x002f }
        L_0x0008:
            return;
        L_0x0009:
            r2 = 1;
            r4.done = r2;	 Catch:{ all -> 0x002f }
            r1 = new java.util.ArrayList;	 Catch:{ all -> 0x002f }
            r2 = r4.chunks;	 Catch:{ all -> 0x002f }
            r1.<init>(r2);	 Catch:{ all -> 0x002f }
            r2 = r4.chunks;	 Catch:{ all -> 0x002f }
            r2.clear();	 Catch:{ all -> 0x002f }
            monitor-exit(r3);	 Catch:{ all -> 0x002f }
            r2 = r1.iterator();
        L_0x001d:
            r3 = r2.hasNext();
            if (r3 == 0) goto L_0x0032;
        L_0x0023:
            r0 = r2.next();
            r0 = (rx.internal.operators.OperatorWindowWithStartEndObservable.SerializedSubject) r0;
            r3 = r0.consumer;
            r3.onCompleted();
            goto L_0x001d;
        L_0x002f:
            r2 = move-exception;
            monitor-exit(r3);	 Catch:{ all -> 0x002f }
            throw r2;
        L_0x0032:
            r2 = r4.child;
            r2.onCompleted();
            goto L_0x0008;
            */
            throw new UnsupportedOperationException("Method not decompiled: rx.internal.operators.OperatorWindowWithStartEndObservable.SourceSubscriber.onCompleted():void");
        }

        void beginWindow(U token) {
            final SerializedSubject<T> s = createSerializedSubject();
            synchronized (this.guard) {
                if (this.done) {
                    return;
                }
                this.chunks.add(s);
                this.child.onNext(s.producer);
                try {
                    Observable<? extends V> end = (Observable) OperatorWindowWithStartEndObservable.this.windowClosingSelector.call(token);
                    Subscriber<V> v = new Subscriber<V>() {
                        boolean once = true;

                        public void onNext(V v) {
                            onCompleted();
                        }

                        public void onError(Throwable e) {
                        }

                        public void onCompleted() {
                            if (this.once) {
                                this.once = false;
                                SourceSubscriber.this.endWindow(s);
                                SourceSubscriber.this.csub.remove(this);
                            }
                        }
                    };
                    this.csub.add(v);
                    end.unsafeSubscribe(v);
                } catch (Throwable e) {
                    onError(e);
                }
            }
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        void endWindow(rx.internal.operators.OperatorWindowWithStartEndObservable.SerializedSubject<T> r6) {
            /*
            r5 = this;
            r2 = 0;
            r4 = r5.guard;
            monitor-enter(r4);
            r3 = r5.done;	 Catch:{ all -> 0x002b }
            if (r3 == 0) goto L_0x000a;
        L_0x0008:
            monitor-exit(r4);	 Catch:{ all -> 0x002b }
        L_0x0009:
            return;
        L_0x000a:
            r3 = r5.chunks;	 Catch:{ all -> 0x002b }
            r0 = r3.iterator();	 Catch:{ all -> 0x002b }
        L_0x0010:
            r3 = r0.hasNext();	 Catch:{ all -> 0x002b }
            if (r3 == 0) goto L_0x0022;
        L_0x0016:
            r1 = r0.next();	 Catch:{ all -> 0x002b }
            r1 = (rx.internal.operators.OperatorWindowWithStartEndObservable.SerializedSubject) r1;	 Catch:{ all -> 0x002b }
            if (r1 != r6) goto L_0x0010;
        L_0x001e:
            r2 = 1;
            r0.remove();	 Catch:{ all -> 0x002b }
        L_0x0022:
            monitor-exit(r4);	 Catch:{ all -> 0x002b }
            if (r2 == 0) goto L_0x0009;
        L_0x0025:
            r3 = r6.consumer;
            r3.onCompleted();
            goto L_0x0009;
        L_0x002b:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x002b }
            throw r3;
            */
            throw new UnsupportedOperationException("Method not decompiled: rx.internal.operators.OperatorWindowWithStartEndObservable.SourceSubscriber.endWindow(rx.internal.operators.OperatorWindowWithStartEndObservable$SerializedSubject):void");
        }

        SerializedSubject<T> createSerializedSubject() {
            BufferUntilSubscriber<T> bus = BufferUntilSubscriber.create();
            return new SerializedSubject(bus, bus);
        }
    }

    public OperatorWindowWithStartEndObservable(Observable<? extends U> windowOpenings, Func1<? super U, ? extends Observable<? extends V>> windowClosingSelector) {
        this.windowOpenings = windowOpenings;
        this.windowClosingSelector = windowClosingSelector;
    }

    public Subscriber<? super T> call(Subscriber<? super Observable<T>> child) {
        final SourceSubscriber sub = new SourceSubscriber(child);
        this.windowOpenings.unsafeSubscribe(new Subscriber<U>(child) {
            public void onStart() {
                request(Long.MAX_VALUE);
            }

            public void onNext(U t) {
                sub.beginWindow(t);
            }

            public void onError(Throwable e) {
                sub.onError(e);
            }

            public void onCompleted() {
                sub.onCompleted();
            }
        });
        return sub;
    }
}
