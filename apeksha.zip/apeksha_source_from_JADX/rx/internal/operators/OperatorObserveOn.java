package rx.internal.operators;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import rx.Observable.Operator;
import rx.Producer;
import rx.Scheduler;
import rx.Scheduler.Worker;
import rx.Subscriber;
import rx.Subscription;
import rx.exceptions.MissingBackpressureException;
import rx.functions.Action0;
import rx.internal.util.RxRingBuffer;
import rx.schedulers.ImmediateScheduler;
import rx.schedulers.TrampolineScheduler;

public final class OperatorObserveOn<T> implements Operator<T, T> {
    private final Scheduler scheduler;

    private static final class ObserveOnSubscriber<T> extends Subscriber<T> {
        static final AtomicLongFieldUpdater<ObserveOnSubscriber> COUNTER_UPDATER = AtomicLongFieldUpdater.newUpdater(ObserveOnSubscriber.class, "counter");
        static final AtomicLongFieldUpdater<ObserveOnSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(ObserveOnSubscriber.class, "requested");
        final Subscriber<? super T> child;
        private boolean completed = false;
        volatile long counter;
        private boolean failure = false;
        final NotificationLite<T> on = NotificationLite.instance();
        private final RxRingBuffer queue = RxRingBuffer.getSpscInstance();
        private final Worker recursiveScheduler;
        private volatile long requested = 0;
        private final ScheduledUnsubscribe scheduledUnsubscribe;

        class C28961 implements Producer {
            C28961() {
            }

            public void request(long n) {
                ObserveOnSubscriber.REQUESTED.getAndAdd(ObserveOnSubscriber.this, n);
                ObserveOnSubscriber.this.schedule();
            }
        }

        class C28972 implements Action0 {
            C28972() {
            }

            public void call() {
                ObserveOnSubscriber.this.pollQueue();
            }
        }

        public ObserveOnSubscriber(Scheduler scheduler, Subscriber<? super T> child) {
            this.child = child;
            this.recursiveScheduler = scheduler.createWorker();
            this.scheduledUnsubscribe = new ScheduledUnsubscribe(this.recursiveScheduler, this.queue);
            child.add(this.scheduledUnsubscribe);
            child.setProducer(new C28961());
            child.add(this.recursiveScheduler);
            child.add(this);
        }

        public void onStart() {
            request((long) RxRingBuffer.SIZE);
        }

        public void onNext(T t) {
            if (!isUnsubscribed() && !this.completed) {
                try {
                    this.queue.onNext(t);
                    schedule();
                } catch (MissingBackpressureException e) {
                    onError(e);
                }
            }
        }

        public void onCompleted() {
            if (!isUnsubscribed() && !this.completed) {
                this.completed = true;
                this.queue.onCompleted();
                schedule();
            }
        }

        public void onError(Throwable e) {
            if (!isUnsubscribed() && !this.completed) {
                unsubscribe();
                this.completed = true;
                this.failure = true;
                this.queue.onError(e);
                schedule();
            }
        }

        protected void schedule() {
            if (COUNTER_UPDATER.getAndIncrement(this) == 0) {
                this.recursiveScheduler.schedule(new C28972());
            }
        }

        private void pollQueue() {
            int emitted = 0;
            do {
                COUNTER_UPDATER.set(this, 1);
                while (!this.scheduledUnsubscribe.isUnsubscribed()) {
                    Object o;
                    if (!this.failure) {
                        if (REQUESTED.getAndDecrement(this) == 0) {
                            REQUESTED.incrementAndGet(this);
                            break;
                        }
                        o = this.queue.poll();
                        if (o == null) {
                            REQUESTED.incrementAndGet(this);
                            break;
                        } else if (!this.on.accept(this.child, o)) {
                            emitted++;
                        }
                    } else {
                        o = this.queue.poll();
                        if (this.on.isError(o)) {
                            this.on.accept(this.child, o);
                            return;
                        }
                    }
                }
            } while (COUNTER_UPDATER.decrementAndGet(this) > 0);
            if (emitted > 0) {
                request((long) emitted);
            }
        }
    }

    static final class ScheduledUnsubscribe implements Subscription {
        static final AtomicIntegerFieldUpdater<ScheduledUnsubscribe> ONCE_UPDATER = AtomicIntegerFieldUpdater.newUpdater(ScheduledUnsubscribe.class, "once");
        volatile int once;
        final RxRingBuffer queue;
        volatile boolean unsubscribed = false;
        final Worker worker;

        class C28981 implements Action0 {
            C28981() {
            }

            public void call() {
                ScheduledUnsubscribe.this.worker.unsubscribe();
                ScheduledUnsubscribe.this.unsubscribed = true;
            }
        }

        public ScheduledUnsubscribe(Worker worker, RxRingBuffer queue) {
            this.worker = worker;
            this.queue = queue;
        }

        public boolean isUnsubscribed() {
            return this.unsubscribed;
        }

        public void unsubscribe() {
            if (ONCE_UPDATER.getAndSet(this, 1) == 0) {
                this.worker.schedule(new C28981());
            }
        }
    }

    public OperatorObserveOn(Scheduler scheduler) {
        this.scheduler = scheduler;
    }

    public Subscriber<? super T> call(Subscriber<? super T> child) {
        return ((this.scheduler instanceof ImmediateScheduler) || (this.scheduler instanceof TrampolineScheduler)) ? child : new ObserveOnSubscriber(this.scheduler, child);
    }
}
