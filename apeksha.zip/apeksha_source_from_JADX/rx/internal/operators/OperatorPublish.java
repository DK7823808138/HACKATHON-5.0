package rx.internal.operators;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import rx.Observable;
import rx.Observable.OnSubscribe;
import rx.Producer;
import rx.Subscriber;
import rx.Subscription;
import rx.exceptions.CompositeException;
import rx.exceptions.Exceptions;
import rx.exceptions.MissingBackpressureException;
import rx.functions.Action0;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.internal.util.RxRingBuffer;
import rx.observables.ConnectableObservable;
import rx.subscriptions.Subscriptions;

public class OperatorPublish<T> extends ConnectableObservable<T> {
    private final RequestHandler<T> requestHandler;
    final Observable<? extends T> source;

    class C29182 implements OnSubscribe<T> {
        final /* synthetic */ RequestHandler val$requestHandler;

        C29182(RequestHandler requestHandler) {
            this.val$requestHandler = requestHandler;
        }

        public void call(final Subscriber<? super T> subscriber) {
            subscriber.setProducer(new Producer() {
                public void request(long n) {
                    C29182.this.val$requestHandler.requestFromChildSubscriber(subscriber, Long.valueOf(n));
                }
            });
            subscriber.add(Subscriptions.create(new Action0() {
                public void call() {
                    C29182.this.val$requestHandler.state.removeSubscriber(subscriber);
                }
            }));
        }
    }

    class C29193 implements Action0 {
        C29193() {
        }

        public void call() {
            OriginSubscriber<T> s = OperatorPublish.this.requestHandler.state.getOrigin();
            OperatorPublish.this.requestHandler.state.setOrigin(null);
            if (s != null) {
                s.unsubscribe();
            }
        }
    }

    private static class OriginSubscriber<T> extends Subscriber<T> {
        private final long THRESHOLD = ((long) (RxRingBuffer.SIZE / 4));
        private final RxRingBuffer buffer = RxRingBuffer.getSpmcInstance();
        private final AtomicLong originOutstanding = new AtomicLong();
        private final RequestHandler<T> requestHandler;

        OriginSubscriber(RequestHandler<T> requestHandler) {
            this.requestHandler = requestHandler;
            add(this.buffer);
        }

        public void onStart() {
            requestMore((long) RxRingBuffer.SIZE);
        }

        private void requestMore(long r) {
            this.originOutstanding.addAndGet(r);
            request(r);
        }

        public void onCompleted() {
            try {
                this.requestHandler.emit(this.requestHandler.notifier.completed());
            } catch (MissingBackpressureException e) {
                onError(e);
            }
        }

        public void onError(Throwable e) {
            List<Throwable> errors = null;
            for (Subscriber<? super T> subscriber : this.requestHandler.state.getSubscribers()) {
                try {
                    subscriber.onError(e);
                } catch (Throwable e2) {
                    if (errors == null) {
                        errors = new ArrayList();
                    }
                    errors.add(e2);
                }
            }
            if (errors == null) {
                return;
            }
            if (errors.size() == 1) {
                Exceptions.propagate((Throwable) errors.get(0));
                return;
            }
            throw new CompositeException("Errors while emitting onError", errors);
        }

        public void onNext(T t) {
            try {
                this.requestHandler.emit(this.requestHandler.notifier.next(t));
            } catch (MissingBackpressureException e) {
                onError(e);
            }
        }
    }

    private static class RequestHandler<T> {
        static final AtomicLongFieldUpdater<RequestHandler> WIP = AtomicLongFieldUpdater.newUpdater(RequestHandler.class, "wip");
        private final NotificationLite<T> notifier;
        private final State<T> state;
        volatile long wip;

        private RequestHandler() {
            this.notifier = NotificationLite.instance();
            this.state = new State();
        }

        public void requestFromChildSubscriber(Subscriber<? super T> subscriber, Long request) {
            this.state.requestFromSubscriber(subscriber, request);
            OriginSubscriber<T> originSubscriber = this.state.getOrigin();
            if (originSubscriber != null) {
                drainQueue(originSubscriber);
            }
        }

        public void emit(Object t) throws MissingBackpressureException {
            OriginSubscriber<T> originSubscriber = this.state.getOrigin();
            if (originSubscriber != null) {
                if (this.notifier.isCompleted(t)) {
                    originSubscriber.buffer.onCompleted();
                } else {
                    originSubscriber.buffer.onNext(this.notifier.getValue(t));
                }
                drainQueue(originSubscriber);
            }
        }

        private void requestMoreAfterEmission(int emitted) {
            OriginSubscriber<T> origin = this.state.getOrigin();
            if (emitted > 0 && origin != null && origin.originOutstanding.addAndGet((long) (-emitted)) <= origin.THRESHOLD) {
                origin.requestMore(((long) RxRingBuffer.SIZE) - origin.THRESHOLD);
            }
        }

        public void drainQueue(OriginSubscriber<T> originSubscriber) {
            if (WIP.getAndIncrement(this) == 0) {
                int emitted = 0;
                do {
                    WIP.set(this, 1);
                    while (this.state.canEmitWithDecrement()) {
                        Object o = originSubscriber.buffer.poll();
                        if (o == null) {
                            this.state.incrementOutstandingAfterFailedEmit();
                            break;
                        }
                        if (this.notifier.isCompleted(o)) {
                            for (Subscriber<? super T> s : this.state.getSubscribers()) {
                                this.notifier.accept(s, o);
                            }
                        } else {
                            for (Subscriber<? super T> s2 : this.state.getSubscribers()) {
                                this.notifier.accept(s2, o);
                            }
                        }
                        emitted++;
                    }
                } while (WIP.decrementAndGet(this) > 0);
                requestMoreAfterEmission(emitted);
            }
        }
    }

    private static class State<T> {
        private long emittedSinceRequest;
        private OriginSubscriber<T> origin;
        private long outstandingRequests;
        private final Map<Subscriber<? super T>, AtomicLong> ss;
        private Subscriber<? super T>[] subscribers;

        private State() {
            this.outstandingRequests = -1;
            this.emittedSinceRequest = 0;
            this.ss = new LinkedHashMap();
            this.subscribers = new Subscriber[0];
        }

        public synchronized OriginSubscriber<T> getOrigin() {
            return this.origin;
        }

        public synchronized void setOrigin(OriginSubscriber<T> o) {
            this.origin = o;
        }

        public synchronized boolean canEmitWithDecrement() {
            boolean z;
            if (this.outstandingRequests > 0) {
                this.outstandingRequests--;
                this.emittedSinceRequest++;
                z = true;
            } else {
                z = false;
            }
            return z;
        }

        public synchronized void incrementOutstandingAfterFailedEmit() {
            this.outstandingRequests++;
            this.emittedSinceRequest--;
        }

        public synchronized Subscriber<? super T>[] getSubscribers() {
            return this.subscribers;
        }

        public synchronized long requestFromSubscriber(Subscriber<? super T> subscriber, Long request) {
            AtomicLong r = (AtomicLong) this.ss.get(subscriber);
            if (r == null) {
                this.ss.put(subscriber, new AtomicLong(request.longValue()));
            } else if (r.get() != Long.MAX_VALUE) {
                if (request.longValue() == Long.MAX_VALUE) {
                    r.set(Long.MAX_VALUE);
                } else {
                    r.addAndGet(request.longValue());
                }
            }
            return resetAfterSubscriberUpdate();
        }

        public synchronized void removeSubscriber(Subscriber<? super T> subscriber) {
            this.ss.remove(subscriber);
            resetAfterSubscriberUpdate();
        }

        private long resetAfterSubscriberUpdate() {
            this.subscribers = new Subscriber[this.ss.size()];
            int i = 0;
            for (Subscriber<? super T> s : this.ss.keySet()) {
                int i2 = i + 1;
                this.subscribers[i] = s;
                i = i2;
            }
            long lowest = -1;
            for (AtomicLong l : this.ss.values()) {
                long c = l.addAndGet(-this.emittedSinceRequest);
                if (lowest == -1 || c < lowest) {
                    lowest = c;
                }
            }
            this.outstandingRequests = lowest;
            this.emittedSinceRequest = 0;
            return this.outstandingRequests;
        }
    }

    public static <T> ConnectableObservable<T> create(Observable<? extends T> source) {
        return new OperatorPublish(source);
    }

    public static <T, R> Observable<R> create(final Observable<? extends T> source, final Func1<? super Observable<T>, ? extends Observable<R>> selector) {
        return Observable.create(new OnSubscribe<R>() {
            public void call(final Subscriber<? super R> child) {
                OperatorPublish<T> op = new OperatorPublish(source);
                ((Observable) selector.call(op)).unsafeSubscribe(child);
                op.connect(new Action1<Subscription>() {
                    public void call(Subscription sub) {
                        child.add(sub);
                    }
                });
            }
        });
    }

    private OperatorPublish(Observable<? extends T> source) {
        this(source, new Object(), new RequestHandler());
    }

    private OperatorPublish(Observable<? extends T> source, Object guard, RequestHandler<T> requestHandler) {
        super(new C29182(requestHandler));
        this.source = source;
        this.requestHandler = requestHandler;
    }

    public void connect(Action1<? super Subscription> connection) {
        boolean shouldSubscribe = false;
        if (this.requestHandler.state.getOrigin() == null) {
            shouldSubscribe = true;
            this.requestHandler.state.setOrigin(new OriginSubscriber(this.requestHandler));
        }
        if (shouldSubscribe) {
            connection.call(Subscriptions.create(new C29193()));
            OriginSubscriber<T> os = this.requestHandler.state.getOrigin();
            if (os != null) {
                this.source.unsafeSubscribe(os);
            }
        }
    }
}
