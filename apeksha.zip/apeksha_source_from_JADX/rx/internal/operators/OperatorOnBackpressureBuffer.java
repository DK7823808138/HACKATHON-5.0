package rx.internal.operators;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import rx.Observable.Operator;
import rx.Producer;
import rx.Subscriber;
import rx.exceptions.MissingBackpressureException;
import rx.functions.Action0;

public class OperatorOnBackpressureBuffer<T> implements Operator<T, T> {
    private final Long capacity;
    private final NotificationLite<T> on;
    private final Action0 onOverflow;

    public OperatorOnBackpressureBuffer() {
        this.on = NotificationLite.instance();
        this.capacity = null;
        this.onOverflow = null;
    }

    public OperatorOnBackpressureBuffer(long capacity) {
        this(capacity, null);
    }

    public OperatorOnBackpressureBuffer(long capacity, Action0 onOverflow) {
        this.on = NotificationLite.instance();
        if (capacity <= 0) {
            throw new IllegalArgumentException("Buffer capacity must be > 0");
        }
        this.capacity = Long.valueOf(capacity);
        this.onOverflow = onOverflow;
    }

    public Subscriber<? super T> call(Subscriber<? super T> child) {
        final ConcurrentLinkedQueue<Object> queue = new ConcurrentLinkedQueue();
        final AtomicLong capacity = this.capacity == null ? null : new AtomicLong(this.capacity.longValue());
        final AtomicLong wip = new AtomicLong();
        final AtomicLong requested = new AtomicLong();
        final Subscriber<? super T> subscriber = child;
        child.setProducer(new Producer() {
            public void request(long n) {
                if (requested.getAndAdd(n) == 0) {
                    OperatorOnBackpressureBuffer.this.pollQueue(wip, requested, capacity, queue, subscriber);
                }
            }
        });
        final ConcurrentLinkedQueue<Object> concurrentLinkedQueue = queue;
        final AtomicLong atomicLong = wip;
        final AtomicLong atomicLong2 = requested;
        final AtomicLong atomicLong3 = capacity;
        final Subscriber<? super T> subscriber2 = child;
        Subscriber<T> parent = new Subscriber<T>() {
            private AtomicBoolean saturated = new AtomicBoolean(false);

            public void onStart() {
                request(Long.MAX_VALUE);
            }

            public void onCompleted() {
                if (!this.saturated.get()) {
                    concurrentLinkedQueue.offer(OperatorOnBackpressureBuffer.this.on.completed());
                    OperatorOnBackpressureBuffer.this.pollQueue(atomicLong, atomicLong2, atomicLong3, concurrentLinkedQueue, subscriber2);
                }
            }

            public void onError(Throwable e) {
                if (!this.saturated.get()) {
                    concurrentLinkedQueue.offer(OperatorOnBackpressureBuffer.this.on.error(e));
                    OperatorOnBackpressureBuffer.this.pollQueue(atomicLong, atomicLong2, atomicLong3, concurrentLinkedQueue, subscriber2);
                }
            }

            public void onNext(T t) {
                if (assertCapacity()) {
                    concurrentLinkedQueue.offer(OperatorOnBackpressureBuffer.this.on.next(t));
                    OperatorOnBackpressureBuffer.this.pollQueue(atomicLong, atomicLong2, atomicLong3, concurrentLinkedQueue, subscriber2);
                }
            }

            private boolean assertCapacity() {
                if (atomicLong3 == null) {
                    return true;
                }
                long currCapacity;
                do {
                    currCapacity = atomicLong3.get();
                    if (currCapacity <= 0) {
                        if (this.saturated.compareAndSet(false, true)) {
                            unsubscribe();
                            subscriber2.onError(new MissingBackpressureException("Overflowed buffer of " + OperatorOnBackpressureBuffer.this.capacity));
                            if (OperatorOnBackpressureBuffer.this.onOverflow != null) {
                                OperatorOnBackpressureBuffer.this.onOverflow.call();
                            }
                        }
                        return false;
                    }
                } while (!atomicLong3.compareAndSet(currCapacity, currCapacity - 1));
                return true;
            }
        };
        child.add(parent);
        return parent;
    }

    private void pollQueue(AtomicLong wip, AtomicLong requested, AtomicLong capacity, Queue<Object> queue, Subscriber<? super T> child) {
        if (requested.get() > 0) {
            try {
                if (wip.getAndIncrement() == 0) {
                    while (requested.getAndDecrement() != 0) {
                        Object o = queue.poll();
                        if (o == null) {
                            requested.incrementAndGet();
                            return;
                        }
                        if (capacity != null) {
                            capacity.incrementAndGet();
                        }
                        this.on.accept(child, o);
                    }
                    requested.incrementAndGet();
                    wip.decrementAndGet();
                    return;
                }
                wip.decrementAndGet();
            } finally {
                wip.decrementAndGet();
            }
        }
    }
}
