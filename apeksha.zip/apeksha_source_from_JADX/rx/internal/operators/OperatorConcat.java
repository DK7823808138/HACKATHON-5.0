package rx.internal.operators;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import rx.Observable;
import rx.Observable.Operator;
import rx.Producer;
import rx.Subscriber;
import rx.functions.Action0;
import rx.observers.SerializedSubscriber;
import rx.subscriptions.SerialSubscription;
import rx.subscriptions.Subscriptions;

public final class OperatorConcat<T> implements Operator<T, Observable<? extends T>> {

    static class ConcatInnerSubscriber<T> extends Subscriber<T> {
        private static final AtomicIntegerFieldUpdater<ConcatInnerSubscriber> ONCE_UPDATER = AtomicIntegerFieldUpdater.newUpdater(ConcatInnerSubscriber.class, "once");
        private final Subscriber<T> child;
        private volatile int once = 0;
        private final ConcatSubscriber<T> parent;

        public ConcatInnerSubscriber(ConcatSubscriber<T> parent, Subscriber<T> child, long initialRequest) {
            this.parent = parent;
            this.child = child;
            request(initialRequest);
        }

        void requestMore(long n) {
            request(n);
        }

        public void onNext(T t) {
            this.parent.decrementRequested();
            this.child.onNext(t);
        }

        public void onError(Throwable e) {
            if (ONCE_UPDATER.compareAndSet(this, 0, 1)) {
                this.parent.onError(e);
            }
        }

        public void onCompleted() {
            if (ONCE_UPDATER.compareAndSet(this, 0, 1)) {
                this.parent.completeInner();
            }
        }
    }

    static final class ConcatProducer<T> implements Producer {
        final ConcatSubscriber<T> cs;

        ConcatProducer(ConcatSubscriber<T> cs) {
            this.cs = cs;
        }

        public void request(long n) {
            this.cs.requestFromChild(n);
        }
    }

    static final class ConcatSubscriber<T> extends Subscriber<Observable<? extends T>> {
        private static final AtomicLongFieldUpdater<ConcatSubscriber> REQUESTED_UPDATER = AtomicLongFieldUpdater.newUpdater(ConcatSubscriber.class, "requested");
        static final AtomicIntegerFieldUpdater<ConcatSubscriber> WIP_UPDATER = AtomicIntegerFieldUpdater.newUpdater(ConcatSubscriber.class, "wip");
        private final Subscriber<T> child;
        private final SerialSubscription current;
        volatile ConcatInnerSubscriber<T> currentSubscriber;
        final NotificationLite<Observable<? extends T>> nl = NotificationLite.instance();
        final ConcurrentLinkedQueue<Object> queue;
        private volatile long requested;
        volatile int wip;

        class C28581 implements Action0 {
            C28581() {
            }

            public void call() {
                ConcatSubscriber.this.queue.clear();
            }
        }

        public ConcatSubscriber(Subscriber<T> s, SerialSubscription current) {
            super(s);
            this.child = s;
            this.current = current;
            this.queue = new ConcurrentLinkedQueue();
            add(Subscriptions.create(new C28581()));
        }

        public void onStart() {
            request(2);
        }

        private void requestFromChild(long n) {
            if (REQUESTED_UPDATER.getAndAdd(this, n) == 0 && this.currentSubscriber == null && this.wip > 0) {
                subscribeNext();
            } else if (this.currentSubscriber != null) {
                this.currentSubscriber.requestMore(n);
            }
        }

        private void decrementRequested() {
            REQUESTED_UPDATER.decrementAndGet(this);
        }

        public void onNext(Observable<? extends T> t) {
            this.queue.add(this.nl.next(t));
            if (WIP_UPDATER.getAndIncrement(this) == 0) {
                subscribeNext();
            }
        }

        public void onError(Throwable e) {
            this.child.onError(e);
            unsubscribe();
        }

        public void onCompleted() {
            this.queue.add(this.nl.completed());
            if (WIP_UPDATER.getAndIncrement(this) == 0) {
                subscribeNext();
            }
        }

        void completeInner() {
            request(1);
            this.currentSubscriber = null;
            if (WIP_UPDATER.decrementAndGet(this) > 0) {
                subscribeNext();
            }
        }

        void subscribeNext() {
            if (this.requested > 0) {
                Object o = this.queue.poll();
                if (this.nl.isCompleted(o)) {
                    this.child.onCompleted();
                    return;
                } else if (o != null) {
                    Observable<? extends T> obs = (Observable) this.nl.getValue(o);
                    this.currentSubscriber = new ConcatInnerSubscriber(this, this.child, this.requested);
                    this.current.set(this.currentSubscriber);
                    obs.unsafeSubscribe(this.currentSubscriber);
                    return;
                } else {
                    return;
                }
            }
            if (this.nl.isCompleted(this.queue.peek())) {
                this.child.onCompleted();
            }
        }
    }

    public Subscriber<? super Observable<? extends T>> call(Subscriber<? super T> child) {
        SerializedSubscriber<T> s = new SerializedSubscriber(child);
        SerialSubscription current = new SerialSubscription();
        child.add(current);
        ConcatSubscriber<T> cs = new ConcatSubscriber(s, current);
        child.setProducer(new ConcatProducer(cs));
        return cs;
    }
}
