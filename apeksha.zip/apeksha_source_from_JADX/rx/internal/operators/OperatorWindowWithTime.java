package rx.internal.operators;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import rx.Observable;
import rx.Observable.Operator;
import rx.Observer;
import rx.Scheduler;
import rx.Scheduler.Worker;
import rx.Subscriber;
import rx.functions.Action0;
import rx.observers.SerializedObserver;
import rx.observers.SerializedSubscriber;

public final class OperatorWindowWithTime<T> implements Operator<Observable<T>, T> {
    static final Object NEXT_SUBJECT = new Object();
    static final NotificationLite<Object> nl = NotificationLite.instance();
    final Scheduler scheduler;
    final int size;
    final long timeshift;
    final long timespan;
    final TimeUnit unit;

    static final class CountedSerializedSubject<T> {
        final Observer<T> consumer;
        int count;
        final Observable<T> producer;

        public CountedSerializedSubject(Observer<T> consumer, Observable<T> producer) {
            this.consumer = new SerializedObserver(consumer);
            this.producer = producer;
        }
    }

    final class ExactSubscriber extends Subscriber<T> {
        final Subscriber<? super Observable<T>> child;
        boolean emitting;
        final Object guard = new Object();
        List<Object> queue;
        volatile State<T> state = State.empty();
        final Worker worker;

        class C29811 implements Action0 {
            C29811() {
            }

            public void call() {
                ExactSubscriber.this.nextWindow();
            }
        }

        public ExactSubscriber(Subscriber<? super Observable<T>> child, Worker worker) {
            super(child);
            this.child = new SerializedSubscriber(child);
            this.worker = worker;
        }

        public void onStart() {
            request(Long.MAX_VALUE);
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onNext(T r7) {
            /*
            r6 = this;
            r4 = r6.guard;
            monitor-enter(r4);
            r3 = r6.emitting;	 Catch:{ all -> 0x0049 }
            if (r3 == 0) goto L_0x0019;
        L_0x0007:
            r3 = r6.queue;	 Catch:{ all -> 0x0049 }
            if (r3 != 0) goto L_0x0012;
        L_0x000b:
            r3 = new java.util.ArrayList;	 Catch:{ all -> 0x0049 }
            r3.<init>();	 Catch:{ all -> 0x0049 }
            r6.queue = r3;	 Catch:{ all -> 0x0049 }
        L_0x0012:
            r3 = r6.queue;	 Catch:{ all -> 0x0049 }
            r3.add(r7);	 Catch:{ all -> 0x0049 }
            monitor-exit(r4);	 Catch:{ all -> 0x0049 }
        L_0x0018:
            return;
        L_0x0019:
            r0 = r6.queue;	 Catch:{ all -> 0x0049 }
            r3 = 0;
            r6.queue = r3;	 Catch:{ all -> 0x0049 }
            r3 = 1;
            r6.emitting = r3;	 Catch:{ all -> 0x0049 }
            monitor-exit(r4);	 Catch:{ all -> 0x0049 }
            r1 = 1;
            r2 = 0;
        L_0x0024:
            r6.drain(r0);	 Catch:{ all -> 0x0065 }
            if (r1 == 0) goto L_0x002d;
        L_0x0029:
            r1 = 0;
            r6.emitValue(r7);	 Catch:{ all -> 0x0065 }
        L_0x002d:
            r4 = r6.guard;	 Catch:{ all -> 0x0065 }
            monitor-enter(r4);	 Catch:{ all -> 0x0065 }
            r0 = r6.queue;	 Catch:{ all -> 0x0062 }
            r3 = 0;
            r6.queue = r3;	 Catch:{ all -> 0x0062 }
            if (r0 != 0) goto L_0x004c;
        L_0x0037:
            r3 = 0;
            r6.emitting = r3;	 Catch:{ all -> 0x0062 }
            r2 = 1;
            monitor-exit(r4);	 Catch:{ all -> 0x0062 }
            if (r2 != 0) goto L_0x0018;
        L_0x003e:
            r4 = r6.guard;
            monitor-enter(r4);
            r3 = 0;
            r6.emitting = r3;	 Catch:{ all -> 0x0046 }
            monitor-exit(r4);	 Catch:{ all -> 0x0046 }
            goto L_0x0018;
        L_0x0046:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x0046 }
            throw r3;
        L_0x0049:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x0049 }
            throw r3;
        L_0x004c:
            monitor-exit(r4);	 Catch:{ all -> 0x0062 }
            r3 = r6.child;	 Catch:{ all -> 0x0065 }
            r3 = r3.isUnsubscribed();	 Catch:{ all -> 0x0065 }
            if (r3 == 0) goto L_0x0024;
        L_0x0055:
            if (r2 != 0) goto L_0x0018;
        L_0x0057:
            r4 = r6.guard;
            monitor-enter(r4);
            r3 = 0;
            r6.emitting = r3;	 Catch:{ all -> 0x005f }
            monitor-exit(r4);	 Catch:{ all -> 0x005f }
            goto L_0x0018;
        L_0x005f:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x005f }
            throw r3;
        L_0x0062:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x0062 }
            throw r3;	 Catch:{ all -> 0x0065 }
        L_0x0065:
            r3 = move-exception;
            if (r2 != 0) goto L_0x006f;
        L_0x0068:
            r4 = r6.guard;
            monitor-enter(r4);
            r5 = 0;
            r6.emitting = r5;	 Catch:{ all -> 0x0070 }
            monitor-exit(r4);	 Catch:{ all -> 0x0070 }
        L_0x006f:
            throw r3;
        L_0x0070:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x0070 }
            throw r3;
            */
            throw new UnsupportedOperationException("Method not decompiled: rx.internal.operators.OperatorWindowWithTime.ExactSubscriber.onNext(java.lang.Object):void");
        }

        void drain(List<Object> queue) {
            if (queue != null) {
                for (T o : queue) {
                    if (o == OperatorWindowWithTime.NEXT_SUBJECT) {
                        replaceSubject();
                    } else if (OperatorWindowWithTime.nl.isError(o)) {
                        error(OperatorWindowWithTime.nl.getError(o));
                        return;
                    } else if (OperatorWindowWithTime.nl.isCompleted(o)) {
                        complete();
                        return;
                    } else {
                        emitValue(o);
                    }
                }
            }
        }

        void replaceSubject() {
            Observer<T> s = this.state.consumer;
            if (s != null) {
                s.onCompleted();
            }
            BufferUntilSubscriber<T> bus = BufferUntilSubscriber.create();
            this.state = this.state.create(bus, bus);
            this.child.onNext(bus);
        }

        void emitValue(T t) {
            State<T> s = this.state;
            if (s.consumer != null) {
                s.consumer.onNext(t);
                if (s.count == OperatorWindowWithTime.this.size) {
                    s.consumer.onCompleted();
                    s = s.clear();
                } else {
                    s = s.next();
                }
            }
            this.state = s;
        }

        public void onError(Throwable e) {
            synchronized (this.guard) {
                if (this.emitting) {
                    this.queue = Collections.singletonList(OperatorWindowWithTime.nl.error(e));
                    return;
                }
                this.queue = null;
                this.emitting = true;
                error(e);
            }
        }

        void error(Throwable e) {
            Observer<T> s = this.state.consumer;
            this.state = this.state.clear();
            if (s != null) {
                s.onError(e);
            }
            this.child.onError(e);
            unsubscribe();
        }

        void complete() {
            Observer<T> s = this.state.consumer;
            this.state = this.state.clear();
            if (s != null) {
                s.onCompleted();
            }
            this.child.onCompleted();
            unsubscribe();
        }

        public void onCompleted() {
            synchronized (this.guard) {
                if (this.emitting) {
                    if (this.queue == null) {
                        this.queue = new ArrayList();
                    }
                    this.queue.add(OperatorWindowWithTime.nl.completed());
                    return;
                }
                List<Object> localQueue = this.queue;
                this.queue = null;
                this.emitting = true;
                try {
                    drain(localQueue);
                    complete();
                } catch (Throwable e) {
                    error(e);
                }
            }
        }

        void scheduleExact() {
            this.worker.schedulePeriodically(new C29811(), 0, OperatorWindowWithTime.this.timespan, OperatorWindowWithTime.this.unit);
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        void nextWindow() {
            /*
            r6 = this;
            r4 = r6.guard;
            monitor-enter(r4);
            r3 = r6.emitting;	 Catch:{ all -> 0x004b }
            if (r3 == 0) goto L_0x001b;
        L_0x0007:
            r3 = r6.queue;	 Catch:{ all -> 0x004b }
            if (r3 != 0) goto L_0x0012;
        L_0x000b:
            r3 = new java.util.ArrayList;	 Catch:{ all -> 0x004b }
            r3.<init>();	 Catch:{ all -> 0x004b }
            r6.queue = r3;	 Catch:{ all -> 0x004b }
        L_0x0012:
            r3 = r6.queue;	 Catch:{ all -> 0x004b }
            r5 = rx.internal.operators.OperatorWindowWithTime.NEXT_SUBJECT;	 Catch:{ all -> 0x004b }
            r3.add(r5);	 Catch:{ all -> 0x004b }
            monitor-exit(r4);	 Catch:{ all -> 0x004b }
        L_0x001a:
            return;
        L_0x001b:
            r0 = r6.queue;	 Catch:{ all -> 0x004b }
            r3 = 0;
            r6.queue = r3;	 Catch:{ all -> 0x004b }
            r3 = 1;
            r6.emitting = r3;	 Catch:{ all -> 0x004b }
            monitor-exit(r4);	 Catch:{ all -> 0x004b }
            r1 = 1;
            r2 = 0;
        L_0x0026:
            r6.drain(r0);	 Catch:{ all -> 0x0067 }
            if (r1 == 0) goto L_0x002f;
        L_0x002b:
            r1 = 0;
            r6.replaceSubject();	 Catch:{ all -> 0x0067 }
        L_0x002f:
            r4 = r6.guard;	 Catch:{ all -> 0x0067 }
            monitor-enter(r4);	 Catch:{ all -> 0x0067 }
            r0 = r6.queue;	 Catch:{ all -> 0x0064 }
            r3 = 0;
            r6.queue = r3;	 Catch:{ all -> 0x0064 }
            if (r0 != 0) goto L_0x004e;
        L_0x0039:
            r3 = 0;
            r6.emitting = r3;	 Catch:{ all -> 0x0064 }
            r2 = 1;
            monitor-exit(r4);	 Catch:{ all -> 0x0064 }
            if (r2 != 0) goto L_0x001a;
        L_0x0040:
            r4 = r6.guard;
            monitor-enter(r4);
            r3 = 0;
            r6.emitting = r3;	 Catch:{ all -> 0x0048 }
            monitor-exit(r4);	 Catch:{ all -> 0x0048 }
            goto L_0x001a;
        L_0x0048:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x0048 }
            throw r3;
        L_0x004b:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x004b }
            throw r3;
        L_0x004e:
            monitor-exit(r4);	 Catch:{ all -> 0x0064 }
            r3 = r6.child;	 Catch:{ all -> 0x0067 }
            r3 = r3.isUnsubscribed();	 Catch:{ all -> 0x0067 }
            if (r3 == 0) goto L_0x0026;
        L_0x0057:
            if (r2 != 0) goto L_0x001a;
        L_0x0059:
            r4 = r6.guard;
            monitor-enter(r4);
            r3 = 0;
            r6.emitting = r3;	 Catch:{ all -> 0x0061 }
            monitor-exit(r4);	 Catch:{ all -> 0x0061 }
            goto L_0x001a;
        L_0x0061:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x0061 }
            throw r3;
        L_0x0064:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x0064 }
            throw r3;	 Catch:{ all -> 0x0067 }
        L_0x0067:
            r3 = move-exception;
            if (r2 != 0) goto L_0x0071;
        L_0x006a:
            r4 = r6.guard;
            monitor-enter(r4);
            r5 = 0;
            r6.emitting = r5;	 Catch:{ all -> 0x0072 }
            monitor-exit(r4);	 Catch:{ all -> 0x0072 }
        L_0x0071:
            throw r3;
        L_0x0072:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x0072 }
            throw r3;
            */
            throw new UnsupportedOperationException("Method not decompiled: rx.internal.operators.OperatorWindowWithTime.ExactSubscriber.nextWindow():void");
        }
    }

    final class InexactSubscriber extends Subscriber<T> {
        final Subscriber<? super Observable<T>> child;
        final List<CountedSerializedSubject<T>> chunks = new LinkedList();
        boolean done;
        final Object guard = new Object();
        final Worker worker;

        class C29821 implements Action0 {
            C29821() {
            }

            public void call() {
                InexactSubscriber.this.startNewChunk();
            }
        }

        public InexactSubscriber(Subscriber<? super Observable<T>> child, Worker worker) {
            super(child);
            this.child = child;
            this.worker = worker;
        }

        public void onStart() {
            request(Long.MAX_VALUE);
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onNext(T r7) {
            /*
            r6 = this;
            r4 = r6.guard;
            monitor-enter(r4);
            r3 = r6.done;	 Catch:{ all -> 0x0032 }
            if (r3 == 0) goto L_0x0009;
        L_0x0007:
            monitor-exit(r4);	 Catch:{ all -> 0x0032 }
        L_0x0008:
            return;
        L_0x0009:
            r2 = new java.util.ArrayList;	 Catch:{ all -> 0x0032 }
            r3 = r6.chunks;	 Catch:{ all -> 0x0032 }
            r2.<init>(r3);	 Catch:{ all -> 0x0032 }
            r3 = r6.chunks;	 Catch:{ all -> 0x0032 }
            r1 = r3.iterator();	 Catch:{ all -> 0x0032 }
        L_0x0016:
            r3 = r1.hasNext();	 Catch:{ all -> 0x0032 }
            if (r3 == 0) goto L_0x0035;
        L_0x001c:
            r0 = r1.next();	 Catch:{ all -> 0x0032 }
            r0 = (rx.internal.operators.OperatorWindowWithTime.CountedSerializedSubject) r0;	 Catch:{ all -> 0x0032 }
            r3 = r0.count;	 Catch:{ all -> 0x0032 }
            r3 = r3 + 1;
            r0.count = r3;	 Catch:{ all -> 0x0032 }
            r5 = rx.internal.operators.OperatorWindowWithTime.this;	 Catch:{ all -> 0x0032 }
            r5 = r5.size;	 Catch:{ all -> 0x0032 }
            if (r3 != r5) goto L_0x0016;
        L_0x002e:
            r1.remove();	 Catch:{ all -> 0x0032 }
            goto L_0x0016;
        L_0x0032:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x0032 }
            throw r3;
        L_0x0035:
            monitor-exit(r4);	 Catch:{ all -> 0x0032 }
            r3 = r2.iterator();
        L_0x003a:
            r4 = r3.hasNext();
            if (r4 == 0) goto L_0x0008;
        L_0x0040:
            r0 = r3.next();
            r0 = (rx.internal.operators.OperatorWindowWithTime.CountedSerializedSubject) r0;
            r4 = r0.consumer;
            r4.onNext(r7);
            r4 = r0.count;
            r5 = rx.internal.operators.OperatorWindowWithTime.this;
            r5 = r5.size;
            if (r4 != r5) goto L_0x003a;
        L_0x0053:
            r4 = r0.consumer;
            r4.onCompleted();
            goto L_0x003a;
            */
            throw new UnsupportedOperationException("Method not decompiled: rx.internal.operators.OperatorWindowWithTime.InexactSubscriber.onNext(java.lang.Object):void");
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onError(java.lang.Throwable r5) {
            /*
            r4 = this;
            r3 = r4.guard;
            monitor-enter(r3);
            r2 = r4.done;	 Catch:{ all -> 0x002f }
            if (r2 == 0) goto L_0x0009;
        L_0x0007:
            monitor-exit(r3);	 Catch:{ all -> 0x002f }
        L_0x0008:
            return;
        L_0x0009:
            r2 = 1;
            r4.done = r2;	 Catch:{ all -> 0x002f }
            r1 = new java.util.ArrayList;	 Catch:{ all -> 0x002f }
            r2 = r4.chunks;	 Catch:{ all -> 0x002f }
            r1.<init>(r2);	 Catch:{ all -> 0x002f }
            r2 = r4.chunks;	 Catch:{ all -> 0x002f }
            r2.clear();	 Catch:{ all -> 0x002f }
            monitor-exit(r3);	 Catch:{ all -> 0x002f }
            r2 = r1.iterator();
        L_0x001d:
            r3 = r2.hasNext();
            if (r3 == 0) goto L_0x0032;
        L_0x0023:
            r0 = r2.next();
            r0 = (rx.internal.operators.OperatorWindowWithTime.CountedSerializedSubject) r0;
            r3 = r0.consumer;
            r3.onError(r5);
            goto L_0x001d;
        L_0x002f:
            r2 = move-exception;
            monitor-exit(r3);	 Catch:{ all -> 0x002f }
            throw r2;
        L_0x0032:
            r2 = r4.child;
            r2.onError(r5);
            goto L_0x0008;
            */
            throw new UnsupportedOperationException("Method not decompiled: rx.internal.operators.OperatorWindowWithTime.InexactSubscriber.onError(java.lang.Throwable):void");
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onCompleted() {
            /*
            r4 = this;
            r3 = r4.guard;
            monitor-enter(r3);
            r2 = r4.done;	 Catch:{ all -> 0x002f }
            if (r2 == 0) goto L_0x0009;
        L_0x0007:
            monitor-exit(r3);	 Catch:{ all -> 0x002f }
        L_0x0008:
            return;
        L_0x0009:
            r2 = 1;
            r4.done = r2;	 Catch:{ all -> 0x002f }
            r1 = new java.util.ArrayList;	 Catch:{ all -> 0x002f }
            r2 = r4.chunks;	 Catch:{ all -> 0x002f }
            r1.<init>(r2);	 Catch:{ all -> 0x002f }
            r2 = r4.chunks;	 Catch:{ all -> 0x002f }
            r2.clear();	 Catch:{ all -> 0x002f }
            monitor-exit(r3);	 Catch:{ all -> 0x002f }
            r2 = r1.iterator();
        L_0x001d:
            r3 = r2.hasNext();
            if (r3 == 0) goto L_0x0032;
        L_0x0023:
            r0 = r2.next();
            r0 = (rx.internal.operators.OperatorWindowWithTime.CountedSerializedSubject) r0;
            r3 = r0.consumer;
            r3.onCompleted();
            goto L_0x001d;
        L_0x002f:
            r2 = move-exception;
            monitor-exit(r3);	 Catch:{ all -> 0x002f }
            throw r2;
        L_0x0032:
            r2 = r4.child;
            r2.onCompleted();
            goto L_0x0008;
            */
            throw new UnsupportedOperationException("Method not decompiled: rx.internal.operators.OperatorWindowWithTime.InexactSubscriber.onCompleted():void");
        }

        void scheduleChunk() {
            this.worker.schedulePeriodically(new C29821(), OperatorWindowWithTime.this.timeshift, OperatorWindowWithTime.this.timeshift, OperatorWindowWithTime.this.unit);
        }

        void startNewChunk() {
            final CountedSerializedSubject<T> chunk = createCountedSerializedSubject();
            synchronized (this.guard) {
                if (this.done) {
                    return;
                }
                this.chunks.add(chunk);
                try {
                    this.child.onNext(chunk.producer);
                    this.worker.schedule(new Action0() {
                        public void call() {
                            InexactSubscriber.this.terminateChunk(chunk);
                        }
                    }, OperatorWindowWithTime.this.timespan, OperatorWindowWithTime.this.unit);
                } catch (Throwable e) {
                    onError(e);
                }
            }
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        void terminateChunk(rx.internal.operators.OperatorWindowWithTime.CountedSerializedSubject<T> r6) {
            /*
            r5 = this;
            r2 = 0;
            r4 = r5.guard;
            monitor-enter(r4);
            r3 = r5.done;	 Catch:{ all -> 0x002b }
            if (r3 == 0) goto L_0x000a;
        L_0x0008:
            monitor-exit(r4);	 Catch:{ all -> 0x002b }
        L_0x0009:
            return;
        L_0x000a:
            r3 = r5.chunks;	 Catch:{ all -> 0x002b }
            r1 = r3.iterator();	 Catch:{ all -> 0x002b }
        L_0x0010:
            r3 = r1.hasNext();	 Catch:{ all -> 0x002b }
            if (r3 == 0) goto L_0x0022;
        L_0x0016:
            r0 = r1.next();	 Catch:{ all -> 0x002b }
            r0 = (rx.internal.operators.OperatorWindowWithTime.CountedSerializedSubject) r0;	 Catch:{ all -> 0x002b }
            if (r0 != r6) goto L_0x0010;
        L_0x001e:
            r2 = 1;
            r1.remove();	 Catch:{ all -> 0x002b }
        L_0x0022:
            monitor-exit(r4);	 Catch:{ all -> 0x002b }
            if (r2 == 0) goto L_0x0009;
        L_0x0025:
            r3 = r6.consumer;
            r3.onCompleted();
            goto L_0x0009;
        L_0x002b:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x002b }
            throw r3;
            */
            throw new UnsupportedOperationException("Method not decompiled: rx.internal.operators.OperatorWindowWithTime.InexactSubscriber.terminateChunk(rx.internal.operators.OperatorWindowWithTime$CountedSerializedSubject):void");
        }

        CountedSerializedSubject<T> createCountedSerializedSubject() {
            BufferUntilSubscriber<T> bus = BufferUntilSubscriber.create();
            return new CountedSerializedSubject(bus, bus);
        }
    }

    static final class State<T> {
        static final State<Object> EMPTY = new State(null, null, 0);
        final Observer<T> consumer;
        final int count;
        final Observable<T> producer;

        public State(Observer<T> consumer, Observable<T> producer, int count) {
            this.consumer = consumer;
            this.producer = producer;
            this.count = count;
        }

        public State<T> next() {
            return new State(this.consumer, this.producer, this.count + 1);
        }

        public State<T> create(Observer<T> consumer, Observable<T> producer) {
            return new State(consumer, producer, 0);
        }

        public State<T> clear() {
            return empty();
        }

        public static <T> State<T> empty() {
            return EMPTY;
        }
    }

    public OperatorWindowWithTime(long timespan, long timeshift, TimeUnit unit, int size, Scheduler scheduler) {
        this.timespan = timespan;
        this.timeshift = timeshift;
        this.unit = unit;
        this.size = size;
        this.scheduler = scheduler;
    }

    public Subscriber<? super T> call(Subscriber<? super Observable<T>> child) {
        Worker worker = this.scheduler.createWorker();
        child.add(worker);
        if (this.timespan == this.timeshift) {
            ExactSubscriber s = new ExactSubscriber(child, worker);
            s.scheduleExact();
            return s;
        }
        Subscriber s2 = new InexactSubscriber(child, worker);
        s2.startNewChunk();
        s2.scheduleChunk();
        return s2;
    }
}
