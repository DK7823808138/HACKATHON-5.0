package rx.internal.operators;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import rx.Observable.Operator;
import rx.Subscriber;
import rx.functions.Func2;

public final class OperatorToObservableSortedList<T> implements Operator<List<T>, T> {
    private static Func2 defaultSortFunction = new DefaultComparableFunction();
    private final Func2<? super T, ? super T, Integer> sortFunction;

    private static class DefaultComparableFunction implements Func2<Object, Object, Integer> {
        private DefaultComparableFunction() {
        }

        public Integer call(Object t1, Object t2) {
            return Integer.valueOf(((Comparable) t1).compareTo((Comparable) t2));
        }
    }

    public OperatorToObservableSortedList() {
        this.sortFunction = defaultSortFunction;
    }

    public OperatorToObservableSortedList(Func2<? super T, ? super T, Integer> sortFunction) {
        this.sortFunction = sortFunction;
    }

    public Subscriber<? super T> call(final Subscriber<? super List<T>> o) {
        return new Subscriber<T>(o) {
            final List<T> list = new ArrayList();

            class C29711 implements Comparator<T> {
                C29711() {
                }

                public int compare(T o1, T o2) {
                    return ((Integer) OperatorToObservableSortedList.this.sortFunction.call(o1, o2)).intValue();
                }
            }

            public void onStart() {
                request(Long.MAX_VALUE);
            }

            public void onCompleted() {
                try {
                    Collections.sort(this.list, new C29711());
                    o.onNext(Collections.unmodifiableList(this.list));
                    o.onCompleted();
                } catch (Throwable e) {
                    onError(e);
                }
            }

            public void onError(Throwable e) {
                o.onError(e);
            }

            public void onNext(T value) {
                this.list.add(value);
            }
        };
    }
}
