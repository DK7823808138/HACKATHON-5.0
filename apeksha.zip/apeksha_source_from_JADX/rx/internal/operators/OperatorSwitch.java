package rx.internal.operators;

import java.util.ArrayList;
import java.util.List;
import rx.Observable;
import rx.Observable.Operator;
import rx.Producer;
import rx.Subscriber;
import rx.observers.SerializedSubscriber;
import rx.subscriptions.SerialSubscription;

public final class OperatorSwitch<T> implements Operator<T, Observable<? extends T>> {

    private static final class SwitchSubscriber<T> extends Subscriber<Observable<? extends T>> {
        boolean active;
        InnerSubscriber currentSubscriber;
        boolean emitting;
        final Object guard = new Object();
        int index;
        volatile boolean infinite = false;
        long initialRequested;
        boolean mainDone;
        final NotificationLite<?> nl = NotificationLite.instance();
        List<Object> queue;
        final SerializedSubscriber<T> f866s;
        final SerialSubscription ssub;

        class C29481 implements Producer {
            C29481() {
            }

            public void request(long n) {
                if (!SwitchSubscriber.this.infinite) {
                    InnerSubscriber localSubscriber;
                    if (n == Long.MAX_VALUE) {
                        SwitchSubscriber.this.infinite = true;
                    }
                    synchronized (SwitchSubscriber.this.guard) {
                        localSubscriber = SwitchSubscriber.this.currentSubscriber;
                        if (SwitchSubscriber.this.currentSubscriber == null) {
                            SwitchSubscriber.this.initialRequested = n;
                        } else {
                            InnerSubscriber innerSubscriber = SwitchSubscriber.this.currentSubscriber;
                            innerSubscriber.requested = innerSubscriber.requested + n;
                        }
                    }
                    if (localSubscriber != null) {
                        localSubscriber.requestMore(n);
                    }
                }
            }
        }

        final class InnerSubscriber extends Subscriber<T> {
            private final int id;
            private final long initialRequested;
            private long requested = 0;

            public InnerSubscriber(int id, long initialRequested) {
                this.id = id;
                this.initialRequested = initialRequested;
            }

            public void onStart() {
                requestMore(this.initialRequested);
            }

            public void requestMore(long n) {
                request(n);
            }

            public void onNext(T t) {
                SwitchSubscriber.this.emit(t, this.id, this);
            }

            public void onError(Throwable e) {
                SwitchSubscriber.this.error(e, this.id);
            }

            public void onCompleted() {
                SwitchSubscriber.this.complete(this.id);
            }
        }

        public SwitchSubscriber(Subscriber<? super T> child) {
            super(child);
            this.f866s = new SerializedSubscriber(child);
            this.ssub = new SerialSubscription();
            child.add(this.ssub);
            child.setProducer(new C29481());
        }

        public void onNext(Observable<? extends T> t) {
            synchronized (this.guard) {
                long remainingRequest;
                int id = this.index + 1;
                this.index = id;
                this.active = true;
                if (this.infinite) {
                    remainingRequest = Long.MAX_VALUE;
                } else {
                    remainingRequest = this.currentSubscriber == null ? this.initialRequested : this.currentSubscriber.requested;
                }
                this.currentSubscriber = new InnerSubscriber(id, remainingRequest);
                this.currentSubscriber.requested = remainingRequest;
            }
            this.ssub.set(this.currentSubscriber);
            t.unsafeSubscribe(this.currentSubscriber);
        }

        public void onError(Throwable e) {
            this.f866s.onError(e);
            unsubscribe();
        }

        public void onCompleted() {
            synchronized (this.guard) {
                this.mainDone = true;
                if (this.active) {
                } else if (this.emitting) {
                    if (this.queue == null) {
                        this.queue = new ArrayList();
                    }
                    this.queue.add(this.nl.completed());
                } else {
                    List<Object> localQueue = this.queue;
                    this.queue = null;
                    this.emitting = true;
                    drain(localQueue);
                    this.f866s.onCompleted();
                    unsubscribe();
                }
            }
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        void emit(T r7, int r8, rx.internal.operators.OperatorSwitch.SwitchSubscriber.InnerSubscriber r9) {
            /*
            r6 = this;
            r4 = r6.guard;
            monitor-enter(r4);
            r3 = r6.index;	 Catch:{ all -> 0x0022 }
            if (r8 == r3) goto L_0x0009;
        L_0x0007:
            monitor-exit(r4);	 Catch:{ all -> 0x0022 }
        L_0x0008:
            return;
        L_0x0009:
            r3 = r6.emitting;	 Catch:{ all -> 0x0022 }
            if (r3 == 0) goto L_0x0025;
        L_0x000d:
            r3 = r6.queue;	 Catch:{ all -> 0x0022 }
            if (r3 != 0) goto L_0x0018;
        L_0x0011:
            r3 = new java.util.ArrayList;	 Catch:{ all -> 0x0022 }
            r3.<init>();	 Catch:{ all -> 0x0022 }
            r6.queue = r3;	 Catch:{ all -> 0x0022 }
        L_0x0018:
            r9.requested = r9.requested - 1;	 Catch:{ all -> 0x0022 }
            r3 = r6.queue;	 Catch:{ all -> 0x0022 }
            r3.add(r7);	 Catch:{ all -> 0x0022 }
            monitor-exit(r4);	 Catch:{ all -> 0x0022 }
            goto L_0x0008;
        L_0x0022:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x0022 }
            throw r3;
        L_0x0025:
            r0 = r6.queue;	 Catch:{ all -> 0x0022 }
            r3 = 0;
            r6.queue = r3;	 Catch:{ all -> 0x0022 }
            r3 = 1;
            r6.emitting = r3;	 Catch:{ all -> 0x0022 }
            monitor-exit(r4);	 Catch:{ all -> 0x0022 }
            r1 = 1;
            r2 = 0;
        L_0x0030:
            r6.drain(r0);	 Catch:{ all -> 0x0061 }
            if (r1 == 0) goto L_0x0042;
        L_0x0035:
            r1 = 0;
            r4 = r6.guard;	 Catch:{ all -> 0x0061 }
            monitor-enter(r4);	 Catch:{ all -> 0x0061 }
            r9.requested = r9.requested - 1;	 Catch:{ all -> 0x005e }
            monitor-exit(r4);	 Catch:{ all -> 0x005e }
            r3 = r6.f866s;	 Catch:{ all -> 0x0061 }
            r3.onNext(r7);	 Catch:{ all -> 0x0061 }
        L_0x0042:
            r4 = r6.guard;	 Catch:{ all -> 0x0061 }
            monitor-enter(r4);	 Catch:{ all -> 0x0061 }
            r0 = r6.queue;	 Catch:{ all -> 0x0076 }
            r3 = 0;
            r6.queue = r3;	 Catch:{ all -> 0x0076 }
            if (r0 != 0) goto L_0x006c;
        L_0x004c:
            r3 = 0;
            r6.emitting = r3;	 Catch:{ all -> 0x0076 }
            r2 = 1;
            monitor-exit(r4);	 Catch:{ all -> 0x0076 }
        L_0x0051:
            if (r2 != 0) goto L_0x0008;
        L_0x0053:
            r4 = r6.guard;
            monitor-enter(r4);
            r3 = 0;
            r6.emitting = r3;	 Catch:{ all -> 0x005b }
            monitor-exit(r4);	 Catch:{ all -> 0x005b }
            goto L_0x0008;
        L_0x005b:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x005b }
            throw r3;
        L_0x005e:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x005e }
            throw r3;	 Catch:{ all -> 0x0061 }
        L_0x0061:
            r3 = move-exception;
            if (r2 != 0) goto L_0x006b;
        L_0x0064:
            r4 = r6.guard;
            monitor-enter(r4);
            r5 = 0;
            r6.emitting = r5;	 Catch:{ all -> 0x0079 }
            monitor-exit(r4);	 Catch:{ all -> 0x0079 }
        L_0x006b:
            throw r3;
        L_0x006c:
            monitor-exit(r4);	 Catch:{ all -> 0x0076 }
            r3 = r6.f866s;	 Catch:{ all -> 0x0061 }
            r3 = r3.isUnsubscribed();	 Catch:{ all -> 0x0061 }
            if (r3 == 0) goto L_0x0030;
        L_0x0075:
            goto L_0x0051;
        L_0x0076:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x0076 }
            throw r3;	 Catch:{ all -> 0x0061 }
        L_0x0079:
            r3 = move-exception;
            monitor-exit(r4);	 Catch:{ all -> 0x0079 }
            throw r3;
            */
            throw new UnsupportedOperationException("Method not decompiled: rx.internal.operators.OperatorSwitch.SwitchSubscriber.emit(java.lang.Object, int, rx.internal.operators.OperatorSwitch$SwitchSubscriber$InnerSubscriber):void");
        }

        void drain(List<Object> localQueue) {
            if (localQueue != null) {
                for (T o : localQueue) {
                    if (this.nl.isCompleted(o)) {
                        this.f866s.onCompleted();
                        return;
                    } else if (this.nl.isError(o)) {
                        this.f866s.onError(this.nl.getError(o));
                        return;
                    } else {
                        this.f866s.onNext(o);
                    }
                }
            }
        }

        void error(Throwable e, int id) {
            synchronized (this.guard) {
                if (id != this.index) {
                } else if (this.emitting) {
                    if (this.queue == null) {
                        this.queue = new ArrayList();
                    }
                    this.queue.add(this.nl.error(e));
                } else {
                    List<Object> localQueue = this.queue;
                    this.queue = null;
                    this.emitting = true;
                    drain(localQueue);
                    this.f866s.onError(e);
                    unsubscribe();
                }
            }
        }

        void complete(int id) {
            synchronized (this.guard) {
                if (id != this.index) {
                    return;
                }
                this.active = false;
                if (!this.mainDone) {
                } else if (this.emitting) {
                    if (this.queue == null) {
                        this.queue = new ArrayList();
                    }
                    this.queue.add(this.nl.completed());
                } else {
                    List<Object> localQueue = this.queue;
                    this.queue = null;
                    this.emitting = true;
                    drain(localQueue);
                    this.f866s.onCompleted();
                    unsubscribe();
                }
            }
        }
    }

    public Subscriber<? super Observable<? extends T>> call(Subscriber<? super T> child) {
        return new SwitchSubscriber(child);
    }
}
