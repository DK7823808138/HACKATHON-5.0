package rx.internal.operators;

import rx.Notification;
import rx.Observable.Operator;
import rx.Subscriber;
import rx.plugins.RxJavaPlugins;

public final class OperatorMaterialize<T> implements Operator<Notification<T>, T> {
    public Subscriber<? super T> call(final Subscriber<? super Notification<T>> child) {
        return new Subscriber<T>(child) {
            public void onCompleted() {
                child.onNext(Notification.createOnCompleted());
                child.onCompleted();
            }

            public void onError(Throwable e) {
                RxJavaPlugins.getInstance().getErrorHandler().handleError(e);
                child.onNext(Notification.createOnError(e));
                child.onCompleted();
            }

            public void onNext(T t) {
                child.onNext(Notification.createOnNext(t));
            }
        };
    }
}
