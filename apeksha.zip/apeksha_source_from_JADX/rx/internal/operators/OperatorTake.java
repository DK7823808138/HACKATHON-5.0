package rx.internal.operators;

import rx.Observable.Operator;
import rx.Producer;
import rx.Subscriber;

public final class OperatorTake<T> implements Operator<T, T> {
    final int limit;

    public OperatorTake(int limit) {
        this.limit = limit;
    }

    public Subscriber<? super T> call(final Subscriber<? super T> child) {
        Subscriber<T> parent = new Subscriber<T>() {
            boolean completed = false;
            int count = 0;

            public void onCompleted() {
                if (!this.completed) {
                    child.onCompleted();
                }
            }

            public void onError(Throwable e) {
                if (!this.completed) {
                    child.onError(e);
                }
            }

            public void onNext(T i) {
                if (!isUnsubscribed()) {
                    int i2 = this.count + 1;
                    this.count = i2;
                    if (i2 >= OperatorTake.this.limit) {
                        this.completed = true;
                    }
                    child.onNext(i);
                    if (this.completed) {
                        child.onCompleted();
                        unsubscribe();
                    }
                }
            }

            public void setProducer(final Producer producer) {
                child.setProducer(new Producer() {
                    public void request(long n) {
                        if (!C29501.this.completed) {
                            long c = (long) (OperatorTake.this.limit - C29501.this.count);
                            if (n < c) {
                                producer.request(n);
                            } else {
                                producer.request(c);
                            }
                        }
                    }
                });
            }
        };
        if (this.limit == 0) {
            child.onCompleted();
            parent.unsubscribe();
        }
        child.add(parent);
        return parent;
    }
}
