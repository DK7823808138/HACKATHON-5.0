package rx.internal.operators;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import rx.Observable;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Action0;
import rx.functions.Func0;
import rx.observables.ConnectableObservable;
import rx.subjects.Subject;

public final class OperatorMulticast<T, R> extends ConnectableObservable<R> {
    private final AtomicReference<Subject<? super T, ? extends R>> connectedSubject;
    final Object guard;
    final Observable<? extends T> source;
    final Func0<? extends Subject<? super T, ? extends R>> subjectFactory;
    Subscriber<T> subscription;
    private final List<Subscriber<? super R>> waitingForConnect;

    class C28931 implements OnSubscribe<R> {
        final /* synthetic */ AtomicReference val$connectedSubject;
        final /* synthetic */ Object val$guard;
        final /* synthetic */ List val$waitingForConnect;

        C28931(Object obj, AtomicReference atomicReference, List list) {
            this.val$guard = obj;
            this.val$connectedSubject = atomicReference;
            this.val$waitingForConnect = list;
        }

        public void call(Subscriber<? super R> subscriber) {
            synchronized (this.val$guard) {
                if (this.val$connectedSubject.get() == null) {
                    this.val$waitingForConnect.add(subscriber);
                } else {
                    ((Subject) this.val$connectedSubject.get()).unsafeSubscribe(subscriber);
                }
            }
        }
    }

    class C28953 implements Action0 {
        C28953() {
        }

        public void call() {
            synchronized (OperatorMulticast.this.guard) {
                Subscription s = OperatorMulticast.this.subscription;
                OperatorMulticast.this.subscription = null;
                OperatorMulticast.this.connectedSubject.set(null);
            }
            if (s != null) {
                s.unsubscribe();
            }
        }
    }

    public OperatorMulticast(Observable<? extends T> source, Func0<? extends Subject<? super T, ? extends R>> subjectFactory) {
        this(new Object(), new AtomicReference(), new ArrayList(), source, subjectFactory);
    }

    private OperatorMulticast(Object guard, AtomicReference<Subject<? super T, ? extends R>> connectedSubject, List<Subscriber<? super R>> waitingForConnect, Observable<? extends T> source, Func0<? extends Subject<? super T, ? extends R>> subjectFactory) {
        super(new C28931(guard, connectedSubject, waitingForConnect));
        this.guard = guard;
        this.connectedSubject = connectedSubject;
        this.waitingForConnect = waitingForConnect;
        this.source = source;
        this.subjectFactory = subjectFactory;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void connect(rx.functions.Action1<? super rx.Subscription> r8) {
        /*
        r7 = this;
        r1 = 0;
        r5 = r7.guard;
        monitor-enter(r5);
        r4 = r7.subscription;	 Catch:{ all -> 0x0030 }
        if (r4 == 0) goto L_0x000a;
    L_0x0008:
        monitor-exit(r5);	 Catch:{ all -> 0x0030 }
    L_0x0009:
        return;
    L_0x000a:
        r1 = 1;
        r4 = r7.subjectFactory;	 Catch:{ all -> 0x0030 }
        r2 = r4.call();	 Catch:{ all -> 0x0030 }
        r2 = (rx.subjects.Subject) r2;	 Catch:{ all -> 0x0030 }
        r4 = new rx.internal.operators.OperatorMulticast$2;	 Catch:{ all -> 0x0030 }
        r4.<init>(r2);	 Catch:{ all -> 0x0030 }
        r7.subscription = r4;	 Catch:{ all -> 0x0030 }
        r4 = r7.waitingForConnect;	 Catch:{ all -> 0x0030 }
        r4 = r4.iterator();	 Catch:{ all -> 0x0030 }
    L_0x0020:
        r6 = r4.hasNext();	 Catch:{ all -> 0x0030 }
        if (r6 == 0) goto L_0x0033;
    L_0x0026:
        r0 = r4.next();	 Catch:{ all -> 0x0030 }
        r0 = (rx.Subscriber) r0;	 Catch:{ all -> 0x0030 }
        r2.unsafeSubscribe(r0);	 Catch:{ all -> 0x0030 }
        goto L_0x0020;
    L_0x0030:
        r4 = move-exception;
        monitor-exit(r5);	 Catch:{ all -> 0x0030 }
        throw r4;
    L_0x0033:
        r4 = r7.waitingForConnect;	 Catch:{ all -> 0x0030 }
        r4.clear();	 Catch:{ all -> 0x0030 }
        r4 = r7.connectedSubject;	 Catch:{ all -> 0x0030 }
        r4.set(r2);	 Catch:{ all -> 0x0030 }
        monitor-exit(r5);	 Catch:{ all -> 0x0030 }
        if (r1 == 0) goto L_0x0009;
    L_0x0040:
        r4 = new rx.internal.operators.OperatorMulticast$3;
        r4.<init>();
        r4 = rx.subscriptions.Subscriptions.create(r4);
        r8.call(r4);
        r5 = r7.guard;
        monitor-enter(r5);
        r4 = r7.subscription;	 Catch:{ all -> 0x0061 }
        if (r4 != 0) goto L_0x005f;
    L_0x0053:
        r3 = 1;
    L_0x0054:
        monitor-exit(r5);	 Catch:{ all -> 0x0061 }
        if (r3 != 0) goto L_0x0009;
    L_0x0057:
        r4 = r7.source;
        r5 = r7.subscription;
        r4.unsafeSubscribe(r5);
        goto L_0x0009;
    L_0x005f:
        r3 = 0;
        goto L_0x0054;
    L_0x0061:
        r4 = move-exception;
        monitor-exit(r5);	 Catch:{ all -> 0x0061 }
        throw r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: rx.internal.operators.OperatorMulticast.connect(rx.functions.Action1):void");
    }
}
