package rx.internal.operators;

import rx.Observable;
import rx.Observable.OnSubscribe;
import rx.Scheduler;
import rx.Subscriber;
import rx.subjects.Subject;

public final class OperatorReplay {

    public static final class SubjectWrapper<T> extends Subject<T, T> {
        final Subject<T, T> subject;

        public SubjectWrapper(OnSubscribe<T> func, Subject<T, T> subject) {
            super(func);
            this.subject = subject;
        }

        public void onNext(T args) {
            this.subject.onNext(args);
        }

        public void onError(Throwable e) {
            this.subject.onError(e);
        }

        public void onCompleted() {
            this.subject.onCompleted();
        }

        public boolean hasObservers() {
            return this.subject.hasObservers();
        }
    }

    private OperatorReplay() {
        throw new IllegalStateException("No instances!");
    }

    public static <T> Subject<T, T> createScheduledSubject(Subject<T, T> subject, Scheduler scheduler) {
        final Observable<T> observedOn = subject.observeOn(scheduler);
        return new SubjectWrapper(new OnSubscribe<T>() {
            public void call(Subscriber<? super T> o) {
                OperatorReplay.subscriberOf(observedOn).call(o);
            }
        }, subject);
    }

    public static <T> OnSubscribe<T> subscriberOf(final Observable<T> target) {
        return new OnSubscribe<T>() {
            public void call(Subscriber<? super T> t1) {
                target.unsafeSubscribe(t1);
            }
        };
    }
}
