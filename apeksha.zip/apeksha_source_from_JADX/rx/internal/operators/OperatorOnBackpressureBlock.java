package rx.internal.operators;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import rx.Observable.Operator;
import rx.Producer;
import rx.Subscriber;

public class OperatorOnBackpressureBlock<T> implements Operator<T, T> {
    final int max;

    static final class BlockingSubscriber<T> extends Subscriber<T> {
        final Subscriber<? super T> child;
        boolean emitting;
        Throwable exception;
        final NotificationLite<T> nl = NotificationLite.instance();
        final BlockingQueue<Object> queue;
        long requestedCount;
        volatile boolean terminated;

        class C28991 implements Producer {
            C28991() {
            }

            public void request(long n) {
                synchronized (BlockingSubscriber.this) {
                    if (n != Long.MAX_VALUE) {
                        if (BlockingSubscriber.this.requestedCount != Long.MAX_VALUE) {
                            BlockingSubscriber blockingSubscriber = BlockingSubscriber.this;
                            blockingSubscriber.requestedCount += n;
                        }
                    }
                    BlockingSubscriber.this.requestedCount = Long.MAX_VALUE;
                }
                BlockingSubscriber.this.drain();
            }
        }

        public BlockingSubscriber(int max, Subscriber<? super T> child) {
            this.queue = new ArrayBlockingQueue(max);
            this.child = child;
        }

        void init() {
            this.child.add(this);
            this.child.setProducer(new C28991());
        }

        public void onNext(T t) {
            try {
                this.queue.put(this.nl.next(t));
                drain();
            } catch (InterruptedException ex) {
                if (!isUnsubscribed()) {
                    onError(ex);
                }
            }
        }

        public void onError(Throwable e) {
            if (!this.terminated) {
                this.exception = e;
                this.terminated = true;
                drain();
            }
        }

        public void onCompleted() {
            this.terminated = true;
            drain();
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        void drain() {
            /*
            r10 = this;
            monitor-enter(r10);
            r5 = r10.emitting;	 Catch:{ all -> 0x0037 }
            if (r5 == 0) goto L_0x0007;
        L_0x0005:
            monitor-exit(r10);	 Catch:{ all -> 0x0037 }
        L_0x0006:
            return;
        L_0x0007:
            r5 = 1;
            r10.emitting = r5;	 Catch:{ all -> 0x0037 }
            r2 = r10.requestedCount;	 Catch:{ all -> 0x0037 }
            monitor-exit(r10);	 Catch:{ all -> 0x0037 }
            r4 = 0;
        L_0x000e:
            r0 = 0;
        L_0x000f:
            r6 = 0;
            r5 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1));
            if (r5 <= 0) goto L_0x005a;
        L_0x0015:
            r5 = r10.queue;	 Catch:{ all -> 0x0040 }
            r1 = r5.poll();	 Catch:{ all -> 0x0040 }
            if (r1 != 0) goto L_0x0049;
        L_0x001d:
            r5 = r10.terminated;	 Catch:{ all -> 0x0040 }
            if (r5 == 0) goto L_0x005a;
        L_0x0021:
            r5 = r10.exception;	 Catch:{ all -> 0x0040 }
            if (r5 == 0) goto L_0x003a;
        L_0x0025:
            r5 = r10.child;	 Catch:{ all -> 0x0040 }
            r6 = r10.exception;	 Catch:{ all -> 0x0040 }
            r5.onError(r6);	 Catch:{ all -> 0x0040 }
        L_0x002c:
            if (r4 != 0) goto L_0x0006;
        L_0x002e:
            monitor-enter(r10);
            r5 = 0;
            r10.emitting = r5;	 Catch:{ all -> 0x0034 }
            monitor-exit(r10);	 Catch:{ all -> 0x0034 }
            goto L_0x0006;
        L_0x0034:
            r5 = move-exception;
            monitor-exit(r10);	 Catch:{ all -> 0x0034 }
            throw r5;
        L_0x0037:
            r5 = move-exception;
            monitor-exit(r10);	 Catch:{ all -> 0x0037 }
            throw r5;
        L_0x003a:
            r5 = r10.child;	 Catch:{ all -> 0x0040 }
            r5.onCompleted();	 Catch:{ all -> 0x0040 }
            goto L_0x002c;
        L_0x0040:
            r5 = move-exception;
            if (r4 != 0) goto L_0x0048;
        L_0x0043:
            monitor-enter(r10);
            r6 = 0;
            r10.emitting = r6;	 Catch:{ all -> 0x00a4 }
            monitor-exit(r10);	 Catch:{ all -> 0x00a4 }
        L_0x0048:
            throw r5;
        L_0x0049:
            r5 = r10.child;	 Catch:{ all -> 0x0040 }
            r6 = r10.nl;	 Catch:{ all -> 0x0040 }
            r6 = r6.getValue(r1);	 Catch:{ all -> 0x0040 }
            r5.onNext(r6);	 Catch:{ all -> 0x0040 }
            r6 = 1;
            r2 = r2 - r6;
            r0 = r0 + 1;
            goto L_0x000f;
        L_0x005a:
            monitor-enter(r10);	 Catch:{ all -> 0x0040 }
            r6 = r10.requestedCount;	 Catch:{ all -> 0x0085 }
            r8 = 9223372036854775807; // 0x7fffffffffffffff float:NaN double:NaN;
            r5 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1));
            if (r5 != 0) goto L_0x0088;
        L_0x0066:
            r5 = r10.queue;	 Catch:{ all -> 0x0085 }
            r5 = r5.peek();	 Catch:{ all -> 0x0085 }
            if (r5 != 0) goto L_0x007e;
        L_0x006e:
            r4 = 1;
            r5 = 0;
            r10.emitting = r5;	 Catch:{ all -> 0x0085 }
            monitor-exit(r10);	 Catch:{ all -> 0x0085 }
            if (r4 != 0) goto L_0x0006;
        L_0x0075:
            monitor-enter(r10);
            r5 = 0;
            r10.emitting = r5;	 Catch:{ all -> 0x007b }
            monitor-exit(r10);	 Catch:{ all -> 0x007b }
            goto L_0x0006;
        L_0x007b:
            r5 = move-exception;
            monitor-exit(r10);	 Catch:{ all -> 0x007b }
            throw r5;
        L_0x007e:
            r2 = 9223372036854775807; // 0x7fffffffffffffff float:NaN double:NaN;
        L_0x0083:
            monitor-exit(r10);	 Catch:{ all -> 0x0085 }
            goto L_0x000e;
        L_0x0085:
            r5 = move-exception;
            monitor-exit(r10);	 Catch:{ all -> 0x0085 }
            throw r5;	 Catch:{ all -> 0x0040 }
        L_0x0088:
            if (r0 != 0) goto L_0x009b;
        L_0x008a:
            r4 = 1;
            r5 = 0;
            r10.emitting = r5;	 Catch:{ all -> 0x0085 }
            monitor-exit(r10);	 Catch:{ all -> 0x0085 }
            if (r4 != 0) goto L_0x0006;
        L_0x0091:
            monitor-enter(r10);
            r5 = 0;
            r10.emitting = r5;	 Catch:{ all -> 0x0098 }
            monitor-exit(r10);	 Catch:{ all -> 0x0098 }
            goto L_0x0006;
        L_0x0098:
            r5 = move-exception;
            monitor-exit(r10);	 Catch:{ all -> 0x0098 }
            throw r5;
        L_0x009b:
            r6 = r10.requestedCount;	 Catch:{ all -> 0x0085 }
            r8 = (long) r0;	 Catch:{ all -> 0x0085 }
            r6 = r6 - r8;
            r10.requestedCount = r6;	 Catch:{ all -> 0x0085 }
            r2 = r10.requestedCount;	 Catch:{ all -> 0x0085 }
            goto L_0x0083;
        L_0x00a4:
            r5 = move-exception;
            monitor-exit(r10);	 Catch:{ all -> 0x00a4 }
            throw r5;
            */
            throw new UnsupportedOperationException("Method not decompiled: rx.internal.operators.OperatorOnBackpressureBlock.BlockingSubscriber.drain():void");
        }
    }

    public OperatorOnBackpressureBlock(int max) {
        this.max = max;
    }

    public Subscriber<? super T> call(Subscriber<? super T> child) {
        BlockingSubscriber<T> s = new BlockingSubscriber(this.max, child);
        s.init();
        return s;
    }
}
