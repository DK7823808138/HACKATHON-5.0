package rx.internal.operators;

import rx.Observable;
import rx.Observable.Operator;
import rx.Subscriber;
import rx.exceptions.OnErrorThrowable;
import rx.functions.Func1;
import rx.plugins.RxJavaPlugins;

public final class OperatorOnErrorFlatMap<T> implements Operator<T, T> {
    private final Func1<OnErrorThrowable, ? extends Observable<? extends T>> resumeFunction;

    public OperatorOnErrorFlatMap(Func1<OnErrorThrowable, ? extends Observable<? extends T>> f) {
        this.resumeFunction = f;
    }

    public Subscriber<? super T> call(final Subscriber<? super T> child) {
        return new Subscriber<T>(child) {

            class C29041 extends Subscriber<T> {
                C29041() {
                }

                public void onCompleted() {
                }

                public void onError(Throwable e) {
                    child.onError(e);
                }

                public void onNext(T t) {
                    child.onNext(t);
                }
            }

            public void onCompleted() {
                child.onCompleted();
            }

            public void onError(Throwable e) {
                try {
                    RxJavaPlugins.getInstance().getErrorHandler().handleError(e);
                    ((Observable) OperatorOnErrorFlatMap.this.resumeFunction.call(OnErrorThrowable.from(e))).unsafeSubscribe(new C29041());
                } catch (Throwable e2) {
                    child.onError(e2);
                }
            }

            public void onNext(T t) {
                child.onNext(t);
            }
        };
    }
}
