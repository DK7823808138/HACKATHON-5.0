package rx.internal.operators;

public final class OperatorMergeDelayError<T> extends OperatorMerge<T> {
    public OperatorMergeDelayError() {
        super(true);
    }
}
