package rx.internal.operators;

import java.util.concurrent.TimeUnit;
import rx.Observable;
import rx.Observable.Operator;
import rx.Scheduler;
import rx.Scheduler.Worker;
import rx.Subscriber;
import rx.functions.Action0;

public final class OperatorDelay<T> implements Operator<T, T> {
    final long delay;
    final Scheduler scheduler;
    final Observable<? extends T> source;
    final TimeUnit unit;

    public OperatorDelay(Observable<? extends T> source, long delay, TimeUnit unit, Scheduler scheduler) {
        this.source = source;
        this.delay = delay;
        this.unit = unit;
        this.scheduler = scheduler;
    }

    public Subscriber<? super T> call(final Subscriber<? super T> child) {
        final Worker worker = this.scheduler.createWorker();
        child.add(worker);
        return new Subscriber<T>(child) {

            class C28641 implements Action0 {
                C28641() {
                }

                public void call() {
                    child.onCompleted();
                }
            }

            public void onCompleted() {
                worker.schedule(new C28641(), OperatorDelay.this.delay, OperatorDelay.this.unit);
            }

            public void onError(Throwable e) {
                child.onError(e);
            }

            public void onNext(final T t) {
                worker.schedule(new Action0() {
                    public void call() {
                        child.onNext(t);
                    }
                }, OperatorDelay.this.delay, OperatorDelay.this.unit);
            }
        };
    }
}
