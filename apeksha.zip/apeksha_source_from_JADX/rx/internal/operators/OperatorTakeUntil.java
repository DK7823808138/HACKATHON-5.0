package rx.internal.operators;

import rx.Observable;
import rx.Observable.Operator;
import rx.Subscriber;
import rx.observers.SerializedSubscriber;

public final class OperatorTakeUntil<T, E> implements Operator<T, T> {
    private final Observable<? extends E> other;

    public OperatorTakeUntil(Observable<? extends E> other) {
        this.other = other;
    }

    public Subscriber<? super T> call(Subscriber<? super T> child) {
        final Subscriber<T> parent = new SerializedSubscriber(child);
        this.other.unsafeSubscribe(new Subscriber<E>(child) {
            public void onCompleted() {
                parent.onCompleted();
            }

            public void onError(Throwable e) {
                parent.onError(e);
            }

            public void onNext(E e) {
                parent.onCompleted();
            }
        });
        return parent;
    }
}
