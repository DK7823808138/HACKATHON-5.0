package rx.internal.operators;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import rx.Observable;
import rx.Observable.Operator;
import rx.Subscriber;
import rx.observers.SerializedSubscriber;
import rx.subscriptions.CompositeSubscription;

public final class OperatorMergeMaxConcurrent<T> implements Operator<T, Observable<? extends T>> {
    final int maxConcurrency;

    static final class SourceSubscriber<T> extends Subscriber<Observable<? extends T>> {
        static final AtomicIntegerFieldUpdater<SourceSubscriber> WIP_UPDATER = AtomicIntegerFieldUpdater.newUpdater(SourceSubscriber.class, "wip");
        int active;
        final CompositeSubscription csub;
        final Object guard = new Object();
        final int maxConcurrency;
        final Queue<Observable<? extends T>> queue = new LinkedList();
        final Subscriber<T> f865s;
        volatile int wip = 1;

        class C28921 extends Subscriber<T> {
            boolean once = true;

            C28921() {
            }

            public void onNext(T t) {
                SourceSubscriber.this.f865s.onNext(t);
            }

            public void onError(Throwable e) {
                SourceSubscriber.this.onError(e);
            }

            public void onCompleted() {
                if (this.once) {
                    this.once = false;
                    synchronized (SourceSubscriber.this.guard) {
                        SourceSubscriber sourceSubscriber = SourceSubscriber.this;
                        sourceSubscriber.active--;
                    }
                    SourceSubscriber.this.csub.remove(this);
                    SourceSubscriber.this.subscribeNext();
                    SourceSubscriber.this.onCompleted();
                }
            }
        }

        public SourceSubscriber(int maxConcurrency, Subscriber<T> s, CompositeSubscription csub) {
            super(s);
            this.maxConcurrency = maxConcurrency;
            this.f865s = s;
            this.csub = csub;
        }

        public void onNext(Observable<? extends T> t) {
            synchronized (this.guard) {
                this.queue.add(t);
            }
            subscribeNext();
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        void subscribeNext() {
            /*
            r5 = this;
            r3 = r5.guard;
            monitor-enter(r3);
            r2 = r5.queue;	 Catch:{ all -> 0x0034 }
            r1 = r2.peek();	 Catch:{ all -> 0x0034 }
            r1 = (rx.Observable) r1;	 Catch:{ all -> 0x0034 }
            if (r1 == 0) goto L_0x0013;
        L_0x000d:
            r2 = r5.active;	 Catch:{ all -> 0x0034 }
            r4 = r5.maxConcurrency;	 Catch:{ all -> 0x0034 }
            if (r2 < r4) goto L_0x0015;
        L_0x0013:
            monitor-exit(r3);	 Catch:{ all -> 0x0034 }
        L_0x0014:
            return;
        L_0x0015:
            r2 = r5.active;	 Catch:{ all -> 0x0034 }
            r2 = r2 + 1;
            r5.active = r2;	 Catch:{ all -> 0x0034 }
            r2 = r5.queue;	 Catch:{ all -> 0x0034 }
            r2.poll();	 Catch:{ all -> 0x0034 }
            monitor-exit(r3);	 Catch:{ all -> 0x0034 }
            r0 = new rx.internal.operators.OperatorMergeMaxConcurrent$SourceSubscriber$1;
            r0.<init>();
            r2 = r5.csub;
            r2.add(r0);
            r2 = WIP_UPDATER;
            r2.incrementAndGet(r5);
            r1.unsafeSubscribe(r0);
            goto L_0x0014;
        L_0x0034:
            r2 = move-exception;
            monitor-exit(r3);	 Catch:{ all -> 0x0034 }
            throw r2;
            */
            throw new UnsupportedOperationException("Method not decompiled: rx.internal.operators.OperatorMergeMaxConcurrent.SourceSubscriber.subscribeNext():void");
        }

        public void onError(Throwable e) {
            this.f865s.onError(e);
            unsubscribe();
        }

        public void onCompleted() {
            if (WIP_UPDATER.decrementAndGet(this) == 0) {
                this.f865s.onCompleted();
            }
        }
    }

    public OperatorMergeMaxConcurrent(int maxConcurrency) {
        this.maxConcurrency = maxConcurrency;
    }

    public Subscriber<? super Observable<? extends T>> call(Subscriber<? super T> child) {
        SerializedSubscriber<T> s = new SerializedSubscriber(child);
        CompositeSubscription csub = new CompositeSubscription();
        child.add(csub);
        return new SourceSubscriber(this.maxConcurrency, s, csub);
    }
}
