package rx.internal.operators;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import rx.Notification;
import rx.Observable;
import rx.Observable.OnSubscribe;
import rx.Observable.Operator;
import rx.Producer;
import rx.Scheduler;
import rx.Scheduler.Worker;
import rx.Subscriber;
import rx.functions.Action0;
import rx.functions.Func1;
import rx.functions.Func2;
import rx.schedulers.Schedulers;
import rx.subjects.PublishSubject;
import rx.subscriptions.SerialSubscription;

public final class OnSubscribeRedo<T> implements OnSubscribe<T> {
    static final Func1<Observable<? extends Notification<?>>, Observable<?>> REDO_INIFINITE = new C28281();
    private final Func1<? super Observable<? extends Notification<?>>, ? extends Observable<?>> controlHandlerFunction;
    private final Scheduler scheduler;
    private Observable<T> source;
    private boolean stopOnComplete;
    private boolean stopOnError;

    static class C28281 implements Func1<Observable<? extends Notification<?>>, Observable<?>> {

        class C28271 implements Func1<Notification<?>, Notification<?>> {
            C28271() {
            }

            public Notification<?> call(Notification<?> notification) {
                return Notification.createOnNext(null);
            }
        }

        C28281() {
        }

        public Observable<?> call(Observable<? extends Notification<?>> ts) {
            return ts.map(new C28271());
        }
    }

    public static final class RedoFinite implements Func1<Observable<? extends Notification<?>>, Observable<?>> {
        private final long count;

        class C28361 implements Func1<Notification<?>, Notification<?>> {
            int num = 0;

            C28361() {
            }

            public Notification<?> call(Notification<?> terminalNotification) {
                if (RedoFinite.this.count == 0) {
                    return terminalNotification;
                }
                this.num++;
                if (((long) this.num) <= RedoFinite.this.count) {
                    return Notification.createOnNext(Integer.valueOf(this.num));
                }
                return terminalNotification;
            }
        }

        public RedoFinite(long count) {
            this.count = count;
        }

        public Observable<?> call(Observable<? extends Notification<?>> ts) {
            return ts.map(new C28361()).dematerialize();
        }
    }

    public static final class RetryWithPredicate implements Func1<Observable<? extends Notification<?>>, Observable<? extends Notification<?>>> {
        private Func2<Integer, Throwable, Boolean> predicate;

        class C28371 implements Func2<Notification<Integer>, Notification<?>, Notification<Integer>> {
            C28371() {
            }

            public Notification<Integer> call(Notification<Integer> n, Notification<?> term) {
                int value = ((Integer) n.getValue()).intValue();
                if (((Boolean) RetryWithPredicate.this.predicate.call(Integer.valueOf(value), term.getThrowable())).booleanValue()) {
                    return Notification.createOnNext(Integer.valueOf(value + 1));
                }
                return term;
            }
        }

        public RetryWithPredicate(Func2<Integer, Throwable, Boolean> predicate) {
            this.predicate = predicate;
        }

        public Observable<? extends Notification<?>> call(Observable<? extends Notification<?>> ts) {
            return ts.scan(Notification.createOnNext(Integer.valueOf(0)), new C28371());
        }
    }

    public static <T> Observable<T> retry(Observable<T> source) {
        return retry((Observable) source, REDO_INIFINITE);
    }

    public static <T> Observable<T> retry(Observable<T> source, long count) {
        if (count >= 0) {
            return count == 0 ? source : retry((Observable) source, new RedoFinite(count));
        } else {
            throw new IllegalArgumentException("count >= 0 expected");
        }
    }

    public static <T> Observable<T> retry(Observable<T> source, Func1<? super Observable<? extends Notification<?>>, ? extends Observable<?>> notificationHandler) {
        return Observable.create(new OnSubscribeRedo(source, notificationHandler, true, false, Schedulers.trampoline()));
    }

    public static <T> Observable<T> retry(Observable<T> source, Func1<? super Observable<? extends Notification<?>>, ? extends Observable<?>> notificationHandler, Scheduler scheduler) {
        return Observable.create(new OnSubscribeRedo(source, notificationHandler, true, false, scheduler));
    }

    public static <T> Observable<T> repeat(Observable<T> source) {
        return repeat((Observable) source, Schedulers.trampoline());
    }

    public static <T> Observable<T> repeat(Observable<T> source, Scheduler scheduler) {
        return repeat((Observable) source, REDO_INIFINITE, scheduler);
    }

    public static <T> Observable<T> repeat(Observable<T> source, long count) {
        return repeat((Observable) source, count, Schedulers.trampoline());
    }

    public static <T> Observable<T> repeat(Observable<T> source, long count, Scheduler scheduler) {
        if (count == 0) {
            return Observable.empty();
        }
        if (count >= 0) {
            return repeat((Observable) source, new RedoFinite(count - 1), scheduler);
        }
        throw new IllegalArgumentException("count >= 0 expected");
    }

    public static <T> Observable<T> repeat(Observable<T> source, Func1<? super Observable<? extends Notification<?>>, ? extends Observable<?>> notificationHandler) {
        return Observable.create(new OnSubscribeRedo(source, notificationHandler, false, true, Schedulers.trampoline()));
    }

    public static <T> Observable<T> repeat(Observable<T> source, Func1<? super Observable<? extends Notification<?>>, ? extends Observable<?>> notificationHandler, Scheduler scheduler) {
        return Observable.create(new OnSubscribeRedo(source, notificationHandler, false, true, scheduler));
    }

    public static <T> Observable<T> redo(Observable<T> source, Func1<? super Observable<? extends Notification<?>>, ? extends Observable<?>> notificationHandler, Scheduler scheduler) {
        return Observable.create(new OnSubscribeRedo(source, notificationHandler, false, false, scheduler));
    }

    private OnSubscribeRedo(Observable<T> source, Func1<? super Observable<? extends Notification<?>>, ? extends Observable<?>> f, boolean stopOnComplete, boolean stopOnError, Scheduler scheduler) {
        this.source = source;
        this.controlHandlerFunction = f;
        this.stopOnComplete = stopOnComplete;
        this.stopOnError = stopOnError;
        this.scheduler = scheduler;
    }

    public void call(Subscriber<? super T> child) {
        final AtomicBoolean isLocked = new AtomicBoolean(true);
        final AtomicBoolean atomicBoolean = new AtomicBoolean(true);
        final AtomicLong consumerCapacity = new AtomicLong(0);
        final AtomicReference<Producer> currentProducer = new AtomicReference();
        final Worker worker = this.scheduler.createWorker();
        child.add(worker);
        final SerialSubscription sourceSubscriptions = new SerialSubscription();
        child.add(sourceSubscriptions);
        final PublishSubject<Notification<?>> terminals = PublishSubject.create();
        final Subscriber<? super T> subscriber = child;
        Action0 subscribeToSource = new Action0() {

            class C28291 extends Subscriber<T> {
                C28291() {
                }

                public void onCompleted() {
                    unsubscribe();
                    terminals.onNext(Notification.createOnCompleted());
                }

                public void onError(Throwable e) {
                    unsubscribe();
                    terminals.onNext(Notification.createOnError(e));
                }

                public void onNext(T v) {
                    if (consumerCapacity.get() != Long.MAX_VALUE) {
                        consumerCapacity.decrementAndGet();
                    }
                    subscriber.onNext(v);
                }

                public void setProducer(Producer producer) {
                    currentProducer.set(producer);
                    long c = consumerCapacity.get();
                    if (c > 0) {
                        producer.request(c);
                    }
                }
            }

            public void call() {
                if (!subscriber.isUnsubscribed()) {
                    Subscriber<T> terminalDelegatingSubscriber = new C28291();
                    sourceSubscriptions.set(terminalDelegatingSubscriber);
                    OnSubscribeRedo.this.source.unsafeSubscribe(terminalDelegatingSubscriber);
                }
            }
        };
        final Subscriber<? super T> subscriber2 = child;
        final Observable<?> restarts = (Observable) this.controlHandlerFunction.call(terminals.lift(new Operator<Notification<?>, Notification<?>>() {
            public Subscriber<? super Notification<?>> call(final Subscriber<? super Notification<?>> filteredTerminals) {
                return new Subscriber<Notification<?>>(filteredTerminals) {
                    public void onCompleted() {
                        filteredTerminals.onCompleted();
                    }

                    public void onError(Throwable e) {
                        filteredTerminals.onError(e);
                    }

                    public void onNext(Notification<?> t) {
                        if (t.isOnCompleted() && OnSubscribeRedo.this.stopOnComplete) {
                            subscriber2.onCompleted();
                        } else if (t.isOnError() && OnSubscribeRedo.this.stopOnError) {
                            subscriber2.onError(t.getThrowable());
                        } else {
                            isLocked.set(false);
                            filteredTerminals.onNext(t);
                        }
                    }

                    public void setProducer(Producer producer) {
                        producer.request(Long.MAX_VALUE);
                    }
                };
            }
        }));
        final Subscriber<? super T> subscriber3 = child;
        final AtomicLong atomicLong = consumerCapacity;
        final Action0 action0 = subscribeToSource;
        worker.schedule(new Action0() {
            public void call() {
                restarts.unsafeSubscribe(new Subscriber<Object>(subscriber3) {
                    public void onCompleted() {
                        subscriber3.onCompleted();
                    }

                    public void onError(Throwable e) {
                        subscriber3.onError(e);
                    }

                    public void onNext(Object t) {
                        if (!isLocked.get() && !subscriber3.isUnsubscribed()) {
                            if (atomicLong.get() > 0) {
                                worker.schedule(action0);
                            } else {
                                atomicBoolean.compareAndSet(false, true);
                            }
                        }
                    }

                    public void setProducer(Producer producer) {
                        producer.request(Long.MAX_VALUE);
                    }
                });
            }
        });
        final AtomicLong atomicLong2 = consumerCapacity;
        final AtomicReference<Producer> atomicReference = currentProducer;
        final AtomicBoolean atomicBoolean2 = atomicBoolean;
        final Worker worker2 = worker;
        final Action0 action02 = subscribeToSource;
        child.setProducer(new Producer() {
            public void request(long n) {
                long c = atomicLong2.getAndAdd(n);
                Producer producer = (Producer) atomicReference.get();
                if (producer != null) {
                    producer.request(n);
                } else if (c == 0 && atomicBoolean2.compareAndSet(true, false)) {
                    worker2.schedule(action02);
                }
            }
        });
    }
}
