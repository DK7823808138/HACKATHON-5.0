package rx.internal.operators;

import rx.Observable.Operator;
import rx.Subscriber;
import rx.exceptions.OnErrorThrowable;
import rx.functions.Func0;
import rx.functions.Func1;

public final class OperatorMapNotification<T, R> implements Operator<R, T> {
    private final Func0<? extends R> onCompleted;
    private final Func1<? super Throwable, ? extends R> onError;
    private final Func1<? super T, ? extends R> onNext;

    public OperatorMapNotification(Func1<? super T, ? extends R> onNext, Func1<? super Throwable, ? extends R> onError, Func0<? extends R> onCompleted) {
        this.onNext = onNext;
        this.onError = onError;
        this.onCompleted = onCompleted;
    }

    public Subscriber<? super T> call(final Subscriber<? super R> o) {
        return new Subscriber<T>(o) {
            public void onCompleted() {
                try {
                    o.onNext(OperatorMapNotification.this.onCompleted.call());
                    o.onCompleted();
                } catch (Throwable e) {
                    o.onError(e);
                }
            }

            public void onError(Throwable e) {
                try {
                    o.onNext(OperatorMapNotification.this.onError.call(e));
                    o.onCompleted();
                } catch (Throwable th) {
                    o.onError(e);
                }
            }

            public void onNext(T t) {
                try {
                    o.onNext(OperatorMapNotification.this.onNext.call(t));
                } catch (Throwable e) {
                    o.onError(OnErrorThrowable.addValueAsLastCause(e, t));
                }
            }
        };
    }
}
