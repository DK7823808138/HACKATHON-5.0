package rx.internal.operators;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import rx.Observable;
import rx.Observable.Operator;
import rx.Observer;
import rx.Producer;
import rx.Subscriber;
import rx.exceptions.MissingBackpressureException;
import rx.exceptions.OnErrorThrowable;
import rx.functions.Func2;
import rx.functions.Func3;
import rx.functions.Func4;
import rx.functions.Func5;
import rx.functions.Func6;
import rx.functions.Func7;
import rx.functions.Func8;
import rx.functions.Func9;
import rx.functions.FuncN;
import rx.functions.Functions;
import rx.internal.util.RxRingBuffer;
import rx.subscriptions.CompositeSubscription;

public final class OperatorZip<R> implements Operator<R, Observable<?>[]> {
    final FuncN<? extends R> zipFunction;

    private static final class Zip<R> {
        static final AtomicLongFieldUpdater<Zip> COUNTER_UPDATER = AtomicLongFieldUpdater.newUpdater(Zip.class, "counter");
        static final int THRESHOLD = ((int) (((double) RxRingBuffer.SIZE) * 0.7d));
        private final Observer<? super R> child;
        private final CompositeSubscription childSubscription = new CompositeSubscription();
        volatile long counter;
        int emitted = 0;
        private Object[] observers;
        private AtomicLong requested;
        private final FuncN<? extends R> zipFunction;

        final class InnerSubscriber extends Subscriber {
            final RxRingBuffer items = RxRingBuffer.getSpmcInstance();

            InnerSubscriber() {
            }

            public void onStart() {
                request((long) RxRingBuffer.SIZE);
            }

            public void requestMore(long n) {
                request(n);
            }

            public void onCompleted() {
                this.items.onCompleted();
                Zip.this.tick();
            }

            public void onError(Throwable e) {
                Zip.this.child.onError(e);
            }

            public void onNext(Object t) {
                try {
                    this.items.onNext(t);
                } catch (MissingBackpressureException e) {
                    onError(e);
                }
                Zip.this.tick();
            }
        }

        public Zip(Subscriber<? super R> child, FuncN<? extends R> zipFunction) {
            this.child = child;
            this.zipFunction = zipFunction;
            child.add(this.childSubscription);
        }

        public void start(Observable[] os, AtomicLong requested) {
            int i;
            this.observers = new Object[os.length];
            this.requested = requested;
            for (i = 0; i < os.length; i++) {
                InnerSubscriber io = new InnerSubscriber();
                this.observers[i] = io;
                this.childSubscription.add(io);
            }
            for (i = 0; i < os.length; i++) {
                os[i].unsafeSubscribe((InnerSubscriber) this.observers[i]);
            }
        }

        void tick() {
            if (this.observers != null && COUNTER_UPDATER.getAndIncrement(this) == 0) {
                while (true) {
                    if (this.requested.get() > 0) {
                        RxRingBuffer buffer;
                        Object[] vs = new Object[this.observers.length];
                        boolean allHaveValues = true;
                        for (int i = 0; i < this.observers.length; i++) {
                            buffer = ((InnerSubscriber) this.observers[i]).items;
                            Object n = buffer.peek();
                            if (n == null) {
                                allHaveValues = false;
                            } else if (buffer.isCompleted(n)) {
                                this.child.onCompleted();
                                this.childSubscription.unsubscribe();
                                return;
                            } else {
                                vs[i] = buffer.getValue(n);
                            }
                        }
                        if (allHaveValues) {
                            try {
                                this.child.onNext(this.zipFunction.call(vs));
                                this.requested.decrementAndGet();
                                this.emitted++;
                                for (Object obj : this.observers) {
                                    buffer = ((InnerSubscriber) obj).items;
                                    buffer.poll();
                                    if (buffer.isCompleted(buffer.peek())) {
                                        this.child.onCompleted();
                                        this.childSubscription.unsubscribe();
                                        return;
                                    }
                                }
                                if (this.emitted > THRESHOLD) {
                                    for (Object obj2 : this.observers) {
                                        ((InnerSubscriber) obj2).requestMore((long) this.emitted);
                                    }
                                    this.emitted = 0;
                                }
                            } catch (Throwable e) {
                                this.child.onError(OnErrorThrowable.addValueAsLastCause(e, vs));
                                return;
                            }
                        }
                    }
                    if (COUNTER_UPDATER.decrementAndGet(this) <= 0) {
                        return;
                    }
                }
            }
        }
    }

    private static final class ZipProducer<R> extends AtomicLong implements Producer {
        private Zip<R> zipper;

        public ZipProducer(Zip<R> zipper) {
            this.zipper = zipper;
        }

        public void request(long n) {
            addAndGet(n);
            this.zipper.tick();
        }
    }

    private final class ZipSubscriber extends Subscriber<Observable[]> {
        final Subscriber<? super R> child;
        final ZipProducer<R> producer;
        boolean started = false;
        final Zip<R> zipper;

        public ZipSubscriber(Subscriber<? super R> child, Zip<R> zipper, ZipProducer<R> producer) {
            super(child);
            this.child = child;
            this.zipper = zipper;
            this.producer = producer;
        }

        public void onCompleted() {
            if (!this.started) {
                this.child.onCompleted();
            }
        }

        public void onError(Throwable e) {
            this.child.onError(e);
        }

        public void onNext(Observable[] observables) {
            if (observables == null || observables.length == 0) {
                this.child.onCompleted();
                return;
            }
            this.started = true;
            this.zipper.start(observables, this.producer);
        }
    }

    public OperatorZip(FuncN<? extends R> f) {
        this.zipFunction = f;
    }

    public OperatorZip(Func2 f) {
        this.zipFunction = Functions.fromFunc(f);
    }

    public OperatorZip(Func3 f) {
        this.zipFunction = Functions.fromFunc(f);
    }

    public OperatorZip(Func4 f) {
        this.zipFunction = Functions.fromFunc(f);
    }

    public OperatorZip(Func5 f) {
        this.zipFunction = Functions.fromFunc(f);
    }

    public OperatorZip(Func6 f) {
        this.zipFunction = Functions.fromFunc(f);
    }

    public OperatorZip(Func7 f) {
        this.zipFunction = Functions.fromFunc(f);
    }

    public OperatorZip(Func8 f) {
        this.zipFunction = Functions.fromFunc(f);
    }

    public OperatorZip(Func9 f) {
        this.zipFunction = Functions.fromFunc(f);
    }

    public Subscriber<? super Observable[]> call(Subscriber<? super R> child) {
        Zip<R> zipper = new Zip(child, this.zipFunction);
        ZipProducer<R> producer = new ZipProducer(zipper);
        child.setProducer(producer);
        return new ZipSubscriber(child, zipper, producer);
    }
}
