package rx.internal.operators;

import java.util.Iterator;
import rx.Observable.Operator;
import rx.Subscriber;
import rx.functions.Func2;
import rx.observers.Subscribers;

public final class OperatorZipIterable<T1, T2, R> implements Operator<R, T1> {
    final Iterable<? extends T2> iterable;
    final Func2<? super T1, ? super T2, ? extends R> zipFunction;

    public OperatorZipIterable(Iterable<? extends T2> iterable, Func2<? super T1, ? super T2, ? extends R> zipFunction) {
        this.iterable = iterable;
        this.zipFunction = zipFunction;
    }

    public Subscriber<? super T1> call(final Subscriber<? super R> subscriber) {
        final Iterator<? extends T2> iterator = this.iterable.iterator();
        try {
            if (!iterator.hasNext()) {
                subscriber.onCompleted();
                return Subscribers.empty();
            }
        } catch (Throwable e) {
            subscriber.onError(e);
        }
        return new Subscriber<T1>(subscriber) {
            boolean once;

            public void onCompleted() {
                if (!this.once) {
                    this.once = true;
                    subscriber.onCompleted();
                }
            }

            public void onError(Throwable e) {
                subscriber.onError(e);
            }

            public void onNext(T1 t) {
                try {
                    subscriber.onNext(OperatorZipIterable.this.zipFunction.call(t, iterator.next()));
                    if (!iterator.hasNext()) {
                        onCompleted();
                    }
                } catch (Throwable e) {
                    onError(e);
                }
            }
        };
    }
}
