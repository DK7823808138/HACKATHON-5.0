package rx.internal.operators;

import rx.Observable.Operator;
import rx.Subscriber;

public class OperatorDefaultIfEmpty<T> implements Operator<T, T> {
    final T defaultValue;

    public OperatorDefaultIfEmpty(T defaultValue) {
        this.defaultValue = defaultValue;
    }

    public Subscriber<? super T> call(final Subscriber<? super T> child) {
        return new Subscriber<T>(child) {
            boolean hasValue;

            public void onNext(T t) {
                this.hasValue = true;
                child.onNext(t);
            }

            public void onError(Throwable e) {
                child.onError(e);
            }

            public void onCompleted() {
                if (!this.hasValue) {
                    try {
                        child.onNext(OperatorDefaultIfEmpty.this.defaultValue);
                    } catch (Throwable e) {
                        child.onError(e);
                        return;
                    }
                }
                child.onCompleted();
            }
        };
    }
}
