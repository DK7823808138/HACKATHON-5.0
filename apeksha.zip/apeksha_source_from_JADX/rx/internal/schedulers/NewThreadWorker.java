package rx.internal.schedulers;

import java.lang.reflect.Method;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import rx.Scheduler.Worker;
import rx.Subscription;
import rx.functions.Action0;
import rx.plugins.RxJavaPlugins;
import rx.plugins.RxJavaSchedulersHook;
import rx.subscriptions.Subscriptions;

public class NewThreadWorker extends Worker implements Subscription {
    private final ScheduledExecutorService executor;
    volatile boolean isUnsubscribed;
    private final RxJavaSchedulersHook schedulersHook;

    public NewThreadWorker(ThreadFactory threadFactory) {
        this.executor = Executors.newScheduledThreadPool(1, threadFactory);
        Method[] methods = this.executor.getClass().getMethods();
        int length = methods.length;
        int i = 0;
        while (i < length) {
            Method m = methods[i];
            if (m.getName().equals("setRemoveOnCancelPolicy") && m.getParameterTypes().length == 1 && m.getParameterTypes()[0] == Boolean.TYPE) {
                try {
                    m.invoke(this.executor, new Object[]{Boolean.valueOf(true)});
                    break;
                } catch (Exception ex) {
                    RxJavaPlugins.getInstance().getErrorHandler().handleError(ex);
                }
            } else {
                i++;
            }
        }
        this.schedulersHook = RxJavaPlugins.getInstance().getSchedulersHook();
    }

    public Subscription schedule(Action0 action) {
        return schedule(action, 0, null);
    }

    public Subscription schedule(Action0 action, long delayTime, TimeUnit unit) {
        if (this.isUnsubscribed) {
            return Subscriptions.unsubscribed();
        }
        return scheduleActual(action, delayTime, unit);
    }

    public ScheduledAction scheduleActual(Action0 action, long delayTime, TimeUnit unit) {
        Future f;
        ScheduledAction run = new ScheduledAction(this.schedulersHook.onSchedule(action));
        if (delayTime <= 0) {
            f = this.executor.submit(run);
        } else {
            f = this.executor.schedule(run, delayTime, unit);
        }
        run.add(f);
        return run;
    }

    public void unsubscribe() {
        this.isUnsubscribed = true;
        this.executor.shutdownNow();
    }

    public boolean isUnsubscribed() {
        return this.isUnsubscribed;
    }
}
