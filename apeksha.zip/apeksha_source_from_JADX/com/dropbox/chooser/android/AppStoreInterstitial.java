package com.dropbox.chooser.android;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.TextView;

class AppStoreInterstitial {
    private static final int APPROX_STATUSBAR_HEIGHT_DP = 25;
    public static final String DIALOG_TAG = "com.dropbox.chooser.android.DIALOG";
    private static final int DLG_PADDING_DP = 10;
    private static final String DROPBOX_PACKAGE_NAME = "com.dropbox.android";
    private static final int MAX_DIALOG_HEIGHT_DP = 700;
    private static final int MAX_DIALOG_WIDTH_DP = 590;

    @TargetApi(11)
    public static class NativeFragment extends DialogFragment {
        public static NativeFragment newInstance() {
            return new NativeFragment();
        }

        public Dialog onCreateDialog(Bundle savedinstanceState) {
            final NativeFragment frag = this;
            View v = getActivity().getLayoutInflater().inflate(C0474R.layout.app_store_interstitial, null);
            AppStoreInterstitial.setStrings(v, AppStoreInterstitial.isDropboxInstalled(getActivity()));
            ((Button) v.findViewById(C0474R.id.dbx_bottom_bar_ok_button)).setOnClickListener(new OnClickListener() {
                public void onClick(View v_clicked) {
                    frag.dismiss();
                    AppStoreInterstitial.launchMarket(frag.getActivity());
                }
            });
            ((Button) v.findViewById(C0474R.id.dbx_bottom_bar_cancel_button)).setOnClickListener(new OnClickListener() {
                public void onClick(View v_clicked) {
                    frag.dismiss();
                }
            });
            Builder builder = new Builder(getActivity());
            builder.setView(v);
            return builder.create();
        }

        public void onStart() {
            super.onStart();
            AppStoreInterstitial.centerWindow(getDialog().getWindow());
        }
    }

    public static class SupportFragment extends android.support.v4.app.DialogFragment {
        public static SupportFragment newInstance() {
            return new SupportFragment();
        }

        public Dialog onCreateDialog(Bundle savedinstanceState) {
            final SupportFragment frag = this;
            View v = getActivity().getLayoutInflater().inflate(C0474R.layout.app_store_interstitial, null);
            AppStoreInterstitial.setStrings(v, AppStoreInterstitial.isDropboxInstalled(getActivity()));
            ((Button) v.findViewById(C0474R.id.dbx_bottom_bar_ok_button)).setOnClickListener(new OnClickListener() {
                public void onClick(View v_clicked) {
                    frag.dismiss();
                    AppStoreInterstitial.launchMarket(frag.getActivity());
                }
            });
            ((Button) v.findViewById(C0474R.id.dbx_bottom_bar_cancel_button)).setOnClickListener(new OnClickListener() {
                public void onClick(View v_clicked) {
                    frag.dismiss();
                }
            });
            Builder builder = new Builder(getActivity());
            builder.setView(v);
            return builder.create();
        }

        public void onStart() {
            super.onStart();
            AppStoreInterstitial.centerWindow(getDialog().getWindow());
        }
    }

    AppStoreInterstitial() {
    }

    @SuppressLint({"NewApi"})
    public static void showInterstitial(ActivityLike thing) {
        if (thing.getSupportFragmentManager() != null) {
            SupportFragment.newInstance().show(thing.getSupportFragmentManager(), DIALOG_TAG);
        } else {
            NativeFragment.newInstance().show(thing.getFragmentManager(), DIALOG_TAG);
        }
    }

    private static void centerWindow(Window w) {
        DisplayMetrics metrics = new DisplayMetrics();
        w.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int width = Math.min(metrics.widthPixels - ((int) (20.0f * metrics.density)), (int) (590.0f * metrics.density));
        int height = Math.min(metrics.heightPixels - ((int) (45.0f * metrics.density)), (int) (700.0f * metrics.density));
        int x = (metrics.widthPixels - width) / 2;
        int y = ((metrics.heightPixels - height) - ((int) (25.0f * metrics.density))) / 2;
        LayoutParams params = w.getAttributes();
        params.x = x;
        params.y = y;
        params.width = width;
        params.height = height;
        w.setAttributes(params);
        w.setGravity(51);
    }

    private static void setStrings(View v, boolean needUpdate) {
        TextView title = (TextView) v.findViewById(C0474R.id.dbx_install_title);
        TextView main = (TextView) v.findViewById(C0474R.id.dbx_install_main);
        TextView sub = (TextView) v.findViewById(C0474R.id.dbx_install_sub);
        Button okButton = (Button) v.findViewById(C0474R.id.dbx_bottom_bar_ok_button);
        Button cancelButton = (Button) v.findViewById(C0474R.id.dbx_bottom_bar_cancel_button);
        if (needUpdate) {
            title.setText(C0474R.string.dbx_update);
            main.setText(C0474R.string.dbx_update_main);
            sub.setText(C0474R.string.dbx_update_sub);
            okButton.setText(C0474R.string.dbx_update_button_ok);
        } else {
            title.setText(C0474R.string.dbx_install);
            main.setText(C0474R.string.dbx_install_main);
            sub.setText(C0474R.string.dbx_install_sub);
            okButton.setText(C0474R.string.dbx_install_button_ok);
        }
        cancelButton.setText(C0474R.string.dbx_install_button_cancel);
    }

    private static boolean isDropboxInstalled(Activity act) {
        try {
            act.getPackageManager().getPackageInfo(DROPBOX_PACKAGE_NAME, 1);
            return true;
        } catch (NameNotFoundException e) {
            return false;
        }
    }

    private static void launchMarket(Activity act) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("market://details?id=com.dropbox.android"));
        act.startActivity(intent);
    }
}
