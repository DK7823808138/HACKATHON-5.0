package com.dropbox.chooser.android;

import android.app.FragmentManager;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;

interface ActivityLike {
    ContentResolver getContentResolver();

    FragmentManager getFragmentManager();

    PackageManager getPackageManager();

    android.support.v4.app.FragmentManager getSupportFragmentManager();

    void startActivity(Intent intent) throws ActivityNotFoundException;

    void startActivityForResult(Intent intent, int i) throws ActivityNotFoundException;
}
