package com.dropbox.chooser.android;

public final class C0474R {

    public static final class color {
        public static final int actionBarBackground = 2131689618;
        public static final int actionBarHighlight = 2131689619;
        public static final int actionModeBackground = 2131689620;
        public static final int actionModeHighlight = 2131689621;
        public static final int album_list_cover_image_frame = 2131689623;
        public static final int barDark = 2131689643;
        public static final int barDarkBorder = 2131689644;
        public static final int barLight = 2131689645;
        public static final int barLightBorder = 2131689646;
        public static final int blackBackground = 2131689648;
        public static final int blue = 2131689649;
        public static final int blueBackground = 2131689650;
        public static final int buttonHighlight = 2131689658;
        public static final int darkBlueText = 2131689700;
        public static final int darkButtonText = 2131689701;
        public static final int darkGrayText = 2131689702;
        public static final int dialogBoxTitleBackground = 2131689713;
        public static final int errorText = 2131689719;
        public static final int feature_popover_bg = 2131689720;
        public static final int feature_popover_border = 2131689721;
        public static final int fileListMediumGrayText = 2131689722;
        public static final int filelistBackground = 2131689723;
        public static final int filelistItemFocused = 2131689724;
        public static final int filelistItemPressed = 2131689725;
        public static final int folderTitleBackground = 2131689726;
        public static final int folderTitleBackgroundBorder = 2131689727;
        public static final int galleryChromeBackground = 2131689730;
        public static final int galleryChromeTransparencyBackgroundDark = 2131689731;
        public static final int galleryChromeTransparencyBackgroundLight = 2131689732;
        public static final int galleryItemSelectedOverlay = 2131689733;
        public static final int grayBlueishText = 2131689735;
        public static final int grayButtonText = 2131689736;
        public static final int green = 2131689737;
        public static final int greenButtonText = 2131689738;
        public static final int lightBlueBackground = 2131689744;
        public static final int lightBlueBackground2 = 2131689745;
        public static final int listEmptyText = 2131689747;
        public static final int localFilelistBackground = 2131689748;
        public static final int localListEmptyText = 2131689749;
        public static final int loginButtonText = 2131689750;
        public static final int loginText = 2131689751;
        public static final int mediumGrayText = 2131689766;
        public static final int passcodeBackgroundOverride = 2131689767;
        public static final int passwordStrength1 = 2131689768;
        public static final int passwordStrength2 = 2131689769;
        public static final int passwordStrength3 = 2131689770;
        public static final int passwordStrength4 = 2131689771;
        public static final int passwordStrengthMeterLit = 2131689772;
        public static final int passwordStrengthMeterUnlit = 2131689773;
        public static final int passwordStrengthText = 2131689774;
        public static final int passwordStrengthUnlitPhone = 2131689775;
        public static final int photoTabBackground = 2131689776;
        public static final int red = 2131689792;
        public static final int redButtonText = 2131689793;
        public static final int ssLoginText = 2131689810;
        public static final int ss_passwordStrengthMeterLit = 2131689811;
        public static final int ss_passwordStrengthMeterUnlit = 2131689812;
        public static final int ss_passwordStrengthText = 2131689813;
        public static final int statusBarSeparator = 2131689815;
        public static final int text = 2131689822;
        public static final int textFieldStroke = 2131689823;
        public static final int textHighlight = 2131689824;
        public static final int titleBarText = 2131689827;
        public static final int titleBarTextWhite = 2131689828;
        public static final int tourBoxText = 2131689830;
        public static final int tourGrayBorder = 2131689831;
        public static final int tourText = 2131689832;
        public static final int tourTitleText = 2131689833;
        public static final int translucentBlackBackground = 2131689834;
        public static final int translucentFileListMediumGrayText = 2131689835;
        public static final int translucentWhiteBackground = 2131689836;
        public static final int translucentWhiteText = 2131689837;
        public static final int videoIconDetailsBackground = 2131689865;
        public static final int whiteBackground = 2131689881;
        public static final int whiteText = 2131689882;
    }

    public static final class dimen {
        public static final int appStoreInterstitialMargin = 2131361904;
        public static final int buttonTextSize = 2131361910;
        public static final int dbx_action_bar_default_height = 2131361809;
        public static final int dbx_action_bar_icon_vertical_padding = 2131361810;
        public static final int dbx_action_bar_subtitle_bottom_margin = 2131361811;
        public static final int dbx_action_bar_subtitle_text_size = 2131361812;
        public static final int dbx_action_bar_subtitle_top_margin = 2131361813;
        public static final int dbx_action_bar_title_text_size = 2131361814;
        public static final int dbx_action_button_min_width = 2131361819;
        public static final int dbx_dialog_min_width_major = 2131361845;
        public static final int dbx_dialog_min_width_minor = 2131361846;
        public static final int dbx_dropdownitem_icon_width = 2131361954;
        public static final int dbx_dropdownitem_text_padding_left = 2131361955;
        public static final int dbx_dropdownitem_text_padding_right = 2131361956;
        public static final int dbx_search_view_preferred_width = 2131361957;
        public static final int dbx_search_view_text_min_width = 2131361958;
        public static final int fileChooserButtonLeft = 2131361987;
        public static final int fileChooserButtonRight = 2131361988;
        public static final int fileChooserButtonsPadding = 2131361989;
        public static final int fileChooserPaddingBottom = 2131361990;
        public static final int fileChooserPaddingLeft = 2131361991;
        public static final int fileChooserPaddingRight = 2131361992;
        public static final int fileChooserPaddingTop = 2131361993;
        public static final int fileChooserTitleText = 2131361994;
    }

    public static final class drawable {
        public static final int common_bar_light_gray_bottom = 2130837689;
        public static final int common_btn_green_disabled = 2130837690;
        public static final int common_btn_green_focused = 2130837691;
        public static final int common_btn_green_normal = 2130837692;
        public static final int common_btn_green_pressed = 2130837693;
        public static final int common_btn_light_gray_disabled = 2130837694;
        public static final int common_btn_light_gray_focused = 2130837695;
        public static final int common_btn_light_gray_normal = 2130837696;
        public static final int common_btn_light_gray_pressed = 2130837697;
        public static final int common_button_green = 2130837698;
        public static final int common_button_light_gray = 2130837699;
        public static final int ic_launcher = 2130837806;
        public static final int icon_new = 2130837925;
        public static final int tab_dropbox = 2130838088;
        public static final int tab_dropbox_inactive = 2130838089;
    }

    public static final class id {
        public static final int dbx_bottom_bar = 2131755428;
        public static final int dbx_bottom_bar_cancel_button = 2131755429;
        public static final int dbx_bottom_bar_ok_button = 2131755430;
        public static final int dbx_bottom_space = 2131755411;
        public static final int dbx_button_bar = 2131755403;
        public static final int dbx_button_container = 2131755402;
        public static final int dbx_icon = 2131755408;
        public static final int dbx_install_main = 2131755409;
        public static final int dbx_install_sub = 2131755410;
        public static final int dbx_install_title = 2131755405;
        public static final int dbx_main_container = 2131755404;
        public static final int dbx_separator = 2131755406;
        public static final int dbx_top_space = 2131755407;
    }

    public static final class integer {
        public static final int dbx_max_action_buttons = 2131558400;
    }

    public static final class layout {
        public static final int app_store_interstitial = 2130903105;
        public static final int bottom_bar_light = 2130903116;
        public static final int bottom_buttons_light = 2130903117;
    }

    public static final class string {
        public static final int dbx_install = 2131230869;
        public static final int dbx_install_button_cancel = 2131230870;
        public static final int dbx_install_button_ok = 2131230871;
        public static final int dbx_install_main = 2131230872;
        public static final int dbx_install_sub = 2131230873;
        public static final int dbx_update = 2131230874;
        public static final int dbx_update_button_ok = 2131230875;
        public static final int dbx_update_main = 2131230876;
        public static final int dbx_update_sub = 2131230877;
    }

    public static final class style {
        public static final int AppBaseTheme = 2131427340;
        public static final int AppTheme = 2131427484;
        public static final int BottomBar = 2131427535;
        public static final int BottomBarContainer = 2131427536;
        public static final int CommonButtonGreen = 2131427541;
        public static final int CommonButtonLightGray = 2131427542;
        public static final int _CommonButtonBase = 2131427784;
    }
}
