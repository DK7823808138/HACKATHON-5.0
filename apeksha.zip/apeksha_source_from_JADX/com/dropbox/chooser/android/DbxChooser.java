package com.dropbox.chooser.android;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.FragmentActivity;
import io.fabric.sdk.android.services.settings.SettingsJsonConstants;
import java.util.HashMap;
import java.util.Map;

public class DbxChooser {
    private static final int SDK_VERSION = 2;
    private static final String[] intentResultExtras = new String[]{"EXTRA_CHOOSER_RESULTS", "EXTRA_PREVIEW_RESULTS", "EXTRA_CONTENT_RESULTS"};
    private String mAction = ResultType.FILE_CONTENT.action;
    private final String mAppKey;
    private boolean mForceNotAvailable = false;

    public static class Result {
        private final Intent mIntent;

        public Result(Intent intent) {
            this.mIntent = intent;
        }

        public Uri getLink() {
            Bundle[] results = getResults();
            if (results.length == 0) {
                return null;
            }
            return (Uri) results[0].getParcelable("uri");
        }

        public String getName() {
            Bundle[] results = getResults();
            if (results.length == 0) {
                return null;
            }
            return results[0].getString("name");
        }

        public Map<String, Uri> getThumbnails() {
            Map<String, Uri> map = null;
            Bundle[] results = getResults();
            if (results.length != 0) {
                Bundle thumbsBundle = (Bundle) results[0].getParcelable("thumbnails");
                if (thumbsBundle != null) {
                    map = new HashMap();
                    for (String key : thumbsBundle.keySet()) {
                        map.put(key, (Uri) thumbsBundle.getParcelable(key));
                    }
                }
            }
            return map;
        }

        public Uri getIcon() {
            Bundle[] results = getResults();
            if (results.length == 0) {
                return null;
            }
            return (Uri) results[0].getParcelable(SettingsJsonConstants.APP_ICON_KEY);
        }

        public long getSize() {
            Bundle[] results = getResults();
            if (results.length == 0) {
                return -1;
            }
            return results[0].getLong("bytes", -1);
        }

        private Bundle[] getResults() {
            if (this.mIntent == null) {
                return new Bundle[0];
            }
            for (String resultExtra : DbxChooser.intentResultExtras) {
                Parcelable[] results = this.mIntent.getParcelableArrayExtra(resultExtra);
                if (results != null) {
                    Bundle[] resultBundles = new Bundle[results.length];
                    for (int i = 0; i < results.length; i++) {
                        resultBundles[i] = (Bundle) results[i];
                    }
                    return resultBundles;
                }
            }
            return new Bundle[0];
        }
    }

    public enum ResultType {
        PREVIEW_LINK("com.dropbox.android.intent.action.GET_PREVIEW"),
        DIRECT_LINK("com.dropbox.android.intent.action.GET_DIRECT"),
        FILE_CONTENT("com.dropbox.android.intent.action.GET_CONTENT");
        
        final String action;

        private ResultType(String action) {
            this.action = action;
        }
    }

    public DbxChooser(String appKey) {
        if (appKey == null || appKey.length() == 0) {
            throw new IllegalArgumentException("An app key must be supplied.");
        }
        this.mAppKey = appKey;
    }

    private static boolean isChooserAvailable(PackageManager pm) {
        for (ResultType resultType : new ResultType[]{ResultType.FILE_CONTENT, ResultType.PREVIEW_LINK, ResultType.DIRECT_LINK}) {
            if (pm.resolveActivity(new Intent(resultType.action), 65536) == null) {
                return false;
            }
        }
        return true;
    }

    private boolean chooserAvailable(PackageManager pm) {
        if (this.mForceNotAvailable) {
            return false;
        }
        return isChooserAvailable(pm);
    }

    public DbxChooser forResultType(ResultType resultType) {
        if (resultType == null) {
            throw new IllegalArgumentException("An app key must be supplied.");
        }
        this.mAction = resultType.action;
        return this;
    }

    public DbxChooser pretendNotAvailable() {
        this.mForceNotAvailable = true;
        return this;
    }

    private Intent getIntent() {
        Intent intent = new Intent(this.mAction).putExtra("EXTRA_APP_KEY", this.mAppKey);
        intent.putExtra("EXTRA_SDK_VERSION", 2);
        return intent;
    }

    public void launch(Activity act, int requestCode) throws ActivityNotFoundException {
        final Activity mAct = act;
        launch(new ActivityLike() {
            public void startActivity(Intent intent) throws ActivityNotFoundException {
                mAct.startActivity(intent);
            }

            public void startActivityForResult(Intent intent, int requestCode) throws ActivityNotFoundException {
                mAct.startActivityForResult(intent, requestCode);
            }

            public ContentResolver getContentResolver() {
                return mAct.getContentResolver();
            }

            public PackageManager getPackageManager() {
                return mAct.getPackageManager();
            }

            public FragmentManager getFragmentManager() {
                try {
                    return mAct.getFragmentManager();
                } catch (NoSuchMethodError e) {
                    return null;
                }
            }

            public android.support.v4.app.FragmentManager getSupportFragmentManager() {
                if (mAct instanceof FragmentActivity) {
                    return ((FragmentActivity) mAct).getSupportFragmentManager();
                }
                return null;
            }
        }, requestCode);
    }

    @TargetApi(11)
    public void launch(Fragment frag, int requestCode) throws ActivityNotFoundException {
        final Fragment mFrag = frag;
        launch(new ActivityLike() {
            public void startActivity(Intent intent) throws ActivityNotFoundException {
                mFrag.startActivity(intent);
            }

            public void startActivityForResult(Intent intent, int requestCode) throws ActivityNotFoundException {
                mFrag.startActivityForResult(intent, requestCode);
            }

            public ContentResolver getContentResolver() {
                Activity act = mFrag.getActivity();
                if (act == null) {
                    return null;
                }
                return act.getContentResolver();
            }

            public PackageManager getPackageManager() {
                Activity act = mFrag.getActivity();
                if (act == null) {
                    return null;
                }
                return act.getPackageManager();
            }

            public FragmentManager getFragmentManager() {
                Activity act = mFrag.getActivity();
                if (act == null) {
                    return null;
                }
                return act.getFragmentManager();
            }

            public android.support.v4.app.FragmentManager getSupportFragmentManager() {
                return null;
            }
        }, requestCode);
    }

    public void launch(android.support.v4.app.Fragment frag, int requestCode) throws ActivityNotFoundException {
        final android.support.v4.app.Fragment mFrag = frag;
        launch(new ActivityLike() {
            public void startActivity(Intent intent) throws ActivityNotFoundException {
                mFrag.startActivity(intent);
            }

            public void startActivityForResult(Intent intent, int requestCode) throws ActivityNotFoundException {
                mFrag.startActivityForResult(intent, requestCode);
            }

            public ContentResolver getContentResolver() {
                Activity act = mFrag.getActivity();
                if (act == null) {
                    return null;
                }
                return act.getContentResolver();
            }

            public PackageManager getPackageManager() {
                Activity act = mFrag.getActivity();
                if (act == null) {
                    return null;
                }
                return act.getPackageManager();
            }

            public FragmentManager getFragmentManager() {
                return null;
            }

            public android.support.v4.app.FragmentManager getSupportFragmentManager() {
                FragmentActivity act = mFrag.getActivity();
                if (act == null) {
                    return null;
                }
                return act.getSupportFragmentManager();
            }
        }, requestCode);
    }

    private void launch(ActivityLike thing, int requestCode) {
        if (requestCode < 0) {
            throw new IllegalArgumentException("requestCode must be non-negative");
        } else if (thing.getSupportFragmentManager() == null && thing.getFragmentManager() == null) {
            throw new IllegalArgumentException("Dropbox Chooser requires Fragments. If below API level 11, pass in a FragmentActivity from the support library.");
        } else if (thing.getPackageManager() == null) {
            throw new IllegalStateException("DbxChooser's launch() must be called when there is an Activity available");
        } else if (chooserAvailable(thing.getPackageManager())) {
            try {
                thing.startActivityForResult(getIntent(), requestCode);
            } catch (ActivityNotFoundException e) {
                throw e;
            }
        } else {
            doAppStoreFallback(thing, requestCode);
        }
    }

    private void doAppStoreFallback(ActivityLike thing, int requestCode) throws ActivityNotFoundException {
        AppStoreInterstitial.showInterstitial(thing);
    }
}
