package com.google.android.youtube.player.internal;

import android.os.RemoteException;

public final class C2215q extends RuntimeException {
    public C2215q(RemoteException remoteException) {
        super(remoteException);
    }
}
