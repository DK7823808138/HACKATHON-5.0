package com.google.android.youtube.player.internal;

import android.util.Log;

public final class C2234y {
    public static void m645a(String str, Throwable th) {
        Log.e("YouTubeAndroidPlayerAPI", str, th);
    }

    public static void m646a(String str, Object... objArr) {
        Log.w("YouTubeAndroidPlayerAPI", String.format(str, objArr));
    }
}
