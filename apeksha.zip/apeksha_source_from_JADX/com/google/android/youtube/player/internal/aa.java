package com.google.android.youtube.player.internal;

import android.app.Activity;
import android.content.Context;
import com.google.android.youtube.player.YouTubeThumbnailView;
import com.google.android.youtube.player.internal.C2175t.C2171a;
import com.google.android.youtube.player.internal.C2175t.C2172b;
import com.google.android.youtube.player.internal.C2232w.C2231a;

public abstract class aa {
    private static final aa f153a = m393b();

    public static aa m392a() {
        return f153a;
    }

    private static aa m393b() {
        try {
            return (aa) Class.forName("com.google.android.youtube.api.locallylinked.LocallyLinkedFactory").asSubclass(aa.class).newInstance();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        } catch (Throwable e2) {
            throw new IllegalStateException(e2);
        } catch (ClassNotFoundException e3) {
            return new ac();
        }
    }

    public abstract C2174a mo7055a(C2176b c2176b, YouTubeThumbnailView youTubeThumbnailView);

    public abstract C2176b mo7056a(Context context, String str, C2171a c2171a, C2172b c2172b);

    public abstract C2180d mo7057a(Activity activity, C2176b c2176b, boolean z) throws C2231a;
}
