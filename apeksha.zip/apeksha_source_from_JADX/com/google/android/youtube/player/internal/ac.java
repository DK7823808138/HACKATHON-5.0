package com.google.android.youtube.player.internal;

import android.app.Activity;
import android.content.Context;
import com.google.android.youtube.player.YouTubeThumbnailView;
import com.google.android.youtube.player.internal.C2175t.C2171a;
import com.google.android.youtube.player.internal.C2175t.C2172b;
import com.google.android.youtube.player.internal.C2232w.C2231a;

public final class ac extends aa {
    public final C2174a mo7055a(C2176b c2176b, YouTubeThumbnailView youTubeThumbnailView) {
        return new C2214p(c2176b, youTubeThumbnailView);
    }

    public final C2176b mo7056a(Context context, String str, C2171a c2171a, C2172b c2172b) {
        return new C2210o(context, str, context.getPackageName(), C2235z.m656d(context), c2171a, c2172b);
    }

    public final C2180d mo7057a(Activity activity, C2176b c2176b, boolean z) throws C2231a {
        return C2232w.m642a(activity, c2176b.mo7131a(), z);
    }
}
