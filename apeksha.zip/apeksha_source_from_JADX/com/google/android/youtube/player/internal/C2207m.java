package com.google.android.youtube.player.internal;

import android.content.Context;
import android.content.res.Resources;
import java.util.Locale;
import java.util.Map;

public final class C2207m {
    public final String f164a;
    public final String f165b;
    public final String f166c;
    public final String f167d;
    public final String f168e;
    public final String f169f;
    public final String f170g;
    public final String f171h;
    public final String f172i;
    public final String f173j;

    public C2207m(Context context) {
        Resources resources = context.getResources();
        Locale locale = (resources == null || resources.getConfiguration() == null || resources.getConfiguration().locale == null) ? Locale.getDefault() : resources.getConfiguration().locale;
        Map a = C2233x.m643a(locale);
        this.f164a = (String) a.get("error_initializing_player");
        this.f165b = (String) a.get("get_youtube_app_title");
        this.f166c = (String) a.get("get_youtube_app_text");
        this.f167d = (String) a.get("get_youtube_app_action");
        this.f168e = (String) a.get("enable_youtube_app_title");
        this.f169f = (String) a.get("enable_youtube_app_text");
        this.f170g = (String) a.get("enable_youtube_app_action");
        this.f171h = (String) a.get("update_youtube_app_title");
        this.f172i = (String) a.get("update_youtube_app_text");
        this.f173j = (String) a.get("update_youtube_app_action");
    }
}
