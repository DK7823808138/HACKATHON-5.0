package com.google.android.youtube.player.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.exoplayer2.extractor.ts.TsExtractor;
import com.google.android.youtube.player.YouTubeApiServiceUtil;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.internal.C2175t.C2171a;
import com.google.android.youtube.player.internal.C2175t.C2172b;
import com.google.android.youtube.player.internal.C2177c.C2179a;
import com.google.android.youtube.player.internal.C2195i.C2197a;
import java.util.ArrayList;

public abstract class C2209r<T extends IInterface> implements C2175t {
    final Handler f176a;
    private final Context f177b;
    private T f178c;
    private ArrayList<C2171a> f179d;
    private final ArrayList<C2171a> f180e = new ArrayList();
    private boolean f181f = false;
    private ArrayList<C2172b> f182g;
    private boolean f183h = false;
    private final ArrayList<C2218b<?>> f184i = new ArrayList();
    private ServiceConnection f185j;
    private boolean f186k = false;

    static /* synthetic */ class C22161 {
        static final /* synthetic */ int[] f206a = new int[YouTubeInitializationResult.values().length];

        static {
            try {
                f206a[YouTubeInitializationResult.SUCCESS.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
        }
    }

    final class C2217a extends Handler {
        final /* synthetic */ C2209r f207a;

        C2217a(C2209r c2209r) {
            this.f207a = c2209r;
        }

        public final void handleMessage(Message message) {
            if (message.what == 3) {
                this.f207a.m568a((YouTubeInitializationResult) message.obj);
            } else if (message.what == 4) {
                synchronized (this.f207a.f179d) {
                    if (this.f207a.f186k && this.f207a.m575f() && this.f207a.f179d.contains(message.obj)) {
                        ((C2171a) message.obj).mo7042a();
                    }
                }
            } else if (message.what == 2 && !this.f207a.m575f()) {
            } else {
                if (message.what == 2 || message.what == 1) {
                    ((C2218b) message.obj).m603a();
                }
            }
        }
    }

    protected abstract class C2218b<TListener> {
        final /* synthetic */ C2209r f208a;
        private TListener f209b;

        public C2218b(C2209r c2209r, TListener tListener) {
            this.f208a = c2209r;
            this.f209b = tListener;
            synchronized (c2209r.f184i) {
                c2209r.f184i.add(this);
            }
        }

        public final void m603a() {
            Object obj;
            synchronized (this) {
                obj = this.f209b;
            }
            mo7147a(obj);
        }

        protected abstract void mo7147a(TListener tListener);

        public final void m605b() {
            synchronized (this) {
                this.f209b = null;
            }
        }
    }

    protected final class C2219c extends C2218b<Boolean> {
        public final YouTubeInitializationResult f210b;
        public final IBinder f211c;
        final /* synthetic */ C2209r f212d;

        public C2219c(C2209r c2209r, String str, IBinder iBinder) {
            this.f212d = c2209r;
            super(c2209r, Boolean.valueOf(true));
            this.f210b = C2209r.m562b(str);
            this.f211c = iBinder;
        }

        protected final /* synthetic */ void mo7147a(Object obj) {
            if (((Boolean) obj) != null) {
                switch (C22161.f206a[this.f210b.ordinal()]) {
                    case 1:
                        try {
                            if (this.f212d.mo7136b().equals(this.f211c.getInterfaceDescriptor())) {
                                this.f212d.f178c = this.f212d.mo7132a(this.f211c);
                                if (this.f212d.f178c != null) {
                                    this.f212d.m576g();
                                    return;
                                }
                            }
                        } catch (RemoteException e) {
                        }
                        this.f212d.mo7131a();
                        this.f212d.m568a(YouTubeInitializationResult.INTERNAL_ERROR);
                        return;
                    default:
                        this.f212d.m568a(this.f210b);
                        return;
                }
            }
        }
    }

    protected final class C2220d extends C2179a {
        final /* synthetic */ C2209r f213a;

        protected C2220d(C2209r c2209r) {
            this.f213a = c2209r;
        }

        public final void mo7058a(String str, IBinder iBinder) {
            this.f213a.f176a.sendMessage(this.f213a.f176a.obtainMessage(1, new C2219c(this.f213a, str, iBinder)));
        }
    }

    final class C2221e implements ServiceConnection {
        final /* synthetic */ C2209r f214a;

        C2221e(C2209r c2209r) {
            this.f214a = c2209r;
        }

        public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            this.f214a.m571b(iBinder);
        }

        public final void onServiceDisconnected(ComponentName componentName) {
            this.f214a.f178c = null;
            this.f214a.m577h();
        }
    }

    protected C2209r(Context context, C2171a c2171a, C2172b c2172b) {
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            throw new IllegalStateException("Clients must be created on the UI thread.");
        }
        this.f177b = (Context) ab.m397a((Object) context);
        this.f179d = new ArrayList();
        this.f179d.add(ab.m397a((Object) c2171a));
        this.f182g = new ArrayList();
        this.f182g.add(ab.m397a((Object) c2172b));
        this.f176a = new C2217a(this);
    }

    private void mo7131a() {
        if (this.f185j != null) {
            try {
                this.f177b.unbindService(this.f185j);
            } catch (Throwable e) {
                Log.w("YouTubeClient", "Unexpected error from unbindService()", e);
            }
        }
        this.f178c = null;
        this.f185j = null;
    }

    private static YouTubeInitializationResult m562b(String str) {
        try {
            return YouTubeInitializationResult.valueOf(str);
        } catch (IllegalArgumentException e) {
            return YouTubeInitializationResult.UNKNOWN_ERROR;
        } catch (NullPointerException e2) {
            return YouTubeInitializationResult.UNKNOWN_ERROR;
        }
    }

    protected abstract T mo7132a(IBinder iBinder);

    protected final void m568a(YouTubeInitializationResult youTubeInitializationResult) {
        this.f176a.removeMessages(4);
        synchronized (this.f182g) {
            this.f183h = true;
            ArrayList arrayList = this.f182g;
            int size = arrayList.size();
            int i = 0;
            while (i < size) {
                if (this.f186k) {
                    if (this.f182g.contains(arrayList.get(i))) {
                        ((C2172b) arrayList.get(i)).mo7044a(youTubeInitializationResult);
                    }
                    i++;
                } else {
                    return;
                }
            }
            this.f183h = false;
        }
    }

    protected abstract void mo7134a(C2195i c2195i, C2220d c2220d) throws RemoteException;

    protected abstract String mo7136b();

    protected final void m571b(IBinder iBinder) {
        try {
            mo7134a(C2197a.m530a(iBinder), new C2220d(this));
        } catch (RemoteException e) {
            Log.w("YouTubeClient", "service died");
        }
    }

    protected abstract String mo7137c();

    public void mo7129d() {
        m577h();
        this.f186k = false;
        synchronized (this.f184i) {
            int size = this.f184i.size();
            for (int i = 0; i < size; i++) {
                ((C2218b) this.f184i.get(i)).m605b();
            }
            this.f184i.clear();
        }
        mo7131a();
    }

    public final void mo7130e() {
        this.f186k = true;
        YouTubeInitializationResult isYouTubeApiServiceAvailable = YouTubeApiServiceUtil.isYouTubeApiServiceAvailable(this.f177b);
        if (isYouTubeApiServiceAvailable != YouTubeInitializationResult.SUCCESS) {
            this.f176a.sendMessage(this.f176a.obtainMessage(3, isYouTubeApiServiceAvailable));
            return;
        }
        Intent intent = new Intent(mo7137c()).setPackage(C2235z.m649a(this.f177b));
        if (this.f185j != null) {
            Log.e("YouTubeClient", "Calling connect() while still connected, missing disconnect().");
            mo7131a();
        }
        this.f185j = new C2221e(this);
        if (!this.f177b.bindService(intent, this.f185j, TsExtractor.TS_STREAM_TYPE_AC3)) {
            this.f176a.sendMessage(this.f176a.obtainMessage(3, YouTubeInitializationResult.ERROR_CONNECTING_TO_SERVICE));
        }
    }

    public final boolean m575f() {
        return this.f178c != null;
    }

    protected final void m576g() {
        boolean z = true;
        synchronized (this.f179d) {
            ab.m400a(!this.f181f);
            this.f176a.removeMessages(4);
            this.f181f = true;
            if (this.f180e.size() != 0) {
                z = false;
            }
            ab.m400a(z);
            ArrayList arrayList = this.f179d;
            int size = arrayList.size();
            for (int i = 0; i < size && this.f186k && m575f(); i++) {
                if (!this.f180e.contains(arrayList.get(i))) {
                    ((C2171a) arrayList.get(i)).mo7042a();
                }
            }
            this.f180e.clear();
            this.f181f = false;
        }
    }

    protected final void m577h() {
        this.f176a.removeMessages(4);
        synchronized (this.f179d) {
            this.f181f = true;
            ArrayList arrayList = this.f179d;
            int size = arrayList.size();
            for (int i = 0; i < size && this.f186k; i++) {
                if (this.f179d.contains(arrayList.get(i))) {
                    ((C2171a) arrayList.get(i)).mo7043b();
                }
            }
            this.f181f = false;
        }
    }

    protected final void m578i() {
        if (!m575f()) {
            throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
        }
    }

    protected final T m579j() {
        m578i();
        return this.f178c;
    }
}
