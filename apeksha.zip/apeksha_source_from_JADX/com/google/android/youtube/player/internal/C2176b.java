package com.google.android.youtube.player.internal;

import android.os.IBinder;

public interface C2176b extends C2175t {
    IBinder mo7131a();

    C2201k mo7133a(C2198j c2198j);

    void mo7135a(boolean z);
}
