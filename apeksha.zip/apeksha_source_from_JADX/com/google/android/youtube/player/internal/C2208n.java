package com.google.android.youtube.player.internal;

import android.content.Context;
import android.support.v4.view.ViewCompat;
import android.view.View.MeasureSpec;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ProgressBar;
import android.widget.TextView;

public final class C2208n extends FrameLayout {
    private final ProgressBar f174a;
    private final TextView f175b;

    public C2208n(Context context) {
        super(context, null, C2235z.m655c(context));
        C2207m c2207m = new C2207m(context);
        setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        this.f174a = new ProgressBar(context);
        this.f174a.setVisibility(8);
        addView(this.f174a, new LayoutParams(-2, -2, 17));
        int i = (int) ((10.0f * context.getResources().getDisplayMetrics().density) + 0.5f);
        this.f175b = new TextView(context);
        this.f175b.setTextAppearance(context, 16973894);
        this.f175b.setTextColor(-1);
        this.f175b.setVisibility(8);
        this.f175b.setPadding(i, i, i, i);
        this.f175b.setGravity(17);
        this.f175b.setText(c2207m.f164a);
        addView(this.f175b, new LayoutParams(-2, -2, 17));
    }

    public final void m555a() {
        this.f174a.setVisibility(8);
        this.f175b.setVisibility(8);
    }

    public final void m556b() {
        this.f174a.setVisibility(0);
        this.f175b.setVisibility(8);
    }

    public final void m557c() {
        this.f174a.setVisibility(8);
        this.f175b.setVisibility(0);
    }

    protected final void onMeasure(int i, int i2) {
        int i3 = 0;
        int mode = MeasureSpec.getMode(i);
        int mode2 = MeasureSpec.getMode(i2);
        int size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        if (mode == 1073741824 && mode2 == 1073741824) {
            i3 = size;
        } else if (mode == 1073741824 || (mode == Integer.MIN_VALUE && mode2 == 0)) {
            size2 = (int) (((float) size) / 1.777f);
            i3 = size;
        } else if (mode2 == 1073741824 || (mode2 == Integer.MIN_VALUE && mode == 0)) {
            i3 = (int) (((float) size2) * 1.777f);
        } else if (mode != Integer.MIN_VALUE || mode2 != Integer.MIN_VALUE) {
            size2 = 0;
        } else if (((float) size2) < ((float) size) / 1.777f) {
            i3 = (int) (((float) size2) * 1.777f);
        } else {
            size2 = (int) (((float) size) / 1.777f);
            i3 = size;
        }
        super.onMeasure(MeasureSpec.makeMeasureSpec(C2208n.resolveSize(i3, i), 1073741824), MeasureSpec.makeMeasureSpec(C2208n.resolveSize(size2, i2), 1073741824));
    }
}
