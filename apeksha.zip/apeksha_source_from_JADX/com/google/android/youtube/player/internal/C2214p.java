package com.google.android.youtube.player.internal;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.youtube.player.YouTubeThumbnailView;
import com.google.android.youtube.player.internal.C2198j.C2200a;

public final class C2214p extends C2174a {
    private final Handler f201a = new Handler(Looper.getMainLooper());
    private C2176b f202b;
    private C2201k f203c;
    private boolean f204d;
    private boolean f205e;

    private final class C2213a extends C2200a {
        final /* synthetic */ C2214p f200a;

        private C2213a(C2214p c2214p) {
            this.f200a = c2214p;
        }

        public final void mo7118a(Bitmap bitmap, String str, boolean z, boolean z2) {
            final boolean z3 = z;
            final boolean z4 = z2;
            final Bitmap bitmap2 = bitmap;
            final String str2 = str;
            this.f200a.f201a.post(new Runnable(this) {
                final /* synthetic */ C2213a f195e;

                public final void run() {
                    this.f195e.f200a.f204d = z3;
                    this.f195e.f200a.f205e = z4;
                    this.f195e.f200a.m380a(bitmap2, str2);
                }
            });
        }

        public final void mo7119a(final String str, final boolean z, final boolean z2) {
            this.f200a.f201a.post(new Runnable(this) {
                final /* synthetic */ C2213a f199d;

                public final void run() {
                    this.f199d.f200a.f204d = z;
                    this.f199d.f200a.f205e = z2;
                    this.f199d.f200a.m385b(str);
                }
            });
        }
    }

    public C2214p(C2176b c2176b, YouTubeThumbnailView youTubeThumbnailView) {
        super(youTubeThumbnailView);
        this.f202b = (C2176b) ab.m398a((Object) c2176b, (Object) "connectionClient cannot be null");
        this.f203c = c2176b.mo7133a(new C2213a());
    }

    public final void mo7138a(String str) {
        try {
            this.f203c.mo7121a(str);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public final void mo7139a(String str, int i) {
        try {
            this.f203c.mo7122a(str, i);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    protected final boolean mo7140a() {
        return super.mo7140a() && this.f203c != null;
    }

    public final void mo7141c() {
        try {
            this.f203c.mo7120a();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public final void mo7142d() {
        try {
            this.f203c.mo7123b();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public final void mo7143e() {
        try {
            this.f203c.mo7124c();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public final boolean mo7144f() {
        return this.f205e;
    }

    public final boolean mo7145g() {
        return this.f204d;
    }

    public final void mo7146h() {
        try {
            this.f203c.mo7125d();
        } catch (RemoteException e) {
        }
        this.f202b.mo7129d();
        this.f203c = null;
        this.f202b = null;
    }
}
