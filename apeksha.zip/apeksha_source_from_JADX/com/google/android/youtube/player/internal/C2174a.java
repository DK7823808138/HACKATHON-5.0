package com.google.android.youtube.player.internal;

import android.graphics.Bitmap;
import com.google.android.youtube.player.YouTubeThumbnailLoader;
import com.google.android.youtube.player.YouTubeThumbnailLoader.ErrorReason;
import com.google.android.youtube.player.YouTubeThumbnailLoader.OnThumbnailLoadedListener;
import com.google.android.youtube.player.YouTubeThumbnailView;
import java.lang.ref.WeakReference;
import java.util.NoSuchElementException;

public abstract class C2174a implements YouTubeThumbnailLoader {
    private final WeakReference<YouTubeThumbnailView> f149a;
    private OnThumbnailLoadedListener f150b;
    private boolean f151c;
    private boolean f152d;

    public C2174a(YouTubeThumbnailView youTubeThumbnailView) {
        this.f149a = new WeakReference(ab.m397a((Object) youTubeThumbnailView));
    }

    private void m379i() {
        if (!mo7140a()) {
            throw new IllegalStateException("This YouTubeThumbnailLoader has been released");
        }
    }

    public final void m380a(Bitmap bitmap, String str) {
        YouTubeThumbnailView youTubeThumbnailView = (YouTubeThumbnailView) this.f149a.get();
        if (mo7140a() && youTubeThumbnailView != null) {
            youTubeThumbnailView.setImageBitmap(bitmap);
            if (this.f150b != null) {
                this.f150b.onThumbnailLoaded(youTubeThumbnailView, str);
            }
        }
    }

    public abstract void mo7138a(String str);

    public abstract void mo7139a(String str, int i);

    protected boolean mo7140a() {
        return !this.f152d;
    }

    public final void m384b() {
        if (mo7140a()) {
            C2234y.m646a("The finalize() method for a YouTubeThumbnailLoader has work to do. You should have called release().", new Object[0]);
            release();
        }
    }

    public final void m385b(String str) {
        YouTubeThumbnailView youTubeThumbnailView = (YouTubeThumbnailView) this.f149a.get();
        if (mo7140a() && this.f150b != null && youTubeThumbnailView != null) {
            ErrorReason valueOf;
            try {
                valueOf = ErrorReason.valueOf(str);
            } catch (IllegalArgumentException e) {
                valueOf = ErrorReason.UNKNOWN;
            } catch (NullPointerException e2) {
                valueOf = ErrorReason.UNKNOWN;
            }
            this.f150b.onThumbnailError(youTubeThumbnailView, valueOf);
        }
    }

    public abstract void mo7141c();

    public abstract void mo7142d();

    public abstract void mo7143e();

    public abstract boolean mo7144f();

    public final void first() {
        m379i();
        if (this.f151c) {
            mo7143e();
            return;
        }
        throw new IllegalStateException("Must call setPlaylist first");
    }

    public abstract boolean mo7145g();

    public abstract void mo7146h();

    public final boolean hasNext() {
        m379i();
        return mo7144f();
    }

    public final boolean hasPrevious() {
        m379i();
        return mo7145g();
    }

    public final void next() {
        m379i();
        if (!this.f151c) {
            throw new IllegalStateException("Must call setPlaylist first");
        } else if (mo7144f()) {
            mo7141c();
        } else {
            throw new NoSuchElementException("Called next at end of playlist");
        }
    }

    public final void previous() {
        m379i();
        if (!this.f151c) {
            throw new IllegalStateException("Must call setPlaylist first");
        } else if (mo7145g()) {
            mo7142d();
        } else {
            throw new NoSuchElementException("Called previous at start of playlist");
        }
    }

    public final void release() {
        if (mo7140a()) {
            this.f152d = true;
            this.f150b = null;
            mo7146h();
        }
    }

    public final void setOnThumbnailLoadedListener(OnThumbnailLoadedListener onThumbnailLoadedListener) {
        m379i();
        this.f150b = onThumbnailLoadedListener;
    }

    public final void setPlaylist(String str) {
        setPlaylist(str, 0);
    }

    public final void setPlaylist(String str, int i) {
        m379i();
        this.f151c = true;
        mo7139a(str, i);
    }

    public final void setVideo(String str) {
        m379i();
        this.f151c = false;
        mo7138a(str);
    }
}
