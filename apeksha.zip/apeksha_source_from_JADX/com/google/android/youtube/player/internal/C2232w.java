package com.google.android.youtube.player.internal;

import android.app.Activity;
import android.content.Context;
import android.os.IBinder;
import com.google.android.youtube.player.internal.C2180d.C2182a;

public final class C2232w {

    public static final class C2231a extends Exception {
        public C2231a(String str) {
            super(str);
        }

        public C2231a(String str, Throwable th) {
            super(str, th);
        }
    }

    private static IBinder m640a(Class<?> cls, IBinder iBinder, IBinder iBinder2, IBinder iBinder3, boolean z) throws C2231a {
        Throwable th;
        String str;
        String valueOf;
        try {
            return (IBinder) cls.getConstructor(new Class[]{IBinder.class, IBinder.class, IBinder.class, Boolean.TYPE}).newInstance(new Object[]{iBinder, iBinder2, iBinder3, Boolean.valueOf(z)});
        } catch (Throwable e) {
            th = e;
            str = "Could not find the right constructor for ";
            valueOf = String.valueOf(cls.getName());
            throw new C2231a(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), th);
        } catch (Throwable e2) {
            th = e2;
            str = "Exception thrown by invoked constructor in ";
            valueOf = String.valueOf(cls.getName());
            throw new C2231a(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), th);
        } catch (Throwable e22) {
            th = e22;
            str = "Unable to instantiate the dynamic class ";
            valueOf = String.valueOf(cls.getName());
            throw new C2231a(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), th);
        } catch (Throwable e222) {
            th = e222;
            str = "Unable to call the default constructor of ";
            valueOf = String.valueOf(cls.getName());
            throw new C2231a(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), th);
        }
    }

    private static IBinder m641a(ClassLoader classLoader, String str, IBinder iBinder, IBinder iBinder2, IBinder iBinder3, boolean z) throws C2231a {
        try {
            return C2232w.m640a(classLoader.loadClass(str), iBinder, iBinder2, iBinder3, z);
        } catch (Throwable e) {
            Throwable th = e;
            String str2 = "Unable to find dynamic class ";
            String valueOf = String.valueOf(str);
            throw new C2231a(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2), th);
        }
    }

    public static C2180d m642a(Activity activity, IBinder iBinder, boolean z) throws C2231a {
        ab.m397a((Object) activity);
        ab.m397a((Object) iBinder);
        Object b = C2235z.m652b((Context) activity);
        if (b != null) {
            return C2182a.m497a(C2232w.m641a(b.getClassLoader(), "com.google.android.youtube.api.jar.client.RemoteEmbeddedPlayer", C2230v.m638a(b).asBinder(), C2230v.m638a((Object) activity).asBinder(), iBinder, z));
        }
        throw new C2231a("Could not create remote context");
    }
}
