package com.google.android.youtube.player.internal;

import android.content.res.Configuration;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.KeyEvent;
import android.view.View;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayer$ErrorReason;
import com.google.android.youtube.player.YouTubePlayer$OnFullscreenListener;
import com.google.android.youtube.player.YouTubePlayer$PlaybackEventListener;
import com.google.android.youtube.player.YouTubePlayer$PlayerStyle;
import com.google.android.youtube.player.YouTubePlayer$PlaylistEventListener;
import com.google.android.youtube.player.YouTubePlayer.PlayerStateChangeListener;
import com.google.android.youtube.player.internal.C2183e.C2185a;
import com.google.android.youtube.player.internal.C2186f.C2188a;
import com.google.android.youtube.player.internal.C2189g.C2191a;
import com.google.android.youtube.player.internal.C2192h.C2194a;
import java.util.List;

public final class C2226s implements YouTubePlayer {
    private C2176b f223a;
    private C2180d f224b;

    public C2226s(C2176b c2176b, C2180d c2180d) {
        this.f223a = (C2176b) ab.m398a((Object) c2176b, (Object) "connectionClient cannot be null");
        this.f224b = (C2180d) ab.m398a((Object) c2180d, (Object) "embeddedPlayer cannot be null");
    }

    public final View m623a() {
        try {
            return (View) C2230v.m639a(this.f224b.mo7101s());
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void m624a(Configuration configuration) {
        try {
            this.f224b.mo7061a(configuration);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void m625a(boolean z) {
        try {
            this.f224b.mo7070a(z);
            this.f223a.mo7135a(z);
            this.f223a.mo7129d();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final boolean m626a(int i, KeyEvent keyEvent) {
        try {
            return this.f224b.mo7071a(i, keyEvent);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final boolean m627a(Bundle bundle) {
        try {
            return this.f224b.mo7072a(bundle);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void addFullscreenControlFlag(int i) {
        try {
            this.f224b.mo7083d(i);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void m628b() {
        try {
            this.f224b.mo7095m();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void m629b(boolean z) {
        try {
            this.f224b.mo7086e(z);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final boolean m630b(int i, KeyEvent keyEvent) {
        try {
            return this.f224b.mo7079b(i, keyEvent);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void m631c() {
        try {
            this.f224b.mo7096n();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void cuePlaylist(String str) {
        cuePlaylist(str, 0, 0);
    }

    public final void cuePlaylist(String str, int i, int i2) {
        try {
            this.f224b.mo7068a(str, i, i2);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void cueVideo(String str) {
        cueVideo(str, 0);
    }

    public final void cueVideo(String str, int i) {
        try {
            this.f224b.mo7067a(str, i);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void cueVideos(List<String> list) {
        cueVideos(list, 0, 0);
    }

    public final void cueVideos(List<String> list, int i, int i2) {
        try {
            this.f224b.mo7069a((List) list, i, i2);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void m632d() {
        try {
            this.f224b.mo7097o();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void m633e() {
        try {
            this.f224b.mo7098p();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void m634f() {
        try {
            this.f224b.mo7099q();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void m635g() {
        try {
            this.f224b.mo7094l();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final int getCurrentTimeMillis() {
        try {
            return this.f224b.mo7090h();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final int getDurationMillis() {
        try {
            return this.f224b.mo7091i();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final int getFullscreenControlFlags() {
        try {
            return this.f224b.mo7092j();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final Bundle m636h() {
        try {
            return this.f224b.mo7100r();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final boolean hasNext() {
        try {
            return this.f224b.mo7085d();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final boolean hasPrevious() {
        try {
            return this.f224b.mo7087e();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final boolean isPlaying() {
        try {
            return this.f224b.mo7082c();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void loadPlaylist(String str) {
        loadPlaylist(str, 0, 0);
    }

    public final void loadPlaylist(String str, int i, int i2) {
        try {
            this.f224b.mo7076b(str, i, i2);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void loadVideo(String str) {
        loadVideo(str, 0);
    }

    public final void loadVideo(String str, int i) {
        try {
            this.f224b.mo7075b(str, i);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void loadVideos(List<String> list) {
        loadVideos(list, 0, 0);
    }

    public final void loadVideos(List<String> list, int i, int i2) {
        try {
            this.f224b.mo7077b((List) list, i, i2);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void next() {
        try {
            this.f224b.mo7088f();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void pause() {
        try {
            this.f224b.mo7073b();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void play() {
        try {
            this.f224b.mo7059a();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void previous() {
        try {
            this.f224b.mo7089g();
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void release() {
        m625a(true);
    }

    public final void seekRelativeMillis(int i) {
        try {
            this.f224b.mo7074b(i);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void seekToMillis(int i) {
        try {
            this.f224b.mo7060a(i);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void setFullscreen(boolean z) {
        try {
            this.f224b.mo7078b(z);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void setFullscreenControlFlags(int i) {
        try {
            this.f224b.mo7080c(i);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void setManageAudioFocus(boolean z) {
        try {
            this.f224b.mo7084d(z);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void setOnFullscreenListener(final YouTubePlayer$OnFullscreenListener youTubePlayer$OnFullscreenListener) {
        try {
            this.f224b.mo7062a(new C2185a(this) {
                final /* synthetic */ C2226s f216b;

                public final void mo7102a(boolean z) {
                    youTubePlayer$OnFullscreenListener.onFullscreen(z);
                }
            });
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void setPlaybackEventListener(final YouTubePlayer$PlaybackEventListener youTubePlayer$PlaybackEventListener) {
        try {
            this.f224b.mo7063a(new C2188a(this) {
                final /* synthetic */ C2226s f222b;

                public final void mo7103a() {
                    youTubePlayer$PlaybackEventListener.onPlaying();
                }

                public final void mo7104a(int i) {
                    youTubePlayer$PlaybackEventListener.onSeekTo(i);
                }

                public final void mo7105a(boolean z) {
                    youTubePlayer$PlaybackEventListener.onBuffering(z);
                }

                public final void mo7106b() {
                    youTubePlayer$PlaybackEventListener.onPaused();
                }

                public final void mo7107c() {
                    youTubePlayer$PlaybackEventListener.onStopped();
                }
            });
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void setPlayerStateChangeListener(final PlayerStateChangeListener playerStateChangeListener) {
        try {
            this.f224b.mo7064a(new C2191a(this) {
                final /* synthetic */ C2226s f220b;

                public final void mo7108a() {
                    playerStateChangeListener.onLoading();
                }

                public final void mo7109a(String str) {
                    playerStateChangeListener.onLoaded(str);
                }

                public final void mo7110b() {
                    playerStateChangeListener.onAdStarted();
                }

                public final void mo7111b(String str) {
                    YouTubePlayer$ErrorReason valueOf;
                    try {
                        valueOf = YouTubePlayer$ErrorReason.valueOf(str);
                    } catch (IllegalArgumentException e) {
                        valueOf = YouTubePlayer$ErrorReason.UNKNOWN;
                    } catch (NullPointerException e2) {
                        valueOf = YouTubePlayer$ErrorReason.UNKNOWN;
                    }
                    playerStateChangeListener.onError(valueOf);
                }

                public final void mo7112c() {
                    playerStateChangeListener.onVideoStarted();
                }

                public final void mo7113d() {
                    playerStateChangeListener.onVideoEnded();
                }
            });
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void setPlayerStyle(YouTubePlayer$PlayerStyle youTubePlayer$PlayerStyle) {
        try {
            this.f224b.mo7066a(youTubePlayer$PlayerStyle.name());
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void setPlaylistEventListener(final YouTubePlayer$PlaylistEventListener youTubePlayer$PlaylistEventListener) {
        try {
            this.f224b.mo7065a(new C2194a(this) {
                final /* synthetic */ C2226s f218b;

                public final void mo7114a() {
                    youTubePlayer$PlaylistEventListener.onPrevious();
                }

                public final void mo7115b() {
                    youTubePlayer$PlaylistEventListener.onNext();
                }

                public final void mo7116c() {
                    youTubePlayer$PlaylistEventListener.onPlaylistEnded();
                }
            });
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }

    public final void setShowFullscreenButton(boolean z) {
        try {
            this.f224b.mo7081c(z);
        } catch (RemoteException e) {
            throw new C2215q(e);
        }
    }
}
