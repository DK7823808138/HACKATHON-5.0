package com.google.android.youtube.player.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.youtube.player.internal.C2175t.C2171a;
import com.google.android.youtube.player.internal.C2175t.C2172b;
import com.google.android.youtube.player.internal.C2204l.C2206a;
import com.google.android.youtube.player.internal.C2209r.C2220d;

public final class C2210o extends C2209r<C2204l> implements C2176b {
    private final String f187b;
    private final String f188c;
    private final String f189d;
    private boolean f190e;

    public C2210o(Context context, String str, String str2, String str3, C2171a c2171a, C2172b c2172b) {
        super(context, c2171a, c2172b);
        this.f187b = (String) ab.m397a((Object) str);
        this.f188c = ab.m399a(str2, (Object) "callingPackage cannot be null or empty");
        this.f189d = ab.m399a(str3, (Object) "callingAppVersion cannot be null or empty");
    }

    private final void m580k() {
        m578i();
        if (this.f190e) {
            throw new IllegalStateException("Connection client has been released");
        }
    }

    public final IBinder mo7131a() {
        m580k();
        try {
            return ((C2204l) m579j()).mo7126a();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    protected final /* synthetic */ IInterface mo7132a(IBinder iBinder) {
        return C2206a.m554a(iBinder);
    }

    public final C2201k mo7133a(C2198j c2198j) {
        m580k();
        try {
            return ((C2204l) m579j()).mo7127a(c2198j);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    protected final void mo7134a(C2195i c2195i, C2220d c2220d) throws RemoteException {
        c2195i.mo7117a(c2220d, 1202, this.f188c, this.f189d, this.f187b, null);
    }

    public final void mo7135a(boolean z) {
        if (m575f()) {
            try {
                ((C2204l) m579j()).mo7128a(z);
            } catch (RemoteException e) {
            }
            this.f190e = true;
        }
    }

    protected final String mo7136b() {
        return "com.google.android.youtube.player.internal.IYouTubeService";
    }

    protected final String mo7137c() {
        return "com.google.android.youtube.api.service.START";
    }

    public final void mo7129d() {
        if (!this.f190e) {
            mo7135a(true);
        }
        super.mo7129d();
    }
}
