package com.google.android.youtube.player.internal;

import com.google.android.youtube.player.YouTubeInitializationResult;

public interface C2175t {

    public interface C2171a {
        void mo7042a();

        void mo7043b();
    }

    public interface C2172b {
        void mo7044a(YouTubeInitializationResult youTubeInitializationResult);
    }

    void mo7129d();

    void mo7130e();
}
