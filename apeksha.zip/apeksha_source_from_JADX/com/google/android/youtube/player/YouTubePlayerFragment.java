package com.google.android.youtube.player;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayer.Provider;
import com.google.android.youtube.player.YouTubePlayerView.b;
import com.google.android.youtube.player.internal.ab;

public class YouTubePlayerFragment extends Fragment implements Provider {
    private final C2169a f127a = new C2169a();
    private Bundle f128b;
    private YouTubePlayerView f129c;
    private String f130d;
    private OnInitializedListener f131e;
    private boolean f132f;

    private final class C2169a implements b {
        final /* synthetic */ YouTubePlayerFragment f126a;

        private C2169a(YouTubePlayerFragment youTubePlayerFragment) {
            this.f126a = youTubePlayerFragment;
        }

        public final void m356a(YouTubePlayerView youTubePlayerView) {
        }

        public final void m357a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener) {
            this.f126a.initialize(str, this.f126a.f131e);
        }
    }

    private void m359a() {
        if (this.f129c != null && this.f131e != null) {
            this.f129c.a(this.f132f);
            this.f129c.a(getActivity(), this, this.f130d, this.f131e, this.f128b);
            this.f128b = null;
            this.f131e = null;
        }
    }

    public static YouTubePlayerFragment newInstance() {
        return new YouTubePlayerFragment();
    }

    public void initialize(String str, OnInitializedListener onInitializedListener) {
        this.f130d = ab.m399a(str, (Object) "Developer key cannot be null or empty");
        this.f131e = onInitializedListener;
        m359a();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f128b = bundle != null ? bundle.getBundle("YouTubePlayerFragment.KEY_PLAYER_VIEW_STATE") : null;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f129c = new YouTubePlayerView(getActivity(), null, 0, this.f127a);
        m359a();
        return this.f129c;
    }

    public void onDestroy() {
        if (this.f129c != null) {
            Activity activity = getActivity();
            YouTubePlayerView youTubePlayerView = this.f129c;
            boolean z = activity == null || activity.isFinishing();
            youTubePlayerView.b(z);
        }
        super.onDestroy();
    }

    public void onDestroyView() {
        this.f129c.c(getActivity().isFinishing());
        this.f129c = null;
        super.onDestroyView();
    }

    public void onPause() {
        this.f129c.c();
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.f129c.b();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putBundle("YouTubePlayerFragment.KEY_PLAYER_VIEW_STATE", this.f129c != null ? this.f129c.e() : this.f128b);
    }

    public void onStart() {
        super.onStart();
        this.f129c.a();
    }

    public void onStop() {
        this.f129c.d();
        super.onStop();
    }
}
