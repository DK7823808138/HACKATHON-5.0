package com.google.android.youtube.player;

public interface YouTubePlayer$PlaylistEventListener {
    void onNext();

    void onPlaylistEnded();

    void onPrevious();
}
