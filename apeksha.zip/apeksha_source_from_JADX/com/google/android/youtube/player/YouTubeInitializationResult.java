package com.google.android.youtube.player;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import com.google.android.youtube.player.internal.m;
import com.google.android.youtube.player.internal.z;

public enum YouTubeInitializationResult {
    SUCCESS,
    INTERNAL_ERROR,
    UNKNOWN_ERROR,
    SERVICE_MISSING,
    SERVICE_VERSION_UPDATE_REQUIRED,
    SERVICE_DISABLED,
    SERVICE_INVALID,
    ERROR_CONNECTING_TO_SERVICE,
    CLIENT_LIBRARY_UPDATE_REQUIRED,
    NETWORK_ERROR,
    DEVELOPER_KEY_INVALID,
    INVALID_APPLICATION_SIGNATURE;

    public final Dialog getErrorDialog(Activity activity, int i) {
        return getErrorDialog(activity, i, null);
    }

    public final Dialog getErrorDialog(Activity activity, int i, OnCancelListener onCancelListener) {
        Intent b;
        Builder builder = new Builder(activity);
        if (onCancelListener != null) {
            builder.setOnCancelListener(onCancelListener);
        }
        switch (1.a[ordinal()]) {
            case 1:
            case 3:
                b = z.b(z.a(activity));
                break;
            case 2:
                b = z.a(z.a(activity));
                break;
            default:
                b = null;
                break;
        }
        OnClickListener aVar = new a(activity, b, i);
        m mVar = new m(activity);
        switch (1.a[ordinal()]) {
            case 1:
                return builder.setTitle(mVar.b).setMessage(mVar.c).setPositiveButton(mVar.d, aVar).create();
            case 2:
                return builder.setTitle(mVar.e).setMessage(mVar.f).setPositiveButton(mVar.g, aVar).create();
            case 3:
                return builder.setTitle(mVar.h).setMessage(mVar.i).setPositiveButton(mVar.j, aVar).create();
            default:
                String str = "Unexpected errorReason: ";
                String valueOf = String.valueOf(name());
                throw new IllegalArgumentException(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        }
    }

    public final boolean isUserRecoverableError() {
        switch (1.a[ordinal()]) {
            case 1:
            case 2:
            case 3:
                return true;
            default:
                return false;
        }
    }
}
