package com.google.android.youtube.player;

import android.app.Activity;
import com.google.android.youtube.player.internal.C2175t.C2171a;

class YouTubePlayerView$1 implements C2171a {
    final /* synthetic */ Activity f140a;
    final /* synthetic */ YouTubePlayerView f141b;

    YouTubePlayerView$1(YouTubePlayerView youTubePlayerView, Activity activity) {
        this.f141b = youTubePlayerView;
        this.f140a = activity;
    }

    public final void mo7042a() {
        if (YouTubePlayerView.a(this.f141b) != null) {
            YouTubePlayerView.a(this.f141b, this.f140a);
        }
        YouTubePlayerView.b(this.f141b);
    }

    public final void mo7043b() {
        if (!(YouTubePlayerView.c(this.f141b) || YouTubePlayerView.d(this.f141b) == null)) {
            YouTubePlayerView.d(this.f141b).m634f();
        }
        YouTubePlayerView.e(this.f141b).m555a();
        if (this.f141b.indexOfChild(YouTubePlayerView.e(this.f141b)) < 0) {
            this.f141b.addView(YouTubePlayerView.e(this.f141b));
            this.f141b.removeView(YouTubePlayerView.f(this.f141b));
        }
        YouTubePlayerView.g(this.f141b);
        YouTubePlayerView.h(this.f141b);
        YouTubePlayerView.b(this.f141b);
    }
}
