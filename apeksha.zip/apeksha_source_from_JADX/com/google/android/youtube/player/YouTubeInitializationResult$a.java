package com.google.android.youtube.player;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import com.google.android.youtube.player.internal.C2234y;
import com.google.android.youtube.player.internal.ab;

final class YouTubeInitializationResult$a implements OnClickListener {
    private final Activity f121a;
    private final Intent f122b;
    private final int f123c;

    public YouTubeInitializationResult$a(Activity activity, Intent intent, int i) {
        this.f121a = (Activity) ab.m397a((Object) activity);
        this.f122b = (Intent) ab.m397a((Object) intent);
        this.f123c = ((Integer) ab.m397a(Integer.valueOf(i))).intValue();
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        try {
            this.f121a.startActivityForResult(this.f122b, this.f123c);
            dialogInterface.dismiss();
        } catch (Throwable e) {
            C2234y.m645a("Can't perform resolution for YouTubeInitalizationError", e);
        }
    }
}
