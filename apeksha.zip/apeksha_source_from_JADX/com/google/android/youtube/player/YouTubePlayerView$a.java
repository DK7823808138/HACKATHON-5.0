package com.google.android.youtube.player;

import android.view.View;
import android.view.ViewTreeObserver.OnGlobalFocusChangeListener;

final class YouTubePlayerView$a implements OnGlobalFocusChangeListener {
    final /* synthetic */ YouTubePlayerView f143a;

    private YouTubePlayerView$a(YouTubePlayerView youTubePlayerView) {
        this.f143a = youTubePlayerView;
    }

    public final void onGlobalFocusChanged(View view, View view2) {
        if (YouTubePlayerView.d(this.f143a) != null && YouTubePlayerView.i(this.f143a).contains(view2) && !YouTubePlayerView.i(this.f143a).contains(view)) {
            YouTubePlayerView.d(this.f143a).m635g();
        }
    }
}
