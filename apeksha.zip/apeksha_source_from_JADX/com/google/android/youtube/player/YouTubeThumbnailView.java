package com.google.android.youtube.player;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;
import com.google.android.youtube.player.internal.C2174a;
import com.google.android.youtube.player.internal.C2175t.C2171a;
import com.google.android.youtube.player.internal.C2175t.C2172b;
import com.google.android.youtube.player.internal.C2176b;
import com.google.android.youtube.player.internal.aa;
import com.google.android.youtube.player.internal.ab;

public final class YouTubeThumbnailView extends ImageView {
    private C2176b f147a;
    private C2174a f148b;

    public interface OnInitializedListener {
        void onInitializationFailure(YouTubeThumbnailView youTubeThumbnailView, YouTubeInitializationResult youTubeInitializationResult);

        void onInitializationSuccess(YouTubeThumbnailView youTubeThumbnailView, YouTubeThumbnailLoader youTubeThumbnailLoader);
    }

    private static final class C2173a implements C2171a, C2172b {
        private YouTubeThumbnailView f145a;
        private OnInitializedListener f146b;

        public C2173a(YouTubeThumbnailView youTubeThumbnailView, OnInitializedListener onInitializedListener) {
            this.f145a = (YouTubeThumbnailView) ab.m398a((Object) youTubeThumbnailView, (Object) "thumbnailView cannot be null");
            this.f146b = (OnInitializedListener) ab.m398a((Object) onInitializedListener, (Object) "onInitializedlistener cannot be null");
        }

        private void m371c() {
            if (this.f145a != null) {
                this.f145a.f147a = null;
                this.f145a = null;
                this.f146b = null;
            }
        }

        public final void mo7042a() {
            if (this.f145a != null && this.f145a.f147a != null) {
                this.f145a.f148b = aa.m392a().mo7055a(this.f145a.f147a, this.f145a);
                this.f146b.onInitializationSuccess(this.f145a, this.f145a.f148b);
                m371c();
            }
        }

        public final void mo7044a(YouTubeInitializationResult youTubeInitializationResult) {
            this.f146b.onInitializationFailure(this.f145a, youTubeInitializationResult);
            m371c();
        }

        public final void mo7043b() {
            m371c();
        }
    }

    public YouTubeThumbnailView(Context context) {
        this(context, null);
    }

    public YouTubeThumbnailView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public YouTubeThumbnailView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    protected final void finalize() throws Throwable {
        if (this.f148b != null) {
            this.f148b.m384b();
            this.f148b = null;
        }
        super.finalize();
    }

    public final void initialize(String str, OnInitializedListener onInitializedListener) {
        Object c2173a = new C2173a(this, onInitializedListener);
        this.f147a = aa.m392a().mo7056a(getContext(), str, c2173a, c2173a);
        this.f147a.mo7130e();
    }
}
