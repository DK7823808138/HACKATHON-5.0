package com.google.android.youtube.player;

public interface YouTubePlayer$OnFullscreenListener {
    void onFullscreen(boolean z);
}
