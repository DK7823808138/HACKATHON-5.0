package com.google.android.youtube.player;

import android.app.Activity;
import android.os.Bundle;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayerView.C0971b;

public class YouTubeBaseActivity extends Activity {
    private C0972a f17a;
    private YouTubePlayerView f18b;
    private int f19c;
    private Bundle f20d;

    private final class C0972a implements C0971b {
        final /* synthetic */ YouTubeBaseActivity f16a;

        private C0972a(YouTubeBaseActivity youTubeBaseActivity) {
            this.f16a = youTubeBaseActivity;
        }

        public final void mo3438a(YouTubePlayerView youTubePlayerView) {
            if (!(this.f16a.f18b == null || this.f16a.f18b == youTubePlayerView)) {
                this.f16a.f18b.m51c(true);
            }
            this.f16a.f18b = youTubePlayerView;
            if (this.f16a.f19c > 0) {
                youTubePlayerView.m45a();
            }
            if (this.f16a.f19c >= 2) {
                youTubePlayerView.m48b();
            }
        }

        public final void mo3439a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener) {
            youTubePlayerView.m46a(this.f16a, youTubePlayerView, str, onInitializedListener, this.f16a.f20d);
            this.f16a.f20d = null;
        }
    }

    final C0971b m31a() {
        return this.f17a;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f17a = new C0972a();
        this.f20d = bundle != null ? bundle.getBundle("YouTubeBaseActivity.KEY_PLAYER_VIEW_STATE") : null;
    }

    protected void onDestroy() {
        if (this.f18b != null) {
            this.f18b.m49b(isFinishing());
        }
        super.onDestroy();
    }

    protected void onPause() {
        this.f19c = 1;
        if (this.f18b != null) {
            this.f18b.m50c();
        }
        super.onPause();
    }

    protected void onResume() {
        super.onResume();
        this.f19c = 2;
        if (this.f18b != null) {
            this.f18b.m48b();
        }
    }

    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putBundle("YouTubeBaseActivity.KEY_PLAYER_VIEW_STATE", this.f18b != null ? this.f18b.m53e() : this.f20d);
    }

    protected void onStart() {
        super.onStart();
        this.f19c = 1;
        if (this.f18b != null) {
            this.f18b.m45a();
        }
    }

    protected void onStop() {
        this.f19c = 0;
        if (this.f18b != null) {
            this.f18b.m52d();
        }
        super.onStop();
    }
}
