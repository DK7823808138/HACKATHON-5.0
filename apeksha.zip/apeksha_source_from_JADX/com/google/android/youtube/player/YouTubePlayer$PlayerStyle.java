package com.google.android.youtube.player;

public enum YouTubePlayer$PlayerStyle {
    DEFAULT,
    MINIMAL,
    CHROMELESS
}
