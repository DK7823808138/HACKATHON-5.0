package com.google.android.youtube.player;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayer.Provider;
import com.google.android.youtube.player.internal.aa;
import com.google.android.youtube.player.internal.ab;
import com.google.android.youtube.player.internal.b;
import com.google.android.youtube.player.internal.n;
import com.google.android.youtube.player.internal.s;
import com.google.android.youtube.player.internal.y;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public final class YouTubePlayerView extends ViewGroup implements Provider {
    private final a f22a;
    private final Set<View> f23b;
    private final C0971b f24c;
    private b f25d;
    private s f26e;
    private View f27f;
    private n f28g;
    private Provider f29h;
    private Bundle f30i;
    private OnInitializedListener f31j;
    private boolean f32k;
    private boolean f33l;

    interface C0971b {
        void mo3438a(YouTubePlayerView youTubePlayerView);

        void mo3439a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener);
    }

    public YouTubePlayerView(Context context) {
        this(context, null);
    }

    public YouTubePlayerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public YouTubePlayerView(Context context, AttributeSet attributeSet, int i) {
        if (context instanceof YouTubeBaseActivity) {
            this(context, attributeSet, i, ((YouTubeBaseActivity) context).m31a());
            return;
        }
        throw new IllegalStateException("A YouTubePlayerView can only be created with an Activity  which extends YouTubeBaseActivity as its context.");
    }

    YouTubePlayerView(Context context, AttributeSet attributeSet, int i, C0971b c0971b) {
        super((Context) ab.a(context, "context cannot be null"), attributeSet, i);
        this.f24c = (C0971b) ab.a(c0971b, "listener cannot be null");
        if (getBackground() == null) {
            setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        }
        setClipToPadding(false);
        this.f28g = new n(context);
        requestTransparentRegion(this.f28g);
        addView(this.f28g);
        this.f23b = new HashSet();
        this.f22a = new a(this, (byte) 0);
    }

    private void m33a(View view) {
        Object obj = (view == this.f28g || (this.f26e != null && view == this.f27f)) ? 1 : null;
        if (obj == null) {
            throw new UnsupportedOperationException("No views can be added on top of the player");
        }
    }

    private void m34a(YouTubeInitializationResult youTubeInitializationResult) {
        this.f26e = null;
        this.f28g.c();
        if (this.f31j != null) {
            this.f31j.onInitializationFailure(this.f29h, youTubeInitializationResult);
            this.f31j = null;
        }
    }

    static /* synthetic */ void m35a(YouTubePlayerView youTubePlayerView, Activity activity) {
        try {
            youTubePlayerView.f26e = new s(youTubePlayerView.f25d, aa.a().a(activity, youTubePlayerView.f25d, youTubePlayerView.f32k));
            youTubePlayerView.f27f = youTubePlayerView.f26e.a();
            youTubePlayerView.addView(youTubePlayerView.f27f);
            youTubePlayerView.removeView(youTubePlayerView.f28g);
            youTubePlayerView.f24c.mo3438a(youTubePlayerView);
            if (youTubePlayerView.f31j != null) {
                boolean z = false;
                if (youTubePlayerView.f30i != null) {
                    z = youTubePlayerView.f26e.a(youTubePlayerView.f30i);
                    youTubePlayerView.f30i = null;
                }
                youTubePlayerView.f31j.onInitializationSuccess(youTubePlayerView.f29h, youTubePlayerView.f26e, z);
                youTubePlayerView.f31j = null;
            }
        } catch (Throwable e) {
            y.a("Error creating YouTubePlayerView", e);
            youTubePlayerView.m34a(YouTubeInitializationResult.INTERNAL_ERROR);
        }
    }

    final void m45a() {
        if (this.f26e != null) {
            this.f26e.b();
        }
    }

    final void m46a(Activity activity, Provider provider, String str, OnInitializedListener onInitializedListener, Bundle bundle) {
        if (this.f26e == null && this.f31j == null) {
            ab.a(activity, "activity cannot be null");
            this.f29h = (Provider) ab.a(provider, "provider cannot be null");
            this.f31j = (OnInitializedListener) ab.a(onInitializedListener, "listener cannot be null");
            this.f30i = bundle;
            this.f28g.b();
            this.f25d = aa.a().a(getContext(), str, new 1(this, activity), new 2(this));
            this.f25d.e();
        }
    }

    final void m47a(boolean z) {
        if (!z || VERSION.SDK_INT >= 14) {
            this.f32k = z;
            return;
        }
        y.a("Could not enable TextureView because API level is lower than 14", new Object[0]);
        this.f32k = false;
    }

    public final void addFocusables(ArrayList<View> arrayList, int i) {
        Collection arrayList2 = new ArrayList();
        super.addFocusables(arrayList2, i);
        arrayList.addAll(arrayList2);
        this.f23b.clear();
        this.f23b.addAll(arrayList2);
    }

    public final void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        Collection arrayList2 = new ArrayList();
        super.addFocusables(arrayList2, i, i2);
        arrayList.addAll(arrayList2);
        this.f23b.clear();
        this.f23b.addAll(arrayList2);
    }

    public final void addView(View view) {
        m33a(view);
        super.addView(view);
    }

    public final void addView(View view, int i) {
        m33a(view);
        super.addView(view, i);
    }

    public final void addView(View view, int i, int i2) {
        m33a(view);
        super.addView(view, i, i2);
    }

    public final void addView(View view, int i, LayoutParams layoutParams) {
        m33a(view);
        super.addView(view, i, layoutParams);
    }

    public final void addView(View view, LayoutParams layoutParams) {
        m33a(view);
        super.addView(view, layoutParams);
    }

    final void m48b() {
        if (this.f26e != null) {
            this.f26e.c();
        }
    }

    final void m49b(boolean z) {
        if (this.f26e != null) {
            this.f26e.b(z);
            m51c(z);
        }
    }

    final void m50c() {
        if (this.f26e != null) {
            this.f26e.d();
        }
    }

    final void m51c(boolean z) {
        this.f33l = true;
        if (this.f26e != null) {
            this.f26e.a(z);
        }
    }

    public final void clearChildFocus(View view) {
        if (hasFocusable()) {
            requestFocus();
        } else {
            super.clearChildFocus(view);
        }
    }

    final void m52d() {
        if (this.f26e != null) {
            this.f26e.e();
        }
    }

    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (this.f26e != null) {
            if (keyEvent.getAction() == 0) {
                return this.f26e.a(keyEvent.getKeyCode(), keyEvent) || super.dispatchKeyEvent(keyEvent);
            } else {
                if (keyEvent.getAction() == 1) {
                    return this.f26e.b(keyEvent.getKeyCode(), keyEvent) || super.dispatchKeyEvent(keyEvent);
                }
            }
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    final Bundle m53e() {
        return this.f26e == null ? this.f30i : this.f26e.h();
    }

    public final void focusableViewAvailable(View view) {
        super.focusableViewAvailable(view);
        this.f23b.add(view);
    }

    public final void initialize(String str, OnInitializedListener onInitializedListener) {
        ab.a(str, "Developer key cannot be null or empty");
        this.f24c.mo3439a(this, str, onInitializedListener);
    }

    protected final void onAttachedToWindow() {
        super.onAttachedToWindow();
        getViewTreeObserver().addOnGlobalFocusChangeListener(this.f22a);
    }

    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (this.f26e != null) {
            this.f26e.a(configuration);
        }
    }

    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        getViewTreeObserver().removeOnGlobalFocusChangeListener(this.f22a);
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        if (getChildCount() > 0) {
            getChildAt(0).layout(0, 0, i3 - i, i4 - i2);
        }
    }

    protected final void onMeasure(int i, int i2) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            childAt.measure(i, i2);
            setMeasuredDimension(childAt.getMeasuredWidth(), childAt.getMeasuredHeight());
            return;
        }
        setMeasuredDimension(0, 0);
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public final void requestChildFocus(View view, View view2) {
        super.requestChildFocus(view, view2);
        this.f23b.add(view2);
    }

    public final void setClipToPadding(boolean z) {
    }

    public final void setPadding(int i, int i2, int i3, int i4) {
    }
}
