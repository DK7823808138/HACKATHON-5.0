package com.google.android.youtube.player;

public interface YouTubePlayer$PlaybackEventListener {
    void onBuffering(boolean z);

    void onPaused();

    void onPlaying();

    void onSeekTo(int i);

    void onStopped();
}
