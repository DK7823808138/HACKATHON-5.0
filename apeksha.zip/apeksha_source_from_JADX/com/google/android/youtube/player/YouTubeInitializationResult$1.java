package com.google.android.youtube.player;

/* synthetic */ class YouTubeInitializationResult$1 {
    static final /* synthetic */ int[] f120a = new int[YouTubeInitializationResult.values().length];

    static {
        try {
            f120a[YouTubeInitializationResult.SERVICE_MISSING.ordinal()] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            f120a[YouTubeInitializationResult.SERVICE_DISABLED.ordinal()] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            f120a[YouTubeInitializationResult.SERVICE_VERSION_UPDATE_REQUIRED.ordinal()] = 3;
        } catch (NoSuchFieldError e3) {
        }
    }
}
