package com.google.android.youtube.player;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayer.Provider;
import com.google.android.youtube.player.YouTubePlayerView.b;
import com.google.android.youtube.player.internal.ab;

public class YouTubePlayerSupportFragment extends Fragment implements Provider {
    private final C2170a f134a = new C2170a();
    private Bundle f135b;
    private YouTubePlayerView f136c;
    private String f137d;
    private OnInitializedListener f138e;
    private boolean f139f;

    private final class C2170a implements b {
        final /* synthetic */ YouTubePlayerSupportFragment f133a;

        private C2170a(YouTubePlayerSupportFragment youTubePlayerSupportFragment) {
            this.f133a = youTubePlayerSupportFragment;
        }

        public final void m360a(YouTubePlayerView youTubePlayerView) {
        }

        public final void m361a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener) {
            this.f133a.initialize(str, this.f133a.f138e);
        }
    }

    private void m363a() {
        if (this.f136c != null && this.f138e != null) {
            this.f136c.a(this.f139f);
            this.f136c.a(getActivity(), this, this.f137d, this.f138e, this.f135b);
            this.f135b = null;
            this.f138e = null;
        }
    }

    public static YouTubePlayerSupportFragment newInstance() {
        return new YouTubePlayerSupportFragment();
    }

    public void initialize(String str, OnInitializedListener onInitializedListener) {
        this.f137d = ab.m399a(str, (Object) "Developer key cannot be null or empty");
        this.f138e = onInitializedListener;
        m363a();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f135b = bundle != null ? bundle.getBundle("YouTubePlayerSupportFragment.KEY_PLAYER_VIEW_STATE") : null;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f136c = new YouTubePlayerView(getActivity(), null, 0, this.f134a);
        m363a();
        return this.f136c;
    }

    public void onDestroy() {
        if (this.f136c != null) {
            Activity activity = getActivity();
            YouTubePlayerView youTubePlayerView = this.f136c;
            boolean z = activity == null || activity.isFinishing();
            youTubePlayerView.b(z);
        }
        super.onDestroy();
    }

    public void onDestroyView() {
        this.f136c.c(getActivity().isFinishing());
        this.f136c = null;
        super.onDestroyView();
    }

    public void onPause() {
        this.f136c.c();
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.f136c.b();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putBundle("YouTubePlayerSupportFragment.KEY_PLAYER_VIEW_STATE", this.f136c != null ? this.f136c.e() : this.f135b);
    }

    public void onStart() {
        super.onStart();
        this.f136c.a();
    }

    public void onStop() {
        this.f136c.d();
        super.onStop();
    }
}
