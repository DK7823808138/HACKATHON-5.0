package com.google.android.youtube.player;

import com.google.android.youtube.player.internal.C2175t.C2172b;

class YouTubePlayerView$2 implements C2172b {
    final /* synthetic */ YouTubePlayerView f142a;

    YouTubePlayerView$2(YouTubePlayerView youTubePlayerView) {
        this.f142a = youTubePlayerView;
    }

    public final void mo7044a(YouTubeInitializationResult youTubeInitializationResult) {
        YouTubePlayerView.a(this.f142a, youTubeInitializationResult);
        YouTubePlayerView.b(this.f142a);
    }
}
