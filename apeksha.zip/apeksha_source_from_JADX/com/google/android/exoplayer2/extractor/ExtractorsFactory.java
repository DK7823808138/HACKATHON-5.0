package com.google.android.exoplayer2.extractor;

public interface ExtractorsFactory {
    Extractor[] createExtractors();
}
