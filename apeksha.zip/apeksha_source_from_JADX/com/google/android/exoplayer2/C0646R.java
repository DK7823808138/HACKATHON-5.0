package com.google.android.exoplayer2;

import com.app.smartk.R;

public final class C0646R {

    public static final class attr {
        public static final int controller_layout_id = 2130771970;
        public static final int default_artwork = 2130772344;
        public static final int fastforward_increment = 2130771972;
        public static final int player_layout_id = 2130771996;
        public static final int resize_mode = 2130771997;
        public static final int rewind_increment = 2130771998;
        public static final int show_timeout = 2130771999;
        public static final int surface_type = 2130772000;
        public static final int use_artwork = 2130772343;
        public static final int use_controller = 2130772345;
    }

    public static final class dimen {
        public static final int exo_media_button_height = 2131361982;
        public static final int exo_media_button_width = 2131361983;
        public static final int new_exo_media_button_height = 2131362005;
        public static final int new_exo_media_button_width = 2131362006;
    }

    public static final class drawable {
        public static final int exo_controls_fastforward = 2130837727;
        public static final int exo_controls_next = 2130837728;
        public static final int exo_controls_pause = 2130837729;
        public static final int exo_controls_play = 2130837730;
        public static final int exo_controls_previous = 2130837731;
        public static final int exo_controls_rewind = 2130837732;
        public static final int full = 2130837740;
        public static final int fullscreen_icon = 2130837741;
    }

    public static final class id {
        public static final int exo_artwork = 2131755030;
        public static final int exo_content_frame = 2131755031;
        public static final int exo_controller_placeholder = 2131755032;
        public static final int exo_duration = 2131755033;
        public static final int exo_ffwd = 2131755034;
        public static final int exo_full = 2131755035;
        public static final int exo_next = 2131755036;
        public static final int exo_overlay = 2131755037;
        public static final int exo_pause = 2131755038;
        public static final int exo_play = 2131755039;
        public static final int exo_position = 2131755040;
        public static final int exo_prev = 2131755041;
        public static final int exo_progress = 2131755042;
        public static final int exo_rew = 2131755043;
        public static final int exo_shutter = 2131755044;
        public static final int exo_subtitles = 2131755045;
        public static final int fill = 2131755057;
        public static final int fit = 2131755058;
        public static final int fixed_height = 2131755059;
        public static final int fixed_width = 2131755060;
        public static final int none = 2131755061;
        public static final int surface_view = 2131755062;
        public static final int texture_view = 2131755063;
    }

    public static final class layout {
        public static final int audio_exo_simple_player_view = 2130903111;
        public static final int exo_simple_player_view = 2130903150;
    }

    public static final class string {
        public static final int exo_controls_fastforward_description = 2131230819;
        public static final int exo_controls_next_description = 2131230820;
        public static final int exo_controls_pause_description = 2131230821;
        public static final int exo_controls_play_description = 2131230822;
        public static final int exo_controls_previous_description = 2131230823;
        public static final int exo_controls_rewind_description = 2131230824;
        public static final int exo_controls_stop_description = 2131230825;
    }

    public static final class style {
        public static final int ExoMediaButton = 2131427357;
        public static final int ExoMediaButton_FastForward = 2131427545;
        public static final int ExoMediaButton_Full = 2131427546;
        public static final int ExoMediaButton_Next = 2131427547;
        public static final int ExoMediaButton_Pause = 2131427548;
        public static final int ExoMediaButton_Play = 2131427549;
        public static final int ExoMediaButton_Previous = 2131427550;
        public static final int ExoMediaButton_Rewind = 2131427551;
    }

    public static final class styleable {
        public static final int[] AspectRatioFrameLayout = new int[]{R.attr.resize_mode};
        public static final int AspectRatioFrameLayout_resize_mode = 0;
        public static final int[] PlaybackControlView = new int[]{R.attr.controller_layout_id, R.attr.fastforward_increment, R.attr.rewind_increment, R.attr.show_timeout};
        public static final int PlaybackControlView_controller_layout_id = 0;
        public static final int PlaybackControlView_fastforward_increment = 1;
        public static final int PlaybackControlView_rewind_increment = 2;
        public static final int PlaybackControlView_show_timeout = 3;
        public static final int[] SimpleExoPlayerView = new int[]{R.attr.controller_layout_id, R.attr.fastforward_increment, R.attr.player_layout_id, R.attr.resize_mode, R.attr.rewind_increment, R.attr.show_timeout, R.attr.surface_type, R.attr.use_artwork, R.attr.default_artwork, R.attr.use_controller};
        public static final int SimpleExoPlayerView_controller_layout_id = 0;
        public static final int SimpleExoPlayerView_default_artwork = 8;
        public static final int SimpleExoPlayerView_fastforward_increment = 1;
        public static final int SimpleExoPlayerView_player_layout_id = 2;
        public static final int SimpleExoPlayerView_resize_mode = 3;
        public static final int SimpleExoPlayerView_rewind_increment = 4;
        public static final int SimpleExoPlayerView_show_timeout = 5;
        public static final int SimpleExoPlayerView_surface_type = 6;
        public static final int SimpleExoPlayerView_use_artwork = 7;
        public static final int SimpleExoPlayerView_use_controller = 9;
    }
}
